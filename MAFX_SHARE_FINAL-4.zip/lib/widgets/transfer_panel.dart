import 'dart:async';

import 'package:flutter/material.dart';

import '../models.dart';
import '../screens/viewer_screens.dart';
import '../services/history_service.dart';
import '../services/transfer_service.dart';
import '../theme.dart';
import 'chunk_bar.dart';

/// Two tabs: "Send" (what this phone is sending) and "Received" (what is
/// coming in). Each tab shows its own live progress and its own recent files.
/// Also shows the Wi-Fi band / link speed, because that is what limits speed.
class TransferPanel extends StatefulWidget {
  const TransferPanel({super.key, this.initialTab = 0});

  final int initialTab;

  @override
  State<TransferPanel> createState() => _TransferPanelState();
}

class _TransferPanelState extends State<TransferPanel>
    with SingleTickerProviderStateMixin {
  final svc = TransferService.instance;
  late final TabController _tabs =
      TabController(length: 2, vsync: this, initialIndex: widget.initialTab);
  Timer? _timer;
  Map<String, int>? _link;
  bool _details = false;
  bool _testing = false;
  String _testResult = '';

  /// Separates "slow Wi-Fi" from "slow storage": run it on BOTH phones.
  Future<void> _runTest() async {
    setState(() {
      _testing = true;
      _testResult = 'Testing (about 8 seconds)...';
    });
    String r;
    try {
      final net = await svc.networkTest();
      final disk = await svc.diskTest();
      r = 'Network to the other phone: ${net.toStringAsFixed(1)} MB/s\n'
          'This phone disk write: ${disk.toStringAsFixed(1)} MB/s';
    } catch (e) {
      r = 'Test failed: ${e.toString().replaceFirst('Exception: ', '')}';
    }
    if (mounted) {
      setState(() {
        _testing = false;
        _testResult = r;
      });
    }
  }

  @override
  void initState() {
    super.initState();
    _poll();
    _timer = Timer.periodic(const Duration(seconds: 3), (_) => _poll());
  }

  @override
  void dispose() {
    _timer?.cancel();
    _tabs.dispose();
    super.dispose();
  }

  Future<void> _poll() async {
    final l = await svc.wifiLinkInfo();
    if (mounted) setState(() => _link = l);
  }

  Widget _linkInfo() {
    final l = _link;
    final f = l == null ? -1 : (l['freq'] ?? -1);
    final band = f >= 5925 ? '6 GHz' : (f >= 4900 ? '5 GHz' : '2.4 GHz');
    final speed = (l != null && (l['speed'] ?? -1) > 0) ? ' · ${l['speed']} Mbps' : '';
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Column(
        children: [
          if (f > 0) ...[
            Text('Wi-Fi: $band$speed',
                style: const TextStyle(fontWeight: FontWeight.w600)),
            if (f < 4900)
              Text(
                '2.4 GHz limits speed to roughly 5-12 MB/s. Use a 5 GHz Wi-Fi for more.',
                textAlign: TextAlign.center,
                style: TextStyle(
                    fontSize: 12, color: alpha(Colors.orangeAccent, 0.9)),
              ),
          ],
          ValueListenableBuilder<int>(
            valueListenable: svc.activeStreams,
            builder: (context, n, _) => n > 0
                ? Text('Streams in use: $n',
                    style: TextStyle(color: alpha(Colors.white, 0.7)))
                : const SizedBox.shrink(),
          ),
          TextButton.icon(
            onPressed: _testing ? null : _runTest,
            icon: const Icon(Icons.speed, size: 18),
            label: const Text('Test speed'),
          ),
          if (_testResult.isNotEmpty)
            Text(_testResult,
                textAlign: TextAlign.center,
                style: const TextStyle(fontWeight: FontWeight.w600)),
          ValueListenableBuilder<String>(
            valueListenable: svc.chunkInfo,
            builder: (context, info, _) => info.isEmpty
                ? const SizedBox.shrink()
                : Text(info,
                    textAlign: TextAlign.center,
                    style: TextStyle(
                        fontSize: 12, color: alpha(Colors.white, 0.6))),
          ),
        ],
      ),
    );
  }

  /// Always visible: which Wi-Fi band the link uses (the main speed limit).
  Widget _bandChip() {
    final l = _link;
    final f = l == null ? -1 : (l['freq'] ?? -1);
    String text;
    var slow = false;
    if (f > 0) {
      final band = f >= 5925 ? '6 GHz' : (f >= 4900 ? '5 GHz' : '2.4 GHz');
      final speed = (l != null && (l['speed'] ?? -1) > 0) ? ' · ${l['speed']} Mbps' : '';
      text = 'Wi-Fi: $band$speed';
      slow = f < 4900;
    } else if (svc.hotspotBand == 2) {
      text = 'Wi-Fi: 5 GHz Wi-Fi Direct';
    } else if (svc.hotspotBand == 1) {
      text = 'Wi-Fi: hotspot (probably 2.4 GHz)';
      slow = true;
    } else {
      return const SizedBox.shrink();
    }
    return Padding(
      padding: const EdgeInsets.only(bottom: 4),
      child: Text(
        text,
        textAlign: TextAlign.center,
        style: TextStyle(
          fontSize: 12,
          fontWeight: FontWeight.w600,
          color: slow ? Colors.orangeAccent : kGreen,
        ),
      ),
    );
  }

  Tab _tab(String text, IconData icon, ValueNotifier<TransferProgress?> n) {
    return Tab(
      child: ValueListenableBuilder<TransferProgress?>(
        valueListenable: n,
        builder: (context, pr, _) {
          final active = pr != null && !pr.finished;
          return Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                pr != null && pr.finished ? Icons.check_circle : icon,
                size: 18,
                color: (active || (pr != null && pr.finished)) ? kGreen : null,
              ),
              const SizedBox(width: 6),
              Text(text),
              if (active) ...[
                const SizedBox(width: 6),
                Text('${(pr.fraction * 100).round()}%',
                    style: const TextStyle(color: kGreen, fontSize: 12)),
              ],
            ],
          );
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        ValueListenableBuilder<String>(
          valueListenable: svc.linkState,
          builder: (context, st, _) => st == 'lost'
              ? Container(
                  width: double.infinity,
                  margin: const EdgeInsets.only(bottom: 8),
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: alpha(Colors.orangeAccent, 0.15),
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: Colors.orangeAccent),
                  ),
                  child: const Text(
                    'Connection lost. Reconnecting by itself... What already arrived is kept.',
                    textAlign: TextAlign.center,
                  ),
                )
              : const SizedBox.shrink(),
        ),
        _bandChip(),
        ValueListenableBuilder<String?>(
          valueListenable: svc.lastIssue,
          builder: (context, r, _) => r == null
              ? const SizedBox.shrink()
              : Padding(
                  padding: const EdgeInsets.only(bottom: 6),
                  child: Text(
                    'Last problem: $r',
                    textAlign: TextAlign.center,
                    maxLines: 3,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontSize: 11, color: Colors.orangeAccent),
                  ),
                ),
        ),
        ValueListenableBuilder<String?>(
            valueListenable: svc.speedReport,
            builder: (context, r, _) => r == null
                ? const SizedBox.shrink()
                : Padding(
                    padding: const EdgeInsets.only(bottom: 6),
                    child: Text(
                      r,
                      textAlign: TextAlign.center,
                      style: TextStyle(fontSize: 12, color: alpha(Colors.white, 0.7)),
                    ),
                  ),
          ),
        Row(
          mainAxisAlignment: MainAxisAlignment.end,
          children: [
            ValueListenableBuilder<int>(
              valueListenable: svc.activeStreams,
              // Getting slower? Tap: every stream reconnects fresh.
              builder: (context, n, _) => n > 0
                  ? IconButton(
                      tooltip: 'Refresh speed',
                      icon: const Icon(Icons.refresh),
                      onPressed: () {
                        svc.boostSpeed();
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(
                            content: Text('Connections refreshed'),
                            duration: Duration(seconds: 1),
                          ),
                        );
                      },
                    )
                  : const SizedBox.shrink(),
            ),
            IconButton(
              tooltip: 'Details',
              icon: Icon(_details ? Icons.info : Icons.info_outline),
              onPressed: () => setState(() => _details = !_details),
            ),
          ],
        ),
        if (_details) _linkInfo(),
        TabBar(
          controller: _tabs,
          indicatorColor: kGreen,
          labelColor: Colors.white,
          tabs: [
            _tab('Send', Icons.arrow_upward, svc.sendProgress),
            _tab('Received', Icons.arrow_downward, svc.receiveProgress),
          ],
        ),
        Expanded(
          child: TabBarView(
            controller: _tabs,
            children: [
              _DirectionView(sent: true),
              _DirectionView(sent: false),
            ],
          ),
        ),
      ],
    );
  }
}

class _DirectionView extends StatelessWidget {
  _DirectionView({required this.sent});

  final bool sent;
  final svc = TransferService.instance;

  @override
  Widget build(BuildContext context) {
    final notifier = sent ? svc.sendProgress : svc.receiveProgress;
    return ListView(
      padding: const EdgeInsets.fromLTRB(4, 16, 4, 16),
      children: [
        if (sent)
          ValueListenableBuilder<int>(
            valueListenable: svc.queued,
            builder: (context, q, _) => q > 0
                ? Padding(
                    padding: const EdgeInsets.only(bottom: 8),
                    child: Text('+$q more waiting in line',
                        textAlign: TextAlign.center,
                        style: TextStyle(color: alpha(Colors.white, 0.7))),
                  )
                : const SizedBox.shrink(),
          ),
        ValueListenableBuilder<TransferProgress?>(
          valueListenable: notifier,
          builder: (context, pr, _) => _progressCard(pr),
        ),
        const SizedBox(height: 12),
        _FileList(sent: sent),
        const SizedBox(height: 16),
        Text(
          sent ? 'Recently sent' : 'Recently received',
          style: TextStyle(color: alpha(Colors.white, 0.7)),
        ),
        ValueListenableBuilder<int>(
          valueListenable: HistoryService.instance.changes,
          builder: (context, _, __) {
            final items = HistoryService.instance
                .all()
                .where((e) => e.type == (sent ? 'sent' : 'received'))
                .take(15)
                .toList();
            if (items.isEmpty) {
              return const Padding(
                padding: EdgeInsets.all(16),
                child: Text('Nothing here yet.'),
              );
            }
            return Column(
              children: [
                for (final e in items)
                  ListTile(
                    dense: true,
                    contentPadding: EdgeInsets.zero,
                    leading: Icon(
                      sent ? Icons.north_east : Icons.south_west,
                      color: sent ? kGreen : kBlue,
                    ),
                    title: Text(e.name, maxLines: 1, overflow: TextOverflow.ellipsis),
                    subtitle: Text(formatSize(e.size)),
                    onTap: () => openFileViewer(context, e.path, name: e.name, size: e.size),
                  ),
              ],
            );
          },
        ),
      ],
    );
  }

  Widget _progressCard(TransferProgress? pr) {
    if (pr == null) {
      return Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: kPanel,
          borderRadius: BorderRadius.circular(18),
        ),
        child: Center(
          child: Text(sent ? 'Nothing is being sent.' : 'Nothing is coming in.'),
        ),
      );
    }
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: kPanel,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: alpha(pr.finished ? kGreen : kBlue, 0.6)),
      ),
      child: Column(
        children: [
          if (pr.finished)
            const Icon(Icons.check_circle, size: 72, color: kGreen)
          else
            Text(
              '${(pr.fraction * 100).floor()}%',
              style: const TextStyle(fontSize: 48, fontWeight: FontWeight.w800),
            ),
          const SizedBox(height: 10),
          Builder(builder: (context) {
            // The bar is cut into the chunks of the file that is moving now.
            final list = (sent ? svc.sendList : svc.receiveList).value;
            TransferFileInfo? cur;
            for (final f in list) {
              if (f.state == 'active') {
                cur = f;
                break;
              }
            }
            final ch = pr.finished ? null : cur?.chunks;
            var done = 0;
            if (ch != null) {
              for (final b in ch) {
                if (b == 1) done++;
              }
            }
            return Column(
              children: [
                ChunkBar(chunks: ch, fraction: pr.fraction, height: 18),
                if (ch != null && ch.isNotEmpty)
                  Padding(
                    padding: const EdgeInsets.only(top: 4),
                    child: Text(
                      'Chunks of this file: $done / ${ch.length}',
                      style: TextStyle(fontSize: 12, color: alpha(Colors.white, 0.6)),
                    ),
                  ),
              ],
            );
          }),
          const SizedBox(height: 12),
          Text(
            pr.currentName,
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
            textAlign: TextAlign.center,
            style: const TextStyle(fontWeight: FontWeight.w600),
          ),
          const SizedBox(height: 6),
          Text('File ${pr.fileIndex} of ${pr.fileCount}'),
          Text('${formatSize(pr.doneBytes)} / ${formatSize(pr.totalBytes)}'),
          const SizedBox(height: 6),
          Text(
            'Speed: ${formatSpeed(pr.speed)}',
            style: const TextStyle(
                fontSize: 18, fontWeight: FontWeight.w700, color: kGreen),
          ),
        ],
      ),
    );
  }
}

/// Every file of the running transfer with its own chunk bar. Each file can
/// be paused, continued or cancelled; when one is paused the next one starts.
class _FileList extends StatelessWidget {
  const _FileList({required this.sent});
  final bool sent;

  @override
  Widget build(BuildContext context) {
    final svc = TransferService.instance;
    return ValueListenableBuilder<List<TransferFileInfo>>(
      valueListenable: sent ? svc.sendList : svc.receiveList,
      builder: (context, list, _) {
        if (list.isEmpty) return const SizedBox.shrink();
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.only(left: 4, bottom: 6),
              child: Text(
                'Files (${list.length})',
                style: TextStyle(color: alpha(Colors.white, 0.7)),
              ),
            ),
            for (final f in list) _row(context, svc, f),
          ],
        );
      },
    );
  }

  Widget _row(BuildContext context, TransferService svc, TransferFileInfo f) {
    final live = f.state == 'active' || f.state == 'queued' || f.state == 'paused';
    final Color color = switch (f.state) {
      'done' => kGreen,
      'active' => kBlue,
      'paused' => Colors.orangeAccent,
      'cancelled' => Colors.redAccent,
      _ => Colors.white54,
    };
    final label = switch (f.state) {
      'done' => 'Done',
      'active' => '${(f.fraction * 100).floor()}%',
      'paused' => 'Paused ${(f.fraction * 100).floor()}%',
      'cancelled' => 'Cancelled',
      _ => 'Waiting',
    };
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.fromLTRB(12, 8, 4, 10),
      decoration: BoxDecoration(
        color: kPanel,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: alpha(color, f.state == 'active' ? 0.8 : 0.25)),
      ),
      child: Column(
        children: [
          Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(f.name,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(fontWeight: FontWeight.w600)),
                    Text('${formatSize(f.size)} • $label',
                        style: TextStyle(fontSize: 12, color: color)),
                  ],
                ),
              ),
              if (live) ...[
                IconButton(
                  tooltip: f.state == 'paused' ? 'Continue' : 'Pause',
                  icon: Icon(f.state == 'paused' ? Icons.play_arrow : Icons.pause),
                  onPressed: () => f.state == 'paused'
                      ? svc.resumeFile(sent, f.index)
                      : svc.pauseFile(sent, f.index),
                ),
                IconButton(
                  tooltip: 'Cancel',
                  icon: const Icon(Icons.close),
                  onPressed: () async {
                    final ok = await showDialog<bool>(
                      context: context,
                      builder: (ctx) => AlertDialog(
                        title: const Text('Cancel this file?'),
                        content: Text(f.name),
                        actions: [
                          TextButton(
                              onPressed: () => Navigator.pop(ctx, false),
                              child: const Text('No')),
                          FilledButton(
                              onPressed: () => Navigator.pop(ctx, true),
                              child: const Text('Cancel file')),
                        ],
                      ),
                    );
                    if (ok == true) svc.cancelFile(sent, f.index);
                  },
                ),
              ] else
                Padding(
                  padding: const EdgeInsets.only(right: 12),
                  child: Icon(
                    f.state == 'done' ? Icons.check_circle : Icons.block,
                    color: color,
                  ),
                ),
            ],
          ),
          if (live)
            Padding(
              padding: const EdgeInsets.only(right: 8),
              child: ChunkBar(chunks: f.chunks, fraction: f.fraction, height: 8),
            ),
        ],
      ),
    );
  }
}
