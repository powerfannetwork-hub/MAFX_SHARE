# MAFX SHARE

MAFX SHARE is a Flutter local-network file transfer app. Start from `lib/` and `pubspec.yaml` for application source. `android_overrides/` contains the Android manifest, MainActivity and Gradle compatibility override used by `ci_build.sh` to generate the Android scaffold.

## Build

With Flutter installed and Android SDK/Gradle dependencies available, run:

```bash
./ci_build.sh
```

See `TRANSFER_IMPLEMENTATION_NOTES.md` for transfer-mode settings, implementation details and verification limitations.
