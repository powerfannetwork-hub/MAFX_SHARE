# MAFX SHARE transfer implementation notes

## Changes in this source bundle

- Standard mode target: 4 MiB range/chunk sizing, up to 4 parallel TCP streams, 256 KiB application read buffer, 1 MiB socket-buffer target.
- 5G+ High Speed target: 8 MiB range/chunk sizing, up to 12 parallel TCP streams, 1 MiB application read buffer, 4 MiB socket-buffer target.
- TCP_NODELAY is enabled for file sockets. Parallel stream count is bounded by the amount of work in a file.
- File payloads are streamed from disk. The whole source file is not loaded into RAM.
- Receiver file writes use synchronous position/write pairs without an `await` between them to avoid asynchronous interleaving of the shared RandomAccessFile position.
- The scanning phone now starts a local listener after it has joined the receiver's network and sends its reverse listener ports/token in the pairing request. This allows the paired peer record on both phones to point to the other phone for subsequent sends.
- Pairing navigation returns both devices to Home and transfer screen disposal no longer stops the receiver listener.
- Added the single-file `sendFileTurbo` wrapper, bounded seeking, landscape orientation support and swipe seeking in the media player.
- History cleanup continues to remove records older than 60 days only; it does not delete the referenced files.
- Dependencies updated to the requested mobile_scanner/file_picker constraints and a small transfer-mode test was added.

## Important limitations and verification status

- Dart's public `Socket` API does not expose `SO_SNDBUF` / `SO_RCVBUF` setters. The mode values are documented targets only; native socket-buffer integration has not been implemented in this bundle.
- The existing on-wire TCP protocol remains a JSON stream header followed by a byte range per connection. It has not yet been migrated to the proposed binary `[uint32 chunkIndex][uint32 dataLength][chunk bytes]` frame format. Do not mix this source with a different protocol implementation without matching both endpoints.
- A true Android foreground service has not been added. Reliable receiving while the app is backgrounded depends on Android/device background policy.
- This environment does not have Flutter or Dart installed and has no network access, so `flutter pub get`, `flutter analyze`, Flutter tests, and Android build could not be executed. No real two-device transfer or throughput benchmark was performed.
- Throughput figures are not claimed; the 30–50 MB/s and 100–200 MB/s values are targets only and require real-device measurements.
- The source project supplied does not include a generated `android/` directory or Gradle wrapper. `ci_build.sh` generates an Android scaffold using `flutter create`; the generated Android project/build could not be verified here.
