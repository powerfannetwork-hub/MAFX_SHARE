import 'package:flutter/material.dart';

import '../models.dart';
import '../services/transfer_service.dart';
import '../theme.dart';
import '../widgets/progress_badge.dart';
import '../widgets/rainbow_title.dart';
import '../widgets/selection_bar.dart';
import 'apps_screen.dart';
import 'connect_screen.dart';
import 'files_screen.dart';
import 'history_screen.dart';
import 'images_screen.dart';
import 'music_screen.dart';
import 'send_screen.dart';
import 'settings_screen.dart';
import 'transfer_screen.dart';
import 'videos_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  void _openReceive(BuildContext context) {
    final svc = TransferService.instance;
    final Widget page = svc.isConnected
        ? const TransferScreen(receiving: true)
        : const ConnectScreen(receive: true);
    Navigator.push(context, MaterialPageRoute(builder: (_) => page));
  }

  void _openSend(BuildContext context) {
    final svc = TransferService.instance;
    final Widget page = svc.isConnected
        ? const SendScreen()
        : const ConnectScreen(receive: false);
    Navigator.push(context, MaterialPageRoute(builder: (_) => page));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0xFF282830), kBg, Color(0xFF1A1A22)],
          ),
        ),
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 8),
            child: Column(
              children: [
                const _Header(),
                const SizedBox(height: 16),
                const _StatusPill(),
                const SizedBox(height: 16),
                Expanded(
                  child: Row(
                    children: [
                      Expanded(
                        child: _ActionCard(
                          letter: 'R',
                          title: 'Received',
                          subtitle: 'Ready to receive files',
                          icon: Icons.move_to_inbox_outlined,
                          color: kBlue,
                          onTap: () => _openReceive(context),
                        ),
                      ),
                      const SizedBox(width: 14),
                      Expanded(
                        child: _ActionCard(
                          letter: 'S',
                          title: 'Send',
                          subtitle: 'Select files to transfer',
                          icon: Icons.send_outlined,
                          color: kGreen,
                          showBadge: true,
                          onTap: () => _openSend(context),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 12),
                const SelectionBar(),
                const _InfoPill(),
                const SizedBox(height: 12),
                const _BottomBar(),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// ------------------------------------------------------------------ header

class _Header extends StatelessWidget {
  const _Header();

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(12, 12, 12, 16),
      decoration: BoxDecoration(
        color: const Color(0xFF1B1B21),
        borderRadius: BorderRadius.circular(28),
        border: Border(
          bottom: BorderSide(color: alpha(kBlue, 0.6), width: 1.5),
        ),
      ),
      child: Row(
        children: [
          const SizedBox(width: 52, child: _MenuButton()),
          const Expanded(child: Center(child: RainbowTitle(size: 50))),
          const SizedBox(
            width: 52,
            child: Align(child: ProgressBadge(size: 48)),
          ),
        ],
      ),
    );
  }
}

class _MenuButton extends StatelessWidget {
  const _MenuButton();

  @override
  Widget build(BuildContext context) {
    final colors = [
      kBlue, kBlue, kBlue,
      kBlue, kBlue, kGreen,
      kBlue, kGreen, kGreen,
    ];
    return PopupMenuButton<String>(
      tooltip: 'Menu',
      color: kPanel,
      onSelected: (v) {
        if (v == 'settings') {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => const SettingsScreen()),
          );
        }
      },
      itemBuilder: (_) => const [
        PopupMenuItem<String>(
          value: 'settings',
          child: Row(
            children: [
              Icon(Icons.settings, size: 20),
              SizedBox(width: 12),
              Text('Settings'),
            ],
          ),
        ),
      ],
      child: SizedBox(
        width: 40,
        height: 40,
        child: GridView.count(
          crossAxisCount: 3,
          mainAxisSpacing: 5,
          crossAxisSpacing: 5,
          physics: const NeverScrollableScrollPhysics(),
          children: [
            for (final c in colors)
              DecoratedBox(
                decoration: BoxDecoration(color: c, shape: BoxShape.circle),
              ),
          ],
        ),
      ),
    );
  }
}

// ------------------------------------------------------------------- pills

class _Pill extends StatelessWidget {
  const _Pill({required this.icon, required this.text});
  final IconData icon;
  final String text;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 11),
      decoration: BoxDecoration(
        color: const Color(0xFF1B1B21),
        borderRadius: BorderRadius.circular(30),
        border: Border.all(color: Colors.white24),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, color: kBlue, size: 22),
          const SizedBox(width: 10),
          Flexible(
            child: Text(
              text,
              style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w500),
            ),
          ),
        ],
      ),
    );
  }
}

class _StatusPill extends StatelessWidget {
  const _StatusPill();

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<PairedPeer?>(
      valueListenable: TransferService.instance.pairedPeer,
      builder: (context, peer, _) => _Pill(
        icon: Icons.devices_outlined,
        text: peer == null
            ? 'Not connected • Secure & Private'
            : '2 devices connected • Secure & Private',
      ),
    );
  }
}

class _InfoPill extends StatelessWidget {
  const _InfoPill();

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<PairedPeer?>(
      valueListenable: TransferService.instance.pairedPeer,
      builder: (context, peer, _) => _Pill(
        icon: Icons.info_outline,
        text: peer == null
            ? 'Transfer progress appears once both phones are connected'
            : 'Tap the sync badge to see the transfer progress',
      ),
    );
  }
}

// ------------------------------------------------------------------- cards

class _ActionCard extends StatelessWidget {
  const _ActionCard({
    required this.letter,
    required this.title,
    required this.subtitle,
    required this.icon,
    required this.color,
    required this.onTap,
    this.showBadge = false,
  });

  final String letter;
  final String title;
  final String subtitle;
  final IconData icon;
  final Color color;
  final VoidCallback onTap;
  final bool showBadge;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: const Color(0xFF1B1B21),
          borderRadius: BorderRadius.circular(32),
          border: Border.all(color: alpha(color, 0.6), width: 1.4),
          boxShadow: [BoxShadow(color: alpha(color, 0.3), blurRadius: 24)],
        ),
        child: Column(
          children: [
            Row(
              children: [
                CircleAvatar(
                  radius: 18,
                  backgroundColor: color,
                  child: Text(
                    letter,
                    style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w800,
                      fontSize: 18,
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    title,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      fontSize: 17,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ),
                if (showBadge) const ProgressBadge(size: 36),
              ],
            ),
            Expanded(
              child: Center(child: Icon(icon, color: color, size: 84)),
            ),
            Text(
              title,
              style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w800),
            ),
            const SizedBox(height: 6),
            Text(
              subtitle,
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w500,
                color: alpha(color, 0.85),
              ),
            ),
            const SizedBox(height: 18),
          ],
        ),
      ),
    );
  }
}

// -------------------------------------------------------------- bottom bar

class _BottomBar extends StatelessWidget {
  const _BottomBar();

  @override
  Widget build(BuildContext context) {
    final items = <(String, String, IconData, Widget Function())>[
      ('V', 'Videos', Icons.videocam_outlined, () => const VideosScreen()),
      ('I', 'Images', Icons.image_outlined, () => const ImagesScreen()),
      ('A', 'Apps', Icons.apps, () => const AppsScreen()),
      ('M', 'Music', Icons.music_note_outlined, () => const MusicScreen()),
      ('H', 'History', Icons.history, () => const HistoryScreen()),
      ('F', 'Files', Icons.folder_outlined, () => const FilesScreen()),
    ];
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 10),
      decoration: BoxDecoration(
        color: const Color(0xFF1B1B21),
        borderRadius: BorderRadius.circular(28),
        border: Border.all(color: Colors.white24),
      ),
      child: Row(
        children: [
          for (final it in items)
            Expanded(
              child: GestureDetector(
                behavior: HitTestBehavior.opaque,
                onTap: () => Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => it.$4()),
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      it.$1,
                      style: const TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.w600,
                        color: kBlue,
                      ),
                    ),
                    const SizedBox(height: 6),
                    Icon(it.$3, size: 28),
                    const SizedBox(height: 6),
                    Text(
                      it.$2,
                      style: const TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }
}
