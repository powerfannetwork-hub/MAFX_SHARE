import 'package:flutter/material.dart';
import 'package:qr_flutter/qr_flutter.dart';

import '../models.dart';
import '../services/transfer_service.dart';
import '../theme.dart';
import 'home_screen.dart';

/// Receiver shows this QR code. The sender scans it.
class QrScreen extends StatefulWidget {
  const QrScreen({super.key});

  @override
  State<QrScreen> createState() => _QrScreenState();
}

class _QrScreenState extends State<QrScreen> {
  final svc = TransferService.instance;
  bool _ready = false;
  bool _paired = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    svc.pairedPeer.addListener(_onPaired);
    _start();
  }

  Future<void> _start() async {
    setState(() {
      _error = null;
      _ready = false;
    });
    try {
      await svc.startReceiver();
      if (mounted) setState(() => _ready = true);
    } catch (e) {
      if (mounted) {
        setState(() => _error = e.toString().replaceFirst('Exception: ', ''));
      }
    }
  }

  void _onPaired() {
    if (_paired || svc.pairedPeer.value == null || !mounted) return;
    _paired = true;
    Navigator.pushAndRemoveUntil(
      context,
      MaterialPageRoute(builder: (_) => const HomeScreen()),
      (route) => false,
    );
  }

  @override
  void dispose() {
    svc.pairedPeer.removeListener(_onPaired);
    if (!_paired) svc.stopReceiver();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Scan to connect')),
      body: _error != null
          ? Center(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(_error!, textAlign: TextAlign.center),
                    const SizedBox(height: 16),
                    FilledButton(onPressed: _start, child: const Text('Try again')),
                  ],
                ),
              ),
            )
          : !_ready
              ? const Center(child: CircularProgressIndicator())
              : _content(),
    );
  }

  Widget _content() {
    final m = svc.mode.value;
    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        const Text(
          'On the other phone, tap Send and scan this code.',
          textAlign: TextAlign.center,
        ),
        const SizedBox(height: 16),
        Center(
          child: SegmentedButton<TransferMode>(
            segments: const [
              ButtonSegment(
                value: TransferMode.standard,
                label: Text('Standard'),
              ),
              ButtonSegment(
                value: TransferMode.fiveGPlus,
                label: Text('5G+ (High Speed)'),
              ),
            ],
            selected: {m},
            onSelectionChanged: (s) {
              svc.mode.value = s.first;
              setState(() {});
            },
          ),
        ),
        const SizedBox(height: 20),
        Center(
          child: Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(20),
              boxShadow: [BoxShadow(color: alpha(kBlue, 0.5), blurRadius: 24)],
            ),
            child: QrImageView(
              data: svc.qrPayload(),
              size: 250,
              backgroundColor: Colors.white,
            ),
          ),
        ),
        const SizedBox(height: 20),
        Text(
          'This device: ${svc.localIp}:${svc.httpPort}',
          textAlign: TextAlign.center,
          style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
        ),
        const SizedBox(height: 8),
        Text(
          'Mode: ${m.label} (${m.detail})',
          textAlign: TextAlign.center,
          style: TextStyle(color: alpha(Colors.white, 0.7)),
        ),
        const SizedBox(height: 8),
        const Text(
          'Waiting for the other phone...',
          textAlign: TextAlign.center,
        ),
      ],
    );
  }
}
