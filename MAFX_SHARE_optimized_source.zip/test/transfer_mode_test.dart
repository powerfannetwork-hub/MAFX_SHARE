import 'package:flutter_test/flutter_test.dart';
import 'package:share/models.dart';

void main() {
  group('Transfer mode targets', () {
    test('Standard uses balanced defaults', () {
      final mode = TransferMode.standard;
      expect(mode.chunkSize, 4 * 1024 * 1024);
      expect(mode.streams, 4);
      expect(mode.applicationBuffer, 256 * 1024);
      expect(mode.socketBufferTarget, 1024 * 1024);
    });

    test('5G+ uses high-speed defaults', () {
      final mode = TransferMode.fiveGPlus;
      expect(mode.chunkSize, 8 * 1024 * 1024);
      expect(mode.streams, 12);
      expect(mode.applicationBuffer, 1024 * 1024);
      expect(mode.socketBufferTarget, 4 * 1024 * 1024);
    });

    test('unknown wire mode safely falls back to Standard', () {
      expect(TransferMode.parse('unknown'), TransferMode.standard);
    });
  });
}
