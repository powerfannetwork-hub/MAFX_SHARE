import 'package:flutter_test/flutter_test.dart';
import 'package:share/models.dart';

void main() {
  test('preferred profile uses high-throughput chunks with bounded memory', () {
    const m = TransferMode.turbo;
    expect(m.chunkSize, 16 * 1024 * 1024);
    expect(m.streams, 4);
    expect(m.maxStreams, 16);
    expect(m.bufferSize, 1024 * 1024);
    expect(m.socketBuffer, 4 * 1024 * 1024);
  });

  test('streams can grow beyond the start count', () {
    for (final m in TransferMode.all) {
      expect(m.maxStreams, greaterThanOrEqualTo(m.streams));
    }
    expect(TransferMode.ultra.maxStreams, 24);
    expect(TransferMode.safe.streams, 2);
    expect(TransferMode.safe.maxStreams, 4);
  });

  test('weak phones fall back to smaller profiles', () {
    expect(
      TransferMode.forDevice(memoryClassMb: 512, totalMemMb: 8000, lowRam: false, cores: 8),
      TransferMode.ultra,
    );
    expect(
      TransferMode.forDevice(memoryClassMb: 256, totalMemMb: 5000, lowRam: false, cores: 8),
      TransferMode.turbo,
    );
    expect(
      TransferMode.forDevice(memoryClassMb: 192, totalMemMb: 3500, lowRam: false, cores: 8),
      TransferMode.balanced,
    );
    expect(
      TransferMode.forDevice(memoryClassMb: 512, totalMemMb: 8000, lowRam: true, cores: 8),
      TransferMode.safe,
    );
  });

  test('two phones use the slower profile; old wire names still parse', () {
    expect(TransferMode.lower(TransferMode.turbo, TransferMode.safe), TransferMode.safe);
    expect(TransferMode.parse('5g_plus'), TransferMode.legacy);
    expect(TransferMode.parse('turbo24'), TransferMode.turbo);
  });
}
