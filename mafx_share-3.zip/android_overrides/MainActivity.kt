package com.mafx.share

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.Drawable
import android.net.Uri
import android.provider.Settings
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import java.io.ByteArrayOutputStream
import java.util.concurrent.Executors

class MainActivity : FlutterActivity() {
    private val channelName = "com.mafx.share/apps"
    private val executor = Executors.newSingleThreadExecutor()

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, channelName)
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    "listApps" -> {
                        executor.execute {
                            try {
                                val apps = listApps()
                                runOnUiThread { result.success(apps) }
                            } catch (e: Exception) {
                                runOnUiThread { result.error("LIST_FAILED", e.message, null) }
                            }
                        }
                    }
                    "openApp" -> {
                        val pkg = call.argument<String>("package")
                        val launch = if (pkg != null) packageManager.getLaunchIntentForPackage(pkg) else null
                        if (launch != null) {
                            launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            startActivity(launch)
                            result.success(true)
                        } else {
                            result.success(false)
                        }
                    }
                    "uninstallApp" -> {
                        val pkg = call.argument<String>("package")
                        if (pkg != null) {
                            val intent = Intent(Intent.ACTION_DELETE, Uri.parse("package:" + pkg))
                            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            startActivity(intent)
                            result.success(true)
                        } else {
                            result.success(false)
                        }
                    }
                    "openWifiSettings" -> {
                        result.success(openFirstWorking(listOf(Intent(Settings.ACTION_WIFI_SETTINGS))))
                    }
                    "openHotspotSettings" -> {
                        val attempts = listOf(
                            Intent().setClassName("com.android.settings", "com.android.settings.TetherSettings"),
                            Intent("android.settings.TETHER_SETTINGS"),
                            Intent().setClassName("com.android.settings", "com.android.settings.Settings\$TetherSettingsActivity"),
                            Intent(Settings.ACTION_WIRELESS_SETTINGS)
                        )
                        result.success(openFirstWorking(attempts))
                    }
                    else -> result.notImplemented()
                }
            }
    }

    private fun openFirstWorking(intents: List<Intent>): Boolean {
        for (intent in intents) {
            try {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(intent)
                return true
            } catch (e: Exception) {
                // try the next one
            }
        }
        return false
    }

    private fun listApps(): List<Map<String, Any?>> {
        val pm = packageManager
        val query = Intent(Intent.ACTION_MAIN, null)
        query.addCategory(Intent.CATEGORY_LAUNCHER)
        val resolved = pm.queryIntentActivities(query, 0)
        val seen = HashSet<String>()
        val out = ArrayList<Map<String, Any?>>()
        for (ri in resolved) {
            val pkg: String = ri.activityInfo?.packageName ?: continue
            if (!seen.add(pkg)) continue
            val label = ri.loadLabel(pm).toString()
            val icon = drawableToPng(ri.loadIcon(pm))
            out.add(mapOf("name" to label, "package" to pkg, "icon" to icon))
        }
        out.sortBy { (it["name"] as String).lowercase() }
        return out
    }

    private fun drawableToPng(d: Drawable): ByteArray {
        val size = 96
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        d.setBounds(0, 0, size, size)
        d.draw(canvas)
        val bos = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.PNG, 100, bos)
        return bos.toByteArray()
    }
}
