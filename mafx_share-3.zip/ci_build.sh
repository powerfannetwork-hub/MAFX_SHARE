#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"

# 1) Android project with package com.mafx.share
flutter create --org com.mafx --project-name share --platforms=android build_app
cp pubspec.yaml build_app/pubspec.yaml
rm -rf build_app/lib build_app/test
cp -r lib build_app/lib
cp android_overrides/AndroidManifest.xml build_app/android/app/src/main/AndroidManifest.xml
find build_app/android/app/src/main \( -name 'MainActivity.kt' -o -name 'MainActivity.java' \) -delete
mkdir -p build_app/android/app/src/main/kotlin/com/mafx/share
cp android_overrides/MainActivity.kt build_app/android/app/src/main/kotlin/com/mafx/share/MainActivity.kt

# 2) Force compileSdk 36 on all modules (fixes the file_picker error)
mkdir -p "$HOME/.gradle/init.d"
cp android_overrides/force-sdk36.gradle "$HOME/.gradle/init.d/force-sdk36.gradle"

cd build_app
flutter pub get

# 3) Belt and braces: also patch the plugin files directly
PUB="${PUB_CACHE:-$HOME/.pub-cache}"
for f in "$PUB"/hosted/pub.dev/*/android/build.gradle "$PUB"/hosted/pub.dev/*/android/build.gradle.kts; do
  [ -f "$f" ] || continue
  if grep -Eq 'compileSdk(Version)?[ =]+[0-9]+' "$f"; then
    sed -i -E 's/(compileSdk(Version)?[ =]+)[0-9]+/\136/' "$f"
    echo "patched $f"
  fi
done

# 4) Build
flutter build apk --release
