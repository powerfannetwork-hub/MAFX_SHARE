enum TransferMode {
  standard('standard', 'Standard', 1048576, 1),
  fiveGPlus('5g_plus', '5G+ High Speed', 4194304, 6);

  const TransferMode(this.wire, this.label, this.chunkSize, this.streams);

  final String wire;
  final String label;
  final int chunkSize;
  final int streams;

  String get detail =>
      '$streams ${streams == 1 ? 'stream' : 'streams'} · ${chunkSize ~/ 1048576} MB chunks';

  static TransferMode parse(String? s) => TransferMode.values.firstWhere(
        (m) => m.wire == s,
        orElse: () => TransferMode.standard,
      );
}

class PairedPeer {
  const PairedPeer({
    required this.ip,
    required this.port,
    required this.tcpPort,
    required this.token,
    required this.mode,
  });

  final String ip;
  final int port;
  final int tcpPort;
  final String token;
  final TransferMode mode;
}

class PendingFile {
  const PendingFile({
    required this.id,
    required this.path,
    required this.name,
    required this.size,
  });

  final String id;
  final String path;
  final String name;
  final int size;
}

class TransferProgress {
  const TransferProgress({
    required this.direction,
    required this.currentName,
    required this.fileIndex,
    required this.fileCount,
    required this.doneBytes,
    required this.totalBytes,
    required this.speed,
    required this.mode,
    required this.finished,
  });

  final String direction; // 'sent' or 'received'
  final String currentName;
  final int fileIndex;
  final int fileCount;
  final int doneBytes;
  final int totalBytes;
  final double speed;
  final TransferMode mode;
  final bool finished;

  double get fraction {
    if (totalBytes <= 0) return finished ? 1.0 : 0.0;
    return (doneBytes / totalBytes).clamp(0.0, 1.0).toDouble();
  }
}

class HistoryEntry {
  const HistoryEntry({
    required this.key,
    required this.name,
    required this.size,
    required this.date,
    required this.type,
    required this.path,
  });

  final dynamic key;
  final String name;
  final int size;
  final DateTime date;
  final String type; // 'sent' or 'received'
  final String path;
}
