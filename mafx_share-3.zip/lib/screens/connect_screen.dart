import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:permission_handler/permission_handler.dart';

import '../services/transfer_service.dart';
import '../theme.dart';
import 'qr_screen.dart';
import 'scan_qr_screen.dart';

/// Step between Home and the QR screens:
/// permissions -> WiFi / Hotspot check -> (open Settings if needed) -> QR.
class ConnectScreen extends StatefulWidget {
  const ConnectScreen({super.key, required this.receive});

  /// true = Received (show QR), false = Send (scan QR).
  final bool receive;

  @override
  State<ConnectScreen> createState() => _ConnectScreenState();
}

class _ConnectScreenState extends State<ConnectScreen>
    with WidgetsBindingObserver {
  static const MethodChannel _sys = MethodChannel('com.mafx.share/apps');

  String _status = 'Requesting permissions...';
  bool _denied = false;
  bool _needNetwork = false;
  bool _navigated = false;
  bool _checking = false;
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    WidgetsBinding.instance.addPostFrameCallback((_) => _run());
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _timer?.cancel();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    // Coming back from Settings: check again and continue by itself.
    if (state == AppLifecycleState.resumed && _needNetwork) {
      _checkNetwork();
    }
  }

  Future<void> _run() async {
    setState(() {
      _denied = false;
      _needNetwork = false;
      _status = 'Requesting permissions...';
    });
    final result = await [
      Permission.camera,
      Permission.locationWhenInUse,
      Permission.nearbyWifiDevices,
    ].request();
    if (!mounted) return;

    final cameraOk = result[Permission.camera]?.isGranted ?? false;
    if (!widget.receive && !cameraOk) {
      setState(() {
        _denied = true;
        _status = 'Camera permission is needed to scan the QR code.';
      });
      return;
    }

    setState(() => _status = 'Checking WiFi / Hotspot...');
    await _checkNetwork();
  }

  Future<void> _checkNetwork() async {
    if (_checking || _navigated) return;
    _checking = true;
    try {
      final ip = await TransferService.instance.getLocalIp();
      if (!mounted || _navigated) return;
      if (ip != null) {
        _go();
        return;
      }
      if (!_needNetwork) setState(() => _needNetwork = true);
      _timer ??= Timer.periodic(
        const Duration(seconds: 2),
        (_) => _checkNetwork(),
      );
    } finally {
      _checking = false;
    }
  }

  void _go() {
    _navigated = true;
    _timer?.cancel();
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (_) =>
            widget.receive ? const QrScreen() : const ScanQrScreen(),
      ),
    );
  }

  Future<void> _open(String method) async {
    var ok = false;
    try {
      ok = (await _sys.invokeMethod<bool>(method)) ?? false;
    } catch (_) {}
    if (!ok && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Could not open Settings. Please open it yourself.')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.receive ? 'Received' : 'Send')),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: _needNetwork ? _networkPanel() : _statusPanel(),
        ),
      ),
    );
  }

  Widget _statusPanel() {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        if (!_denied) const CircularProgressIndicator(),
        const SizedBox(height: 20),
        Text(_status, textAlign: TextAlign.center),
        if (_denied) ...[
          const SizedBox(height: 16),
          FilledButton(onPressed: _run, child: const Text('Try again')),
          TextButton(
            onPressed: openAppSettings,
            child: const Text('Open app settings'),
          ),
        ],
      ],
    );
  }

  Widget _networkPanel() {
    final hotspotBtn = widget.receive
        ? FilledButton.icon(
            onPressed: () => _open('openHotspotSettings'),
            icon: const Icon(Icons.wifi_tethering),
            label: const Text('Open Hotspot settings'),
          )
        : OutlinedButton.icon(
            onPressed: () => _open('openHotspotSettings'),
            icon: const Icon(Icons.wifi_tethering),
            label: const Text('Open Hotspot settings'),
          );
    final wifiBtn = widget.receive
        ? OutlinedButton.icon(
            onPressed: () => _open('openWifiSettings'),
            icon: const Icon(Icons.wifi),
            label: const Text('Open WiFi settings'),
          )
        : FilledButton.icon(
            onPressed: () => _open('openWifiSettings'),
            icon: const Icon(Icons.wifi),
            label: const Text('Open WiFi settings'),
          );

    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        const Icon(Icons.wifi_off, size: 72, color: kGreen),
        const SizedBox(height: 16),
        const Text(
          'Turn on WiFi or Hotspot',
          textAlign: TextAlign.center,
          style: TextStyle(fontSize: 22, fontWeight: FontWeight.w700),
        ),
        const SizedBox(height: 8),
        Text(
          widget.receive
              ? 'Turn on your Hotspot (or connect to a WiFi network). The other phone must join the same network.'
              : 'Connect to the same WiFi, or to the other phone\'s Hotspot.',
          textAlign: TextAlign.center,
        ),
        const SizedBox(height: 24),
        if (widget.receive) ...[hotspotBtn, const SizedBox(height: 10), wifiBtn]
        else ...[wifiBtn, const SizedBox(height: 10), hotspotBtn],
        const SizedBox(height: 16),
        Text(
          'After you turn it on, come back to this app. It continues by itself.',
          textAlign: TextAlign.center,
          style: TextStyle(color: alpha(Colors.white, 0.7)),
        ),
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('Cancel'),
        ),
      ],
    );
  }
}
