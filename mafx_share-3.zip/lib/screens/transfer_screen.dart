import 'package:flutter/material.dart';

import '../models.dart';
import '../services/selection_service.dart';
import '../services/transfer_service.dart';
import '../theme.dart';

/// Shows speed, file name and percentage while files move between phones.
///
/// - files != null : starts sending those files
/// - receiving     : receiver side, waits for incoming files
/// - neither       : just shows the current progress
class TransferScreen extends StatefulWidget {
  const TransferScreen({super.key, this.files, this.receiving = false});

  final List<PendingFile>? files;
  final bool receiving;

  @override
  State<TransferScreen> createState() => _TransferScreenState();
}

class _TransferScreenState extends State<TransferScreen> {
  final svc = TransferService.instance;
  String? _error;

  @override
  void initState() {
    super.initState();
    if (widget.files != null) _send();
  }

  Future<void> _send() async {
    try {
      await svc.sendFiles(widget.files!);
      SelectionService.instance.clear();
    } catch (e) {
      if (mounted) {
        setState(() => _error = e.toString().replaceFirst('Exception: ', ''));
      }
    }
  }

  @override
  void dispose() {
    if (widget.receiving) svc.stopReceiver();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.receiving ? 'Receiving' : 'Transfer'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: ValueListenableBuilder<TransferProgress?>(
          valueListenable: svc.progress,
          builder: (context, pr, _) {
            final m = svc.mode.value;
            return Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: kPanel,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: alpha(kBlue, 0.6)),
                  ),
                  child: Text(
                    'Mode: ${m.label}\n${m.detail}',
                    textAlign: TextAlign.center,
                  ),
                ),
                const Spacer(),
                if (_error != null) ...[
                  const Icon(Icons.error_outline, size: 72, color: Colors.redAccent),
                  const SizedBox(height: 12),
                  Text(_error!, textAlign: TextAlign.center),
                ] else if (pr == null) ...[
                  const Center(child: CircularProgressIndicator()),
                  const SizedBox(height: 16),
                  Text(
                    widget.receiving
                        ? 'Connected. Waiting for files from the other phone...'
                        : 'Preparing...',
                    textAlign: TextAlign.center,
                  ),
                ] else ...[
                  Text(
                    pr.finished
                        ? 'Done'
                        : '${(pr.fraction * 100).toStringAsFixed(0)}%',
                    textAlign: TextAlign.center,
                    style: const TextStyle(fontSize: 64, fontWeight: FontWeight.w800),
                  ),
                  const SizedBox(height: 16),
                  ClipRRect(
                    borderRadius: BorderRadius.circular(8),
                    child: LinearProgressIndicator(
                      value: pr.fraction,
                      minHeight: 12,
                      color: kGreen,
                      backgroundColor: kPanel,
                    ),
                  ),
                  const SizedBox(height: 20),
                  Text(
                    pr.currentName,
                    textAlign: TextAlign.center,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'File ${pr.fileIndex} of ${pr.fileCount} • ${pr.direction == 'sent' ? 'sending' : 'receiving'}',
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 8),
                  Text(
                    '${formatSize(pr.doneBytes)} / ${formatSize(pr.totalBytes)}',
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'Speed: ${formatSpeed(pr.speed)}',
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.w700,
                      color: kGreen,
                    ),
                  ),
                ],
                const Spacer(),
                if (_error != null || (pr != null && pr.finished))
                  FilledButton(
                    onPressed: () => Navigator.pop(context),
                    child: const Text('Done'),
                  ),
              ],
            );
          },
        ),
      ),
    );
  }
}
