import 'dart:io';

import 'package:flutter/material.dart';
import 'package:path/path.dart' as p;
import 'package:video_player/video_player.dart';

import '../theme.dart';

const _videoExt = {'.mp4', '.mkv', '.3gp', '.webm', '.mov', '.avi', '.m4v'};
const _audioExt = {'.mp3', '.m4a', '.aac', '.wav', '.ogg', '.flac', '.opus', '.amr'};
const _imageExt = {'.jpg', '.jpeg', '.png', '.gif', '.webp', '.bmp'};

/// Opens a file inside the app (video / music player or image viewer).
void openFileViewer(BuildContext context, String path) {
  final ext = p.extension(path).toLowerCase();
  Widget? page;
  if (_videoExt.contains(ext)) {
    page = PlayerScreen(path: path);
  } else if (_audioExt.contains(ext)) {
    page = PlayerScreen(path: path, audio: true);
  } else if (_imageExt.contains(ext)) {
    page = ImageViewerScreen(path: path);
  }
  if (page == null) {
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(
        const SnackBar(content: Text('This file type cannot be opened here.')),
      );
    return;
  }
  final target = page;
  Navigator.push(context, MaterialPageRoute(builder: (_) => target));
}

class PlayerScreen extends StatefulWidget {
  const PlayerScreen({super.key, required this.path, this.audio = false});

  final String path;
  final bool audio;

  @override
  State<PlayerScreen> createState() => _PlayerScreenState();
}

class _PlayerScreenState extends State<PlayerScreen> {
  late final VideoPlayerController _c =
      VideoPlayerController.file(File(widget.path));
  bool _ready = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<void> _init() async {
    try {
      await _c.initialize();
      if (!mounted) return;
      setState(() => _ready = true);
      await _c.play();
    } catch (_) {
      if (mounted) setState(() => _error = 'This file cannot be played.');
    }
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          p.basename(widget.path),
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
        ),
      ),
      body: _error != null
          ? Center(child: Text(_error!))
          : !_ready
              ? const Center(child: CircularProgressIndicator())
              : Column(
                  children: [
                    Expanded(
                      child: Center(
                        child: widget.audio
                            ? Icon(Icons.music_note, size: 120, color: alpha(kBlue, 0.9))
                            : AspectRatio(
                                aspectRatio: _c.value.aspectRatio,
                                child: VideoPlayer(_c),
                              ),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      child: VideoProgressIndicator(
                        _c,
                        allowScrubbing: true,
                        colors: const VideoProgressColors(
                          playedColor: kGreen,
                          bufferedColor: kPanel,
                          backgroundColor: kPanel,
                        ),
                      ),
                    ),
                    ValueListenableBuilder<VideoPlayerValue>(
                      valueListenable: _c,
                      builder: (context, v, _) => Padding(
                        padding: const EdgeInsets.all(16),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            IconButton(
                              iconSize: 36,
                              icon: const Icon(Icons.replay_10),
                              onPressed: () => _c.seekTo(
                                v.position - const Duration(seconds: 10),
                              ),
                            ),
                            const SizedBox(width: 12),
                            IconButton.filled(
                              iconSize: 44,
                              icon: Icon(v.isPlaying ? Icons.pause : Icons.play_arrow),
                              onPressed: () =>
                                  v.isPlaying ? _c.pause() : _c.play(),
                            ),
                            const SizedBox(width: 12),
                            IconButton(
                              iconSize: 36,
                              icon: const Icon(Icons.forward_10),
                              onPressed: () => _c.seekTo(
                                v.position + const Duration(seconds: 10),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
    );
  }
}

class ImageViewerScreen extends StatelessWidget {
  const ImageViewerScreen({super.key, required this.path});
  final String path;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        title: Text(
          p.basename(path),
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
        ),
      ),
      body: InteractiveViewer(
        maxScale: 6,
        child: Center(child: Image.file(File(path))),
      ),
    );
  }
}
