# MAFX SHARE (v1.1.0)

Fast offline file sharing between Android phones (Flutter + Kotlin).
This version extends the existing app; nothing from the old version was removed
(transfer engine, QR pairing, Wi-Fi Direct / hotspot, resume, history, themes).

## Build

The project keeps only `lib/`, `test/`, `pubspec.yaml` and `android_overrides/`.
`ci_build.sh` creates the Android project with `flutter create` (package
`com.mafx.share`), copies everything in, and builds the release APK.

```bash
# needs Flutter (stable), JDK 17, Android SDK
./ci_build.sh
# APK: build_app/build/app/outputs/flutter-apk/app-release.apk
```

GitHub Actions: commit this zip to the root of the repository (the existing
`.github/workflows/build.yml` unpacks the newest zip and runs `ci_build.sh`).
`ci_build.sh` now also runs `flutter analyze` and `flutter test`; their result is
printed in the log and does not stop the APK build.

Manual commands (inside `build_app/` after `ci_build.sh` ran once):
`flutter clean && flutter pub get && flutter analyze && flutter test && flutter build apk --release --no-shrink`

## What is new

| Area | Where |
|---|---|
| Music player (play/pause, next/prev, auto-next, shuffle, repeat off/all/one, seek, speed 0.5-2x, queue, playlists, search, sorting, artwork, background playback, notification + lock-screen controls) | `lib/services/music_service.dart`, `lib/screens/music/`, `lib/widgets/mini_player.dart` |
| Equalizer (real Android `Equalizer`, `LoudnessEnhancer`, `BassBoost`; 11 presets, custom bands, bass, treble, reset, save/delete presets, restore previous) | `lib/services/equalizer_service.dart`, `lib/screens/music/equalizer_screen.dart` |
| Video player (MX-style gestures, brightness/volume swipes, double-tap ±10 s, speed, lock, fullscreen, rotation, picture size, SRT subtitles + delay, resume, info) | `lib/screens/video_player_screen.dart`, `lib/services/subtitle.dart` |
| Settings → VIDEO & AUDIO TOOLS (Video Cutter, MP3 Cutter, Video to MP3, Image Crop) | `lib/screens/tools/`, `android_overrides/MediaTools.kt` |
| Media browser (History, Apps, Photos, Videos, Music, Files; search, 8 sort modes, list/grid remembered, multi-select, select all, share, delete with confirmation, details) | `lib/widgets/media_browser.dart` |
| Public storage (MediaStore) | `MediaTools.kt` (`publishFile`), `StorageService.publish`, `TransferService._completeFile` |
| Adaptive transfer profiles | `lib/models.dart` (`TransferMode`), `lib/main.dart` |

### Public storage
Received files go to a safe temporary folder first (partial files, resume,
random-access writes are unchanged). Only after a complete transfer with the
expected size is the file copied to MediaStore and the temporary copy removed:
Pictures/MAFX SHARE, Movies/MAFX SHARE, Music/MAFX SHARE, Download/MAFX SHARE
(Android 10+ via MediaStore; Android 9 and older write to the public folder and
trigger a media scan). History stores the `content://` URI; open, share, delete
and the existence check handle both URIs and plain paths (`lib/services/file_ops.dart`).
If the SD card is selected in Settings, files stay on the card (no publishing).
If publishing fails the file simply stays in the temporary folder.

### Transfer profiles
The profile is chosen automatically from RAM, cores and the low-RAM flag:

| Profile | Chunk | Profile streams (start = 1/3, min 4) | May grow to | App buffer | Socket buffer |
|---|---|---|---|---|---|
| Ultra (7 GB+ RAM, 8+ cores) | 16 MiB | 32 | 64 | 2 MiB | 8 MiB |
| Turbo | 16 MiB | 24 | 48 | 2 MiB | 8 MiB |
| Balanced | 8 MiB | 12 | 24 | 1 MiB | 4 MiB |
| Safe (weak / low-RAM phones) | 4 MiB | 6 | 12 | 512 KiB | 2 MiB |

While sending, the watchdog adds streams (+50% per step) only as long as the measured speed
improves by 10% or more, and goes back to the best count when it stops growing (more streams
are not always faster; the Wi-Fi link is the real limit). When two phones connect the slower
profile of the two is used and the receiver caps its buffer to its own profile.
Older app versions (`5g_plus`) still connect. No speed numbers are claimed: nothing was benchmarked.

### Connectivity (changes)
* Wi-Fi Direct 5 GHz group: one automatic retry when Android answers BUSY / ERROR, then the
  existing fallback to the local-only hotspot (unchanged).
* Wi-Fi locks: HIGH_PERF (Android 13 and older) plus LOW_LATENCY (Android 10+) are both held
  during a transfer, together with the wake lock and foreground service (unchanged).
* Settings → Transfer engine shows the profile and links to the battery-optimisation screen.

### v1.2.0 additions
* **Automatic 5 GHz:** no manual network choice any more. The QR screen starts a 5 GHz Wi-Fi Direct
  group by itself (tries the 5 GHz band, then channel 36, then channel 149); if the phone cannot, it
  falls back to the normal hotspot and shows WHY 5 GHz was not possible. Button "Use my Wi-Fi" remains.
* **Chunks:** every file gets its own chunk size (about 3 chunks per stream, 1 MiB to 16 MiB), so more
  chunks and all streams busy even for small files. Resume still works (the chunk map is converted).
* **Chunk bars:** the progress bar and every file row are cut into chunk pieces (green = arrived,
  blue = on its way, dark = waiting) on BOTH phones.
* **Per-file queue:** files go one after another; each file can be paused, continued or cancelled from
  either phone; when one is paused the next starts at once.
* **Continue on both phones:** after a broken link both phones ask "Continue?"; sending starts when both
  pressed it.
* **Battery check** is part of the connect checklist (like Bluetooth).
* **Share from other apps:** file manager, MX Player, gallery ... "Share -> MAFX SHARE" adds the files,
  opens the connect screen and sends by itself after pairing.
* **One permission:** "Allow access to all files" (Android 11+) at first start; the Files tab then becomes a
  real file manager of the whole storage. Android still shows its own questions for Wi-Fi/Location and
  notifications; they are asked together once. Note: Google Play restricts this permission.

### v1.3.0 additions
* **Up to 5 phones:** the host (the phone that shows the QR code) plus up to 4 guests. Home shows
  "Connected phones N / 5"; the host has an "Add phone" button (shows the QR code again). The host sends
  the list of phones to every guest, so every phone can send to every other phone (guest-to-guest needs a
  network that allows phones to talk to each other; if not, the send says the phone is not reachable).
* **Every phone sends and receives:** both directions run at the same time on each phone. A phone receives
  from one sender at a time; a second sender waits in line automatically ("the other phone is receiving
  from another phone") and starts when the first one is done.
* **Send to several phones:** pressing SEND with more than one phone connected asks "Send to": all or chosen
  phones; the files go to them one after another.
* **Screen stays on** while a transfer screen is open (keeps Wi-Fi at full speed).
* **Speed report** after each send: average, peak, streams used, profile.
* The group has a single QR / network (5 GHz Wi-Fi Direct when the host phone supports it).

### Tools (native `MediaExtractor` / `MediaMuxer` / `MediaCodec`, no extra packages)
* Video Cutter: lossless stream copy, starts at the key frame at/before the start time.
* MP3 Cutter: MP3 stays MP3 (frames copied), AAC/M4A stays M4A, anything else becomes WAV.
* Video to MP3: result is `.mp3` only if the video's audio already is MP3; otherwise
  `.m4a` (AAC, lossless) or `.wav`. Android cannot create new MP3 files natively.
* Image Crop: crop (free / 1:1 / 4:3 / 3:4 / 16:9 / 9:16), rotate, preview, save PNG or JPG.

## Not changed / limits
* Home screen: kept exactly as it was (only the mini music player was added above the info pill).
* QR pairing, hotspot logic and the foreground service are unchanged.
* Integrity check = per-chunk length + final file size. There is still no cryptographic hash.
* Subtitles: SRT only. Only one audio engine (just_audio) is used for the music player;
  tool previews use `video_player`.

## Test status (honest)
Written in an environment without Flutter/Android SDK or internet: **nothing was compiled,
analyzed, or run on a device**. Unit tests were added (`test/`: SRT parser, equalizer maths,
sorting, transfer profiles, existing chunk codec) but were not executed.
Please run `./ci_build.sh`, read the `flutter analyze` / `flutter test` output, and test on two
phones: transfer + resume, media visibility in Gallery/Files, background music, the four tools.

### Stream auto-tuning (v1.3.1)
A send starts with 1/3 of the profile's streams (at least 4) and adds streams (+50% per 2.5 s step) only
while the measured speed grows by 6% or more; when it stops growing it goes back to the best count.
Reason: too many TCP streams on one Wi-Fi link can be slower, especially on weaker phones. After each send the
panel shows the average and peak speed, the band (5 GHz / 2.4 GHz) and the streams used.
