package com.mafx.share

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.wifi.WifiManager
import android.net.wifi.WifiNetworkSpecifier
import android.os.Build
import android.os.Handler
import android.os.Looper
import java.net.Inet4Address
import java.net.NetworkInterface
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.Drawable
import android.net.Uri
import android.provider.Settings
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import java.io.ByteArrayOutputStream
import java.util.concurrent.Executors

class MainActivity : FlutterActivity() {
    private val channelName = "com.mafx.share/apps"
    private val executor = Executors.newSingleThreadExecutor()
    private var hotspotReservation: WifiManager.LocalOnlyHotspotReservation? = null
    private var netCallback: ConnectivityManager.NetworkCallback? = null

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, channelName)
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    "listApps" -> {
                        executor.execute {
                            try {
                                val apps = listApps()
                                runOnUiThread { result.success(apps) }
                            } catch (e: Exception) {
                                runOnUiThread { result.error("LIST_FAILED", e.message, null) }
                            }
                        }
                    }
                    "openApp" -> {
                        val pkg = call.argument<String>("package")
                        val launch = if (pkg != null) packageManager.getLaunchIntentForPackage(pkg) else null
                        if (launch != null) {
                            launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            startActivity(launch)
                            result.success(true)
                        } else {
                            result.success(false)
                        }
                    }
                    "uninstallApp" -> {
                        val pkg = call.argument<String>("package")
                        if (pkg != null) {
                            val intent = Intent(Intent.ACTION_DELETE, Uri.parse("package:" + pkg))
                            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            startActivity(intent)
                            result.success(true)
                        } else {
                            result.success(false)
                        }
                    }
                    "openWifiSettings" -> {
                        result.success(openFirstWorking(listOf(Intent(Settings.ACTION_WIFI_SETTINGS))))
                    }
                    "openHotspotSettings" -> {
                        val attempts = listOf(
                            Intent().setClassName("com.android.settings", "com.android.settings.TetherSettings"),
                            Intent("android.settings.TETHER_SETTINGS"),
                            Intent().setClassName("com.android.settings", "com.android.settings.Settings\$TetherSettingsActivity"),
                            Intent(Settings.ACTION_WIRELESS_SETTINGS)
                        )
                        result.success(openFirstWorking(attempts))
                    }
                    "openWifiPanel" -> {
                        // Small Wi-Fi pop-up with an on/off switch (Android 11+), like Xender.
                        val attempts = ArrayList<Intent>()
                        if (Build.VERSION.SDK_INT >= 30) attempts.add(Intent(Settings.Panel.ACTION_WIFI))
                        if (Build.VERSION.SDK_INT >= 29) attempts.add(Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY))
                        attempts.add(Intent(Settings.ACTION_WIFI_SETTINGS))
                        result.success(openFirstWorking(attempts))
                    }
                    "openBluetoothSettings" -> {
                        result.success(openFirstWorking(listOf(Intent(Settings.ACTION_BLUETOOTH_SETTINGS))))
                    }
                    "wifiLinkInfo" -> result.success(wifiLinkInfo())
                    "bindToWifi" -> result.success(bindToWifi())
                    "isWifiOn" -> result.success(isWifiOn())
                    "isBluetoothOn" -> result.success(isBluetoothOn())
                    "isHotspotOn" -> result.success(isHotspotOn())
                    "turnOffBluetooth" -> result.success(turnOffBluetooth())
                    "startHotspot" -> startHotspot(result)
                    "stopHotspot" -> {
                        stopHotspot()
                        result.success(true)
                    }
                    "connectToWifi" -> {
                        val ssid = call.argument<String>("ssid")
                        val pass = call.argument<String>("password")
                        if (ssid == null) result.success(false) else connectToWifi(ssid, pass, result)
                    }
                    "releaseWifi" -> {
                        releaseWifi()
                        result.success(true)
                    }
                    "startKeepAlive" -> {
                        result.success(startKeepAlive(call.argument<String>("text") ?: "Connected"))
                    }
                    "updateKeepAlive" -> {
                        result.success(startKeepAlive(call.argument<String>("text") ?: "Connected"))
                    }
                    "stopKeepAlive" -> {
                        stopKeepAlive()
                        result.success(true)
                    }
                    "moveToBack" -> {
                        // Hide the app (do not close it) so the connection survives.
                        result.success(moveTaskToBack(true))
                    }
                    else -> result.notImplemented()
                }
            }
    }


    // ---------------------------------------------------------------- status

    private fun isWifiOn(): Boolean {
        return try {
            (applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager).isWifiEnabled
        } catch (e: Exception) {
            false
        }
    }

    // Use the Wi-Fi network (even without internet) for this app's traffic.
    @Suppress("DEPRECATION")
    private fun bindToWifi(): Boolean {
        var ok = false
        try {
            val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as android.net.ConnectivityManager
            for (n in cm.allNetworks) {
                val caps = cm.getNetworkCapabilities(n) ?: continue
                if (caps.hasTransport(android.net.NetworkCapabilities.TRANSPORT_WIFI)) {
                    ok = cm.bindProcessToNetwork(n)
                    break
                }
            }
        } catch (e: Throwable) {
            ok = false
        }
        return ok
    }

    @Suppress("DEPRECATION")
    private fun wifiLinkInfo(): Map<String, Int> {
        return try {
            val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            val i = wm.connectionInfo
            mapOf("freq" to i.frequency, "speed" to i.linkSpeed, "rssi" to i.rssi)
        } catch (e: Throwable) {
            mapOf("freq" to -1, "speed" to -1, "rssi" to 0)
        }
    }

    private fun isBluetoothOn(): Boolean {
        return try {
            BluetoothAdapter.getDefaultAdapter()?.isEnabled ?: false
        } catch (e: Exception) {
            false
        }
    }

    // True when the user's own hotspot (tethering) is on. Our own local-only
    // hotspot is not counted.
    @SuppressLint("PrivateApi", "DiscouragedPrivateApi")
    private fun isHotspotOn(): Boolean {
        try {
            val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            val m = wm.javaClass.getDeclaredMethod("isWifiApEnabled")
            m.isAccessible = true
            if (m.invoke(wm) as Boolean) return hotspotReservation == null
        } catch (e: Throwable) {
            // fall through to the interface check
        }
        if (hotspotReservation != null) return false
        try {
            val all = NetworkInterface.getNetworkInterfaces() ?: return false
            for (ni in all) {
                val n = ni.name.lowercase()
                if (!ni.isUp) continue
                if (n.startsWith("ap") || n.startsWith("swlan") || n.startsWith("softap")) {
                    for (a in ni.inetAddresses) {
                        if (a is Inet4Address && !a.isLoopbackAddress) return true
                    }
                }
            }
        } catch (e: Throwable) {
        }
        return false
    }

    @SuppressLint("MissingPermission")
    @Suppress("DEPRECATION")
    private fun turnOffBluetooth(): Boolean {
        if (Build.VERSION.SDK_INT >= 33) return false // Android blocks this; Dart opens Settings
        return try {
            BluetoothAdapter.getDefaultAdapter()?.disable() ?: false
        } catch (e: Throwable) {
            false
        }
    }

    // ---------------------------------------------- local-only hotspot (receiver)

    @SuppressLint("MissingPermission")
    @Suppress("DEPRECATION")
    private fun startHotspot(result: MethodChannel.Result) {
        if (Build.VERSION.SDK_INT < 26) {
            result.success(null)
            return
        }
        stopHotspot()
        val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        var replied = false
        fun reply(v: Any?) {
            if (replied) return
            replied = true
            result.success(v)
        }
        try {
            wm.startLocalOnlyHotspot(object : WifiManager.LocalOnlyHotspotCallback() {
                override fun onStarted(res: WifiManager.LocalOnlyHotspotReservation) {
                    hotspotReservation = res
                    try {
                        var ssid: String? = null
                        var pass: String? = null
                        if (Build.VERSION.SDK_INT >= 30) {
                            val cfg = res.softApConfiguration
                            ssid = cfg.ssid
                            pass = cfg.passphrase
                        } else {
                            val cfg = res.wifiConfiguration
                            ssid = cfg?.SSID
                            pass = cfg?.preSharedKey
                        }
                        ssid = ssid?.trim('"')
                        pass = pass?.trim('"')
                        if (ssid.isNullOrEmpty()) reply(null)
                        else reply(mapOf("ssid" to ssid, "password" to (pass ?: "")))
                    } catch (e: Throwable) {
                        reply(null)
                    }
                }

                override fun onStopped() {
                    hotspotReservation = null
                }

                override fun onFailed(reason: Int) {
                    hotspotReservation = null
                    reply(null)
                }
            }, Handler(Looper.getMainLooper()))
        } catch (e: Throwable) {
            reply(null)
        }
    }

    private fun stopHotspot() {
        try {
            hotspotReservation?.close()
        } catch (e: Throwable) {
        }
        hotspotReservation = null
    }

    // ------------------------------------------- join the other phone's hotspot

    private fun connectToWifi(ssid: String, pass: String?, result: MethodChannel.Result) {
        if (Build.VERSION.SDK_INT < 29) {
            result.success(false)
            return
        }
        releaseWifi()
        val cm = applicationContext.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        var replied = false
        fun reply(v: Boolean) {
            if (replied) return
            replied = true
            result.success(v)
        }
        try {
            val b = WifiNetworkSpecifier.Builder().setSsid(ssid)
            if (!pass.isNullOrEmpty()) b.setWpa2Passphrase(pass)
            val req = NetworkRequest.Builder()
                .addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
                .removeCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                .setNetworkSpecifier(b.build())
                .build()
            val cb = object : ConnectivityManager.NetworkCallback() {
                override fun onAvailable(network: Network) {
                    // All sockets of this app now go through the other phone's hotspot.
                    cm.bindProcessToNetwork(network)
                    reply(true)
                }

                override fun onUnavailable() {
                    reply(false)
                }

                override fun onLost(network: Network) {
                    try {
                        cm.bindProcessToNetwork(null)
                    } catch (e: Throwable) {
                    }
                }
            }
            netCallback = cb
            cm.requestNetwork(req, cb, Handler(Looper.getMainLooper()), 30000)
        } catch (e: Throwable) {
            reply(false)
        }
    }

    private fun releaseWifi() {
        val cm = applicationContext.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        try {
            cm.bindProcessToNetwork(null)
        } catch (e: Throwable) {
        }
        val cb = netCallback
        netCallback = null
        if (cb != null) {
            try {
                cm.unregisterNetworkCallback(cb)
            } catch (e: Throwable) {
            }
        }
    }

    private fun startKeepAlive(text: String): Boolean {
        return try {
            val i = Intent(this, TransferKeepAliveService::class.java)
            i.putExtra(TransferKeepAliveService.EXTRA_TEXT, text)
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
            true
        } catch (e: Throwable) {
            false
        }
    }

    private fun stopKeepAlive() {
        try {
            stopService(Intent(this, TransferKeepAliveService::class.java))
        } catch (e: Throwable) {
        }
    }

    override fun onDestroy() {
        // Only tear the network down when the app is really closing. Going to
        // the background (or another app) must NOT end the connection.
        if (isFinishing) {
            stopKeepAlive()
            stopHotspot()
            releaseWifi()
        }
        super.onDestroy()
    }

    private fun openFirstWorking(intents: List<Intent>): Boolean {
        for (intent in intents) {
            try {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(intent)
                return true
            } catch (e: Exception) {
                // try the next one
            }
        }
        return false
    }

    private fun listApps(): List<Map<String, Any?>> {
        val pm = packageManager
        val query = Intent(Intent.ACTION_MAIN, null)
        query.addCategory(Intent.CATEGORY_LAUNCHER)
        val resolved = pm.queryIntentActivities(query, 0)
        val seen = HashSet<String>()
        val out = ArrayList<Map<String, Any?>>()
        for (ri in resolved) {
            val pkg: String = ri.activityInfo?.packageName ?: continue
            if (!seen.add(pkg)) continue
            val label = ri.loadLabel(pm).toString()
            val icon = drawableToPng(ri.loadIcon(pm))
            out.add(mapOf("name" to label, "package" to pkg, "icon" to icon))
        }
        out.sortBy { (it["name"] as String).lowercase() }
        return out
    }

    private fun drawableToPng(d: Drawable): ByteArray {
        val size = 96
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        d.setBounds(0, 0, size, size)
        d.draw(canvas)
        val bos = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.PNG, 100, bos)
        return bos.toByteArray()
    }
}
