package com.mafx.share

import android.app.Activity
import android.app.ActivityManager
import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.AudioFormat
import android.media.AudioManager
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.media.MediaMuxer
import android.media.MediaScannerConnection
import android.media.audiofx.BassBoost
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.util.Size
import android.view.WindowManager
import android.webkit.MimeTypeMap
import androidx.core.content.FileProvider
import io.flutter.plugin.common.BinaryMessenger
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.Executors

/**
 * Native helpers used by the Flutter side (channel "com.mafx.share/media"):
 * MediaStore publishing / querying, thumbnails, share / open / delete,
 * lossless video / audio cutting, audio extraction, BassBoost effect,
 * brightness + volume for the video player.
 */
class MediaTools(private val activity: Activity, messenger: BinaryMessenger) {
    private val ctx: Context = activity.applicationContext
    private val executor = Executors.newFixedThreadPool(2)
    private val channel = MethodChannel(messenger, "com.mafx.share/media")
    private var bassBoost: BassBoost? = null
    private var bassSession = -1

    init {
        channel.setMethodCallHandler { call, result -> handle(call, result) }
    }

    private fun bg(result: MethodChannel.Result, block: () -> Any?) {
        executor.execute {
            try {
                val v = block()
                activity.runOnUiThread { result.success(v) }
            } catch (e: Throwable) {
                activity.runOnUiThread { result.error("MEDIA_ERROR", e.message ?: e.toString(), null) }
            }
        }
    }

    private fun handle(call: MethodCall, result: MethodChannel.Result) {
        when (call.method) {
            "sdkInt" -> result.success(Build.VERSION.SDK_INT)
            "deviceProfile" -> result.success(deviceProfile())
            "queryMedia" -> {
                val kind = call.argument<String>("kind") ?: "image"
                bg(result) { queryMedia(kind) }
            }
            "thumbnail" -> {
                val src = call.argument<String>("source") ?: ""
                val kind = call.argument<String>("kind") ?: "image"
                val size = call.argument<Int>("size") ?: 256
                val albumId = call.argument<Number>("albumId")?.toLong() ?: -1L
                bg(result) { thumbnail(src, kind, size, albumId) }
            }
            "publishFile" -> {
                val path = call.argument<String>("path") ?: ""
                val name = call.argument<String>("name") ?: File(path).name
                val dir = call.argument<String>("dir")
                bg(result) { publishFile(File(path), name, dir) }
            }
            "saveImage" -> {
                val bytes = call.argument<ByteArray>("bytes")
                val name = call.argument<String>("name") ?: "image.png"
                val format = call.argument<String>("format") ?: "png"
                bg(result) { saveImage(bytes ?: ByteArray(0), name, format) }
            }
            "deleteSources" -> {
                val list = call.argument<List<String>>("sources") ?: emptyList()
                bg(result) { deleteSources(list) }
            }
            "exists" -> {
                val src = call.argument<String>("source") ?: ""
                bg(result) { exists(src) }
            }
            "copyToCache" -> {
                val src = call.argument<String>("source") ?: ""
                val name = call.argument<String>("name") ?: "file"
                bg(result) { copyToCache(src, name) }
            }
            "share" -> {
                val list = call.argument<List<String>>("sources") ?: emptyList()
                result.success(share(list))
            }
            "openExternal" -> {
                val src = call.argument<String>("source") ?: ""
                val mime = call.argument<String>("mime")
                result.success(openExternal(src, mime))
            }
            "mediaInfo" -> {
                val src = call.argument<String>("source") ?: ""
                bg(result) { mediaInfo(src) }
            }
            "cutVideo" -> {
                val src = call.argument<String>("source") ?: ""
                val s = call.argument<Number>("startMs")?.toLong() ?: 0L
                val e = call.argument<Number>("endMs")?.toLong() ?: 0L
                val name = call.argument<String>("name") ?: "cut.mp4"
                bg(result) { cutVideo(src, s, e, name) }
            }
            "cutAudio" -> {
                val src = call.argument<String>("source") ?: ""
                val s = call.argument<Number>("startMs")?.toLong() ?: 0L
                val e = call.argument<Number>("endMs")?.toLong() ?: 0L
                val name = call.argument<String>("name") ?: "cut"
                bg(result) { cutAudio(src, s, e, name, false) }
            }
            "extractAudio" -> {
                val src = call.argument<String>("source") ?: ""
                val name = call.argument<String>("name") ?: "audio"
                bg(result) { cutAudio(src, 0L, Long.MAX_VALUE / 2000, name, true) }
            }
            "setBassBoost" -> {
                val session = call.argument<Int>("session") ?: 0
                val strength = call.argument<Int>("strength") ?: 0
                result.success(setBassBoost(session, strength))
            }
            "isIgnoringBattery" -> {
                val pm = ctx.getSystemService(Context.POWER_SERVICE) as android.os.PowerManager
                result.success(pm.isIgnoringBatteryOptimizations(ctx.packageName))
            }
            "openBatterySettings" -> {
                result.success(try {
                    val i = Intent(android.provider.Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    ctx.startActivity(i)
                    true
                } catch (_: Throwable) {
                    false
                })
            }
            "getBrightness" -> result.success(getBrightness())
            "setBrightness" -> {
                val v = call.argument<Double>("value") ?: -1.0
                setBrightness(v.toFloat())
                result.success(true)
            }
            "getVolume" -> result.success(getVolume())
            "setVolume" -> {
                val v = call.argument<Double>("value") ?: 0.0
                setVolume(v)
                result.success(true)
            }
            "keepScreenOn" -> {
                val on = call.argument<Boolean>("on") ?: false
                activity.runOnUiThread {
                    if (on) activity.window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                    else activity.window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                }
                result.success(true)
            }
            else -> result.notImplemented()
        }
    }

    // ------------------------------------------------------------ device

    private fun deviceProfile(): Map<String, Any> {
        val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        return mapOf(
            "memoryClassMb" to am.memoryClass,
            "totalMemMb" to (mi.totalMem / 1048576L).toInt(),
            "lowRam" to am.isLowRamDevice,
            "cores" to Runtime.getRuntime().availableProcessors(),
            "sdk" to Build.VERSION.SDK_INT
        )
    }

    // ------------------------------------------------------------- query

    private fun collectionFor(kind: String): Uri = when (kind) {
        "video" -> MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        "audio" -> MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        "download" ->
            if (Build.VERSION.SDK_INT >= 29) MediaStore.Downloads.EXTERNAL_CONTENT_URI
            else MediaStore.Files.getContentUri("external")
        else -> MediaStore.Images.Media.EXTERNAL_CONTENT_URI
    }

    @Suppress("DEPRECATION")
    private fun queryMedia(kind: String): List<Map<String, Any?>> {
        val uri = collectionFor(kind)
        val cols = ArrayList<String>()
        cols.add(MediaStore.MediaColumns._ID)
        cols.add(MediaStore.MediaColumns.DISPLAY_NAME)
        cols.add(MediaStore.MediaColumns.SIZE)
        cols.add(MediaStore.MediaColumns.DATE_ADDED)
        cols.add(MediaStore.MediaColumns.MIME_TYPE)
        cols.add(MediaStore.MediaColumns.DATA)
        if (kind == "video") {
            cols.add(MediaStore.Video.VideoColumns.DURATION)
            cols.add(MediaStore.Video.VideoColumns.WIDTH)
            cols.add(MediaStore.Video.VideoColumns.HEIGHT)
        }
        if (kind == "image") {
            cols.add(MediaStore.Images.ImageColumns.WIDTH)
            cols.add(MediaStore.Images.ImageColumns.HEIGHT)
        }
        if (kind == "audio") {
            cols.add(MediaStore.Audio.AudioColumns.DURATION)
            cols.add(MediaStore.Audio.AudioColumns.ARTIST)
            cols.add(MediaStore.Audio.AudioColumns.ALBUM)
            cols.add(MediaStore.Audio.AudioColumns.ALBUM_ID)
            cols.add(MediaStore.Audio.AudioColumns.TITLE)
        }
        var selection: String? = null
        var args: Array<String>? = null
        if (kind == "audio") {
            selection = "${MediaStore.Audio.AudioColumns.IS_RINGTONE}=0 AND " +
                "${MediaStore.Audio.AudioColumns.IS_NOTIFICATION}=0 AND " +
                "${MediaStore.Audio.AudioColumns.IS_ALARM}=0"
        } else if (kind == "download") {
            if (Build.VERSION.SDK_INT >= 29) {
                selection = "${MediaStore.MediaColumns.RELATIVE_PATH} LIKE ?"
                args = arrayOf("Download/MAFX SHARE%")
            } else {
                selection = "${MediaStore.MediaColumns.DATA} LIKE ?"
                args = arrayOf("%/Download/MAFX SHARE/%")
            }
        }
        val out = ArrayList<Map<String, Any?>>()
        val c = ctx.contentResolver.query(
            uri, cols.toTypedArray(), selection, args,
            "${MediaStore.MediaColumns.DATE_ADDED} DESC"
        ) ?: return out
        c.use {
            val iId = it.getColumnIndexOrThrow(MediaStore.MediaColumns._ID)
            val iName = it.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME)
            val iSize = it.getColumnIndexOrThrow(MediaStore.MediaColumns.SIZE)
            val iDate = it.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_ADDED)
            val iMime = it.getColumnIndexOrThrow(MediaStore.MediaColumns.MIME_TYPE)
            val iData = it.getColumnIndexOrThrow(MediaStore.MediaColumns.DATA)
            val iDur = it.getColumnIndex("duration")
            val iW = it.getColumnIndex("width")
            val iH = it.getColumnIndex("height")
            val iArtist = it.getColumnIndex("artist")
            val iAlbum = it.getColumnIndex("album")
            val iAlbumId = it.getColumnIndex("album_id")
            val iTitle = it.getColumnIndex("title")
            while (it.moveToNext()) {
                val id = it.getLong(iId)
                val m = HashMap<String, Any?>()
                m["id"] = id
                m["uri"] = ContentUris.withAppendedId(uri, id).toString()
                m["name"] = it.getString(iName) ?: ""
                m["size"] = it.getLong(iSize)
                m["date"] = it.getLong(iDate) * 1000L
                m["mime"] = it.getString(iMime) ?: ""
                m["path"] = it.getString(iData) ?: ""
                if (iDur >= 0) m["durationMs"] = it.getLong(iDur)
                if (iW >= 0) m["width"] = it.getInt(iW)
                if (iH >= 0) m["height"] = it.getInt(iH)
                if (iArtist >= 0) m["artist"] = it.getString(iArtist)
                if (iAlbum >= 0) m["album"] = it.getString(iAlbum)
                if (iAlbumId >= 0) m["albumId"] = it.getLong(iAlbumId)
                if (iTitle >= 0) m["title"] = it.getString(iTitle)
                out.add(m)
            }
        }
        return out
    }

    // --------------------------------------------------------- thumbnails

    private fun isContent(s: String) = s.startsWith("content://")

    private fun toBytes(bmp: Bitmap, png: Boolean = false): ByteArray {
        val bos = ByteArrayOutputStream()
        if (png) bmp.compress(Bitmap.CompressFormat.PNG, 100, bos)
        else bmp.compress(Bitmap.CompressFormat.JPEG, 82, bos)
        return bos.toByteArray()
    }

    @Suppress("DEPRECATION")
    private fun thumbnail(src: String, kind: String, size: Int, albumId: Long): ByteArray? {
        try {
            if (kind == "audio") {
                val art = audioArt(src)
                if (art != null) return art
                if (albumId > 0) {
                    val au = ContentUris.withAppendedId(Uri.parse("content://media/external/audio/albumart"), albumId)
                    try {
                        ctx.contentResolver.openInputStream(au)?.use { ins ->
                            val b = BitmapFactory.decodeStream(ins)
                            if (b != null) return toBytes(scaleDown(b, size))
                        }
                    } catch (_: Throwable) {
                    }
                }
                return null
            }
            if (isContent(src)) {
                val uri = Uri.parse(src)
                if (Build.VERSION.SDK_INT >= 29) {
                    val b = ctx.contentResolver.loadThumbnail(uri, Size(size, size), null)
                    return toBytes(b)
                }
                if (kind == "video") {
                    val id = ContentUris.parseId(uri)
                    val b = MediaStore.Video.Thumbnails.getThumbnail(
                        ctx.contentResolver, id, MediaStore.Video.Thumbnails.MINI_KIND, null
                    )
                    return if (b != null) toBytes(b) else null
                }
                return decodeSampled(uri, size)
            }
            // plain file path
            if (kind == "video") {
                val r = MediaMetadataRetriever()
                try {
                    r.setDataSource(src)
                    val b = r.getFrameAtTime(1_000_000L, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                    return if (b != null) toBytes(scaleDown(b, size)) else null
                } finally {
                    r.release()
                }
            }
            return decodeSampled(Uri.fromFile(File(src)), size)
        } catch (_: Throwable) {
            return null
        }
    }

    private fun audioArt(src: String): ByteArray? {
        val r = MediaMetadataRetriever()
        try {
            if (isContent(src)) r.setDataSource(ctx, Uri.parse(src)) else r.setDataSource(src)
            val pic = r.embeddedPicture ?: return null
            val b = BitmapFactory.decodeByteArray(pic, 0, pic.size) ?: return null
            return toBytes(scaleDown(b, 512))
        } catch (_: Throwable) {
            return null
        } finally {
            try {
                r.release()
            } catch (_: Throwable) {
            }
        }
    }

    private fun scaleDown(b: Bitmap, target: Int): Bitmap {
        val m = maxOf(b.width, b.height)
        if (m <= target) return b
        val f = target.toFloat() / m
        return Bitmap.createScaledBitmap(b, (b.width * f).toInt().coerceAtLeast(1), (b.height * f).toInt().coerceAtLeast(1), true)
    }

    private fun decodeSampled(uri: Uri, size: Int): ByteArray? {
        val o = BitmapFactory.Options()
        o.inJustDecodeBounds = true
        ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
        var sample = 1
        while (o.outWidth / (sample * 2) >= size && o.outHeight / (sample * 2) >= size) sample *= 2
        val o2 = BitmapFactory.Options()
        o2.inSampleSize = sample
        val b = ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o2) }
            ?: return null
        return toBytes(b)
    }

    // -------------------------------------------------- MediaStore publish

    private fun guessMime(name: String): String {
        val ext = name.substringAfterLast('.', "").lowercase()
        val m = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext)
        if (m != null) return m
        return when (ext) {
            "mkv" -> "video/x-matroska"
            "opus" -> "audio/ogg"
            "m4a" -> "audio/mp4"
            "apk" -> "application/vnd.android.package-archive"
            else -> "application/octet-stream"
        }
    }

    /** Folder (Pictures / Movies / Music / Download) for a file name. */
    private fun dirFor(name: String): String {
        val m = guessMime(name)
        return when {
            m.startsWith("image/") -> "Pictures"
            m.startsWith("video/") -> "Movies"
            m.startsWith("audio/") -> "Music"
            else -> "Download"
        }
    }

    /**
     * Copies [file] into the public folder <dir>/MAFX SHARE and returns
     * {uri, path, dir}. The source file is NOT deleted here.
     */
    @Suppress("DEPRECATION")
    private fun publishFile(file: File, name: String, dirArg: String?): Map<String, Any?> {
        val dir = dirArg ?: dirFor(name)
        val mime = guessMime(name)
        if (Build.VERSION.SDK_INT >= 29) {
            val collection: Uri = when (dir) {
                "Pictures" -> MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
                "Movies" -> MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
                "Music" -> MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
                else -> MediaStore.Downloads.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
            }
            val values = ContentValues()
            values.put(MediaStore.MediaColumns.DISPLAY_NAME, name)
            values.put(MediaStore.MediaColumns.MIME_TYPE, mime)
            values.put(MediaStore.MediaColumns.RELATIVE_PATH, "$dir/MAFX SHARE")
            values.put(MediaStore.MediaColumns.IS_PENDING, 1)
            val resolver = ctx.contentResolver
            val item = resolver.insert(collection, values) ?: throw Exception("MediaStore insert failed")
            try {
                resolver.openOutputStream(item, "w").use { out ->
                    if (out == null) throw Exception("Cannot open output")
                    file.inputStream().use { ins ->
                        val buf = ByteArray(1 shl 20)
                        while (true) {
                            val n = ins.read(buf)
                            if (n <= 0) break
                            out.write(buf, 0, n)
                        }
                        out.flush()
                    }
                }
                val done = ContentValues()
                done.put(MediaStore.MediaColumns.IS_PENDING, 0)
                resolver.update(item, done, null, null)
            } catch (e: Throwable) {
                try {
                    resolver.delete(item, null, null)
                } catch (_: Throwable) {
                }
                throw e
            }
            return mapOf("uri" to item.toString(), "path" to "", "dir" to "$dir/MAFX SHARE", "name" to name)
        }
        // Android 9 and older: write straight into the public folder.
        val publicDir = Environment.getExternalStoragePublicDirectory(
            when (dir) {
                "Pictures" -> Environment.DIRECTORY_PICTURES
                "Movies" -> Environment.DIRECTORY_MOVIES
                "Music" -> Environment.DIRECTORY_MUSIC
                else -> Environment.DIRECTORY_DOWNLOADS
            }
        )
        val target = File(publicDir, "MAFX SHARE")
        if (!target.exists() && !target.mkdirs()) throw Exception("Cannot create ${target.path}")
        var dest = File(target, name)
        var n = 1
        val base = name.substringBeforeLast('.', name)
        val ext = if (name.contains('.')) "." + name.substringAfterLast('.') else ""
        while (dest.exists()) {
            dest = File(target, "$base ($n)$ext")
            n++
        }
        file.inputStream().use { ins -> FileOutputStream(dest).use { out -> ins.copyTo(out, 1 shl 20) } }
        MediaScannerConnection.scanFile(ctx, arrayOf(dest.absolutePath), arrayOf(mime), null)
        return mapOf("uri" to Uri.fromFile(dest).toString(), "path" to dest.absolutePath, "dir" to "$dir/MAFX SHARE", "name" to dest.name)
    }

    private fun saveImage(bytes: ByteArray, name: String, format: String): Map<String, Any?> {
        val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size) ?: throw Exception("Bad image data")
        val jpg = format == "jpg" || format == "jpeg"
        val outName = name.substringBeforeLast('.', name) + if (jpg) ".jpg" else ".png"
        val tmp = File(ctx.cacheDir, "save_" + System.currentTimeMillis() + (if (jpg) ".jpg" else ".png"))
        FileOutputStream(tmp).use {
            if (jpg) bmp.compress(Bitmap.CompressFormat.JPEG, 95, it)
            else bmp.compress(Bitmap.CompressFormat.PNG, 100, it)
        }
        try {
            return publishFile(tmp, outName, "Pictures")
        } finally {
            tmp.delete()
        }
    }

    // ----------------------------------------------------- delete / exists

    @Suppress("DEPRECATION")
    private fun deleteSources(list: List<String>): Map<String, Any?> {
        val ok = ArrayList<String>()
        val failed = ArrayList<String>()
        for (s in list) {
            try {
                if (isContent(s)) {
                    val n = ctx.contentResolver.delete(Uri.parse(s), null, null)
                    if (n > 0) ok.add(s) else failed.add(s)
                } else {
                    val f = File(s.removePrefix("file://"))
                    if (!f.exists() || f.delete()) {
                        ok.add(s)
                        MediaScannerConnection.scanFile(ctx, arrayOf(f.absolutePath), null, null)
                    } else failed.add(s)
                }
            } catch (_: Throwable) {
                failed.add(s)
            }
        }
        return mapOf("deleted" to ok, "failed" to failed)
    }

    private fun exists(s: String): Boolean {
        if (s.isEmpty()) return false
        return try {
            if (isContent(s)) {
                ctx.contentResolver.openFileDescriptor(Uri.parse(s), "r")?.use { true } ?: false
            } else if (s.startsWith("file://")) File(Uri.parse(s).path ?: "").exists()
            else File(s).exists()
        } catch (_: Throwable) {
            false
        }
    }

    private fun copyToCache(s: String, name: String): String {
        if (!isContent(s)) return s
        val dir = File(ctx.cacheDir, "opened")
        dir.mkdirs()
        val dest = File(dir, System.currentTimeMillis().toString() + "_" + name.replace('/', '_'))
        ctx.contentResolver.openInputStream(Uri.parse(s))?.use { ins ->
            FileOutputStream(dest).use { ins.copyTo(it, 1 shl 20) }
        } ?: throw Exception("Cannot open file")
        return dest.absolutePath
    }

    // ------------------------------------------------------- share / open

    private fun uriFor(s: String): Uri {
        if (isContent(s)) return Uri.parse(s)
        val path = if (s.startsWith("file://")) (Uri.parse(s).path ?: s) else s
        return FileProvider.getUriForFile(ctx, ctx.packageName + ".fileprovider", File(path))
    }

    private fun share(list: List<String>): Boolean {
        return try {
            if (list.isEmpty()) return false
            val uris = ArrayList<Uri>()
            val mimes = HashSet<String>()
            for (s in list) {
                uris.add(uriFor(s))
                val n = if (isContent(s)) (ctx.contentResolver.getType(Uri.parse(s)) ?: "*/*") else guessMime(s)
                mimes.add(n)
            }
            val type = if (mimes.size == 1) mimes.first() else {
                val tops = mimes.map { it.substringBefore('/') }.toSet()
                if (tops.size == 1) tops.first() + "/*" else "*/*"
            }
            val intent = if (uris.size == 1) Intent(Intent.ACTION_SEND).apply {
                putExtra(Intent.EXTRA_STREAM, uris[0])
            } else Intent(Intent.ACTION_SEND_MULTIPLE).apply {
                putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
            }
            intent.type = type
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            val chooser = Intent.createChooser(intent, "Share")
            chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION)
            ctx.startActivity(chooser)
            true
        } catch (_: Throwable) {
            false
        }
    }

    private fun openExternal(s: String, mimeArg: String?): Boolean {
        return try {
            val uri = uriFor(s)
            val mime = mimeArg ?: (if (isContent(s)) ctx.contentResolver.getType(uri) else guessMime(s)) ?: "*/*"
            val intent = Intent(Intent.ACTION_VIEW)
            intent.setDataAndType(uri, mime)
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(intent)
            true
        } catch (_: Throwable) {
            false
        }
    }

    // ---------------------------------------------------------- media info

    private fun setSource(r: MediaMetadataRetriever, s: String) {
        if (isContent(s)) r.setDataSource(ctx, Uri.parse(s)) else r.setDataSource(s)
    }

    private fun mediaInfo(s: String): Map<String, Any?> {
        val r = MediaMetadataRetriever()
        try {
            setSource(r, s)
            val m = HashMap<String, Any?>()
            fun put(key: String, id: Int) {
                val v = r.extractMetadata(id)
                if (v != null) m[key] = v
            }
            put("durationMs", MediaMetadataRetriever.METADATA_KEY_DURATION)
            put("width", MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)
            put("height", MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)
            put("rotation", MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)
            put("bitrate", MediaMetadataRetriever.METADATA_KEY_BITRATE)
            put("mime", MediaMetadataRetriever.METADATA_KEY_MIMETYPE)
            put("title", MediaMetadataRetriever.METADATA_KEY_TITLE)
            put("artist", MediaMetadataRetriever.METADATA_KEY_ARTIST)
            put("album", MediaMetadataRetriever.METADATA_KEY_ALBUM)
            if (Build.VERSION.SDK_INT >= 23) put("fps", MediaMetadataRetriever.METADATA_KEY_CAPTURE_FRAMERATE)
            return m
        } finally {
            try {
                r.release()
            } catch (_: Throwable) {
            }
        }
    }

    // ------------------------------------------------------- cut / extract

    private fun newExtractor(s: String): MediaExtractor {
        val ex = MediaExtractor()
        if (isContent(s)) ex.setDataSource(ctx, Uri.parse(s), null) else ex.setDataSource(s)
        return ex
    }

    private fun findTrack(ex: MediaExtractor, prefix: String): Int {
        for (i in 0 until ex.trackCount) {
            val mime = ex.getTrackFormat(i).getString(MediaFormat.KEY_MIME) ?: continue
            if (mime.startsWith(prefix)) return i
        }
        return -1
    }

    private fun tmpFile(ext: String): File {
        val d = File(ctx.cacheDir, "tools")
        d.mkdirs()
        return File(d, "out_" + System.currentTimeMillis() + "." + ext)
    }

    /**
     * Lossless video cut (stream copy). The cut starts at the key frame at or
     * before the chosen start time, so it is fast and keeps full quality.
     */
    private fun cutVideo(src: String, startMs: Long, endMs: Long, name: String): Map<String, Any?> {
        if (endMs <= startMs) throw Exception("End time must be after start time")
        val ex = newExtractor(src)
        val tmp = tmpFile("mp4")
        var muxer: MediaMuxer? = null
        try {
            var rotation = 0
            val r = MediaMetadataRetriever()
            try {
                setSource(r, src)
                rotation = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
            } finally {
                try {
                    r.release()
                } catch (_: Throwable) {
                }
            }
            muxer = MediaMuxer(tmp.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            val map = HashMap<Int, Int>()
            for (i in 0 until ex.trackCount) {
                val f = ex.getTrackFormat(i)
                val mime = f.getString(MediaFormat.KEY_MIME) ?: continue
                if (!mime.startsWith("video/") && !mime.startsWith("audio/")) continue
                try {
                    map[i] = muxer.addTrack(f)
                    ex.selectTrack(i)
                } catch (_: Throwable) {
                    // this track type cannot go into MP4: skip it
                }
            }
            if (map.isEmpty()) throw Exception("This video format cannot be cut on this phone")
            if (findTrack(ex, "video/") < 0 || !map.containsKey(findTrack(ex, "video/"))) {
                throw Exception("The video track of this file is not supported for cutting")
            }
            muxer.setOrientationHint(rotation)
            muxer.start()
            ex.seekTo(startMs * 1000L, MediaExtractor.SEEK_TO_PREVIOUS_SYNC)
            val buf = ByteBuffer.allocateDirect(4 * 1024 * 1024)
            val info = MediaCodec.BufferInfo()
            var base = -1L
            val endUs = endMs * 1000L
            var wrote = 0
            while (true) {
                buf.clear()
                val size = ex.readSampleData(buf, 0)
                if (size < 0) break
                val t = ex.sampleTime
                if (t > endUs) break
                val track = map[ex.sampleTrackIndex]
                if (track != null) {
                    if (base < 0) base = t
                    info.offset = 0
                    info.size = size
                    info.presentationTimeUs = (t - base).coerceAtLeast(0)
                    var flags = 0
                    if ((ex.sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC) != 0) flags = flags or MediaCodec.BUFFER_FLAG_SYNC_FRAME
                    info.flags = flags
                    muxer.writeSampleData(track, buf, info)
                    wrote++
                }
                ex.advance()
            }
            muxer.stop()
            muxer.release()
            muxer = null
            if (wrote == 0) throw Exception("Nothing was written. Try another range.")
            val outName = if (name.lowercase().endsWith(".mp4")) name else "$name.mp4"
            return publishFile(tmp, outName, "Movies")
        } finally {
            try {
                muxer?.release()
            } catch (_: Throwable) {
            }
            ex.release()
            tmp.delete()
        }
    }

    /**
     * Audio cut / extraction.
     *  - MP3 source  -> raw MP3 frames copied (lossless, .mp3)
     *  - AAC source  -> M4A (lossless)
     *  - anything else -> decoded and saved as WAV
     */
    private fun cutAudio(src: String, startMs: Long, endMs: Long, nameArg: String, fromVideo: Boolean): Map<String, Any?> {
        val ex = newExtractor(src)
        try {
            val track = findTrack(ex, "audio/")
            if (track < 0) throw Exception("No audio track found in this file")
            val format = ex.getTrackFormat(track)
            val mime = format.getString(MediaFormat.KEY_MIME) ?: ""
            ex.selectTrack(track)
            val base = nameArg.substringBeforeLast('.', nameArg)
            val startUs = startMs * 1000L
            val endUs = if (endMs > Long.MAX_VALUE / 4000) Long.MAX_VALUE else endMs * 1000L
            if (!fromVideo && endUs <= startUs) throw Exception("End time must be after start time")
            ex.seekTo(startUs, MediaExtractor.SEEK_TO_PREVIOUS_SYNC)
            return when {
                mime == "audio/mpeg" -> cutRawMp3(ex, base, startUs, endUs)
                mime == "audio/mp4a-latm" -> cutToM4a(ex, format, base, startUs, endUs)
                else -> cutToWav(ex, format, mime, base, startUs, endUs)
            }
        } finally {
            ex.release()
        }
    }

    private fun cutRawMp3(ex: MediaExtractor, base: String, startUs: Long, endUs: Long): Map<String, Any?> {
        val tmp = tmpFile("mp3")
        try {
            val buf = ByteBuffer.allocate(256 * 1024)
            var wrote = 0
            FileOutputStream(tmp).use { out ->
                while (true) {
                    buf.clear()
                    val n = ex.readSampleData(buf, 0)
                    if (n < 0) break
                    val t = ex.sampleTime
                    if (t > endUs) break
                    if (t >= startUs - 30_000L) {
                        out.write(buf.array(), 0, n)
                        wrote++
                    }
                    ex.advance()
                }
            }
            if (wrote == 0) throw Exception("Nothing was written. Try another range.")
            return publishFile(tmp, "$base.mp3", "Music")
        } finally {
            tmp.delete()
        }
    }

    private fun cutToM4a(ex: MediaExtractor, format: MediaFormat, base: String, startUs: Long, endUs: Long): Map<String, Any?> {
        val tmp = tmpFile("m4a")
        var muxer: MediaMuxer? = null
        try {
            muxer = MediaMuxer(tmp.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            val t = muxer.addTrack(format)
            muxer.start()
            val buf = ByteBuffer.allocateDirect(512 * 1024)
            val info = MediaCodec.BufferInfo()
            var first = -1L
            var wrote = 0
            while (true) {
                buf.clear()
                val n = ex.readSampleData(buf, 0)
                if (n < 0) break
                val st = ex.sampleTime
                if (st > endUs) break
                if (st >= startUs - 30_000L) {
                    if (first < 0) first = st
                    info.offset = 0
                    info.size = n
                    info.presentationTimeUs = (st - first).coerceAtLeast(0)
                    info.flags = MediaCodec.BUFFER_FLAG_SYNC_FRAME
                    muxer.writeSampleData(t, buf, info)
                    wrote++
                }
                ex.advance()
            }
            muxer.stop()
            muxer.release()
            muxer = null
            if (wrote == 0) throw Exception("Nothing was written. Try another range.")
            return publishFile(tmp, "$base.m4a", "Music")
        } finally {
            try {
                muxer?.release()
            } catch (_: Throwable) {
            }
            tmp.delete()
        }
    }

    private fun writeWavHeader(raf: RandomAccessFile, dataLen: Long, sampleRate: Int, channels: Int) {
        val bits = 16
        val byteRate = sampleRate * channels * bits / 8
        val h = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
        h.put("RIFF".toByteArray())
        h.putInt((36 + dataLen).toInt())
        h.put("WAVE".toByteArray())
        h.put("fmt ".toByteArray())
        h.putInt(16)
        h.putShort(1)
        h.putShort(channels.toShort())
        h.putInt(sampleRate)
        h.putInt(byteRate)
        h.putShort((channels * bits / 8).toShort())
        h.putShort(bits.toShort())
        h.put("data".toByteArray())
        h.putInt(dataLen.toInt())
        raf.seek(0)
        raf.write(h.array())
    }

    private fun cutToWav(ex: MediaExtractor, format: MediaFormat, mime: String, base: String, startUs: Long, endUs: Long): Map<String, Any?> {
        val tmp = tmpFile("wav")
        var sampleRate = format.getInteger(MediaFormat.KEY_SAMPLE_RATE)
        var channels = format.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
        var codec: MediaCodec? = null
        try {
            RandomAccessFile(tmp, "rw").use { raf ->
                raf.setLength(0)
                raf.write(ByteArray(44))
                var dataLen = 0L
                val info = MediaCodec.BufferInfo()
                if (mime == "audio/raw") {
                    val buf = ByteBuffer.allocate(256 * 1024)
                    while (true) {
                        buf.clear()
                        val n = ex.readSampleData(buf, 0)
                        if (n < 0) break
                        val t = ex.sampleTime
                        if (t > endUs) break
                        if (t >= startUs) {
                            raf.write(buf.array(), 0, n)
                            dataLen += n
                        }
                        ex.advance()
                    }
                } else {
                    codec = MediaCodec.createDecoderByType(mime)
                    codec.configure(format, null, null, 0)
                    codec.start()
                    var inputDone = false
                    var outputDone = false
                    val skipUntil = startUs
                    while (!outputDone) {
                        if (!inputDone) {
                            val ii = codec.dequeueInputBuffer(10_000)
                            if (ii >= 0) {
                                val ib = codec.getInputBuffer(ii)!!
                                val n = ex.readSampleData(ib, 0)
                                if (n < 0 || ex.sampleTime > endUs + 200_000L) {
                                    codec.queueInputBuffer(ii, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                                    inputDone = true
                                } else {
                                    codec.queueInputBuffer(ii, 0, n, ex.sampleTime, 0)
                                    ex.advance()
                                }
                            }
                        }
                        val oi = codec.dequeueOutputBuffer(info, 10_000)
                        if (oi >= 0) {
                            val ob = codec.getOutputBuffer(oi)!!
                            val pts = info.presentationTimeUs
                            if (info.size > 0 && pts >= skipUntil && pts <= endUs) {
                                val arr = ByteArray(info.size)
                                ob.position(info.offset)
                                ob.get(arr, 0, info.size)
                                raf.write(arr)
                                dataLen += info.size
                            }
                            codec.releaseOutputBuffer(oi, false)
                            if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) outputDone = true
                        } else if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                            val nf = codec.outputFormat
                            sampleRate = nf.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                            channels = nf.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                        }
                    }
                }
                if (dataLen == 0L) throw Exception("Nothing was written. Try another range.")
                writeWavHeader(raf, dataLen, sampleRate, channels)
            }
            return publishFile(tmp, "$base.wav", "Music")
        } finally {
            try {
                codec?.stop()
                codec?.release()
            } catch (_: Throwable) {
            }
            tmp.delete()
        }
    }

    // ------------------------------------------------------------- effects

    /** Real android.media.audiofx.BassBoost on the player's audio session. */
    private fun setBassBoost(session: Int, strength: Int): Boolean {
        return try {
            if (strength <= 0) {
                bassBoost?.enabled = false
                return true
            }
            if (bassBoost == null || bassSession != session) {
                try {
                    bassBoost?.release()
                } catch (_: Throwable) {
                }
                bassBoost = BassBoost(0, session)
                bassSession = session
            }
            val b = bassBoost!!
            if (!b.strengthSupported) return false
            b.setStrength(strength.coerceIn(0, 1000).toShort())
            b.enabled = true
            true
        } catch (_: Throwable) {
            false
        }
    }

    // ---------------------------------------------- brightness and volume

    private fun getBrightness(): Double {
        val v = activity.window.attributes.screenBrightness
        if (v >= 0f) return v.toDouble()
        return try {
            android.provider.Settings.System.getInt(ctx.contentResolver, android.provider.Settings.System.SCREEN_BRIGHTNESS) / 255.0
        } catch (_: Throwable) {
            0.5
        }
    }

    private fun setBrightness(v: Float) {
        activity.runOnUiThread {
            val lp = activity.window.attributes
            lp.screenBrightness = if (v < 0f) WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE else v.coerceIn(0.01f, 1f)
            activity.window.attributes = lp
        }
    }

    private fun getVolume(): Double {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
        return am.getStreamVolume(AudioManager.STREAM_MUSIC).toDouble() / max
    }

    private fun setVolume(v: Double) {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        am.setStreamVolume(AudioManager.STREAM_MUSIC, (v.coerceIn(0.0, 1.0) * max).toInt(), 0)
    }

    fun dispose() {
        try {
            bassBoost?.release()
        } catch (_: Throwable) {
        }
        bassBoost = null
    }
}
