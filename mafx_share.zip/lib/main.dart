import 'dart:async';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:hive/hive.dart';
import 'package:just_audio_background/just_audio_background.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:path_provider/path_provider.dart';

import 'models.dart';
import 'screens/home_screen.dart';
import 'screens/transfer_screen.dart';
import 'services/history_service.dart';
import 'services/music_service.dart';
import 'services/native_bridge.dart';
import 'services/partial_store.dart';
import 'services/storage_service.dart';
import 'services/transfer_service.dart';
import 'theme.dart';

final GlobalKey<NavigatorState> navigatorKey = GlobalKey<NavigatorState>();

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  // Background music: notification + lock-screen controls.
  try {
    await JustAudioBackground.init(
      androidNotificationChannelId: 'com.mafx.share.audio',
      androidNotificationChannelName: 'MAFX SHARE music',
      androidNotificationOngoing: true,
    );
  } catch (_) {}
  final dir = await getApplicationDocumentsDirectory();
  Hive.init(dir.path);
  await StorageService.instance.init();
  await HistoryService.instance.init();
  await PartialStore.instance.init();
  await _prepareDevice();
  unawaited(MusicService.instance.init());
  runApp(const MafxShareApp());
}

/// Chooses the transfer profile for this phone (16 MiB / 24 streams when it
/// can take it, smaller profiles on weaker phones) and asks for the storage
/// permission that Android 9 and older need to save into public folders.
Future<void> _prepareDevice() async {
  try {
    final prof = await Native.deviceProfile();
    int n(String k, int d) => (prof[k] is num) ? (prof[k] as num).toInt() : d;
    TransferMode.recommended = TransferMode.forDevice(
      memoryClassMb: n('memoryClassMb', 256),
      totalMemMb: n('totalMemMb', 6000),
      lowRam: prof['lowRam'] == true,
      cores: n('cores', 8),
    );
    final sdk = await Native.sdkInt();
    if (sdk > 0 && sdk < 29) {
      await Permission.storage.request();
    }
  } catch (_) {}
}

class MafxShareApp extends StatefulWidget {
  const MafxShareApp({super.key});

  @override
  State<MafxShareApp> createState() => _MafxShareAppState();
}

class _MafxShareAppState extends State<MafxShareApp> {
  final svc = TransferService.instance;

  @override
  void initState() {
    super.initState();
    svc.incomingStart.addListener(_onIncoming);
    svc.pairedPeer.addListener(_onPeer);
    svc.resumeOffer.addListener(_onResumeOffer);
  }

  @override
  void dispose() {
    svc.incomingStart.removeListener(_onIncoming);
    svc.pairedPeer.removeListener(_onPeer);
    svc.resumeOffer.removeListener(_onResumeOffer);
    super.dispose();
  }

  /// The connection ended (on purpose or it could not be restored): go back
  /// to Home, where the Send / Received cards are shown again.
  void _onPeer() {
    if (svc.pairedPeer.value != null) return;
    final nav = navigatorKey.currentState;
    nav?.popUntil((r) => r.isFirst);
    final notice = svc.linkNotice.value;
    final ctx = navigatorKey.currentContext;
    if (notice != null && ctx != null) {
      ScaffoldMessenger.of(ctx).showSnackBar(SnackBar(content: Text(notice)));
      svc.linkNotice.value = null;
    }
  }

  /// Connected again and a send was interrupted: ask if it should continue.
  Future<void> _onResumeOffer() async {
    await Future.delayed(const Duration(milliseconds: 700));
    final pending = PartialStore.instance.pending;
    final ctx = navigatorKey.currentContext;
    if (pending == null || ctx == null || !svc.isConnected) return;
    final files = <PendingFile>[];
    for (final f in (pending['files'] as List? ?? const [])) {
      if (f is! Map) continue;
      final path = (f['path'] ?? '').toString();
      if (path.isNotEmpty && File(path).existsSync()) {
        files.add(PendingFile(
          id: path,
          path: path,
          name: (f['name'] ?? '').toString(),
          size: (f['size'] as num?)?.toInt() ?? 0,
        ));
      }
    }
    if (files.isEmpty) {
      await PartialStore.instance.setPending(null);
      return;
    }
    final pct = (pending['percent'] as num?)?.toInt() ?? 0;
    final more = files.length > 1 ? ' (+${files.length - 1} more)' : '';
    if (!ctx.mounted) return;
    final yes = await showDialog<bool>(
      context: ctx,
      builder: (c) => AlertDialog(
        title: const Text('Continue?'),
        content: Text(
          '"${files.first.name}"$more stopped at about $pct%.\n'
          'Continue from where it stopped?',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(c, false),
            child: const Text('No'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(c, true),
            child: const Text('Yes'),
          ),
        ],
      ),
    );
    if (yes == true) {
      navigatorKey.currentState?.push(
        MaterialPageRoute(builder: (_) => TransferScreen(files: files)),
      );
    } else if (yes == false) {
      await PartialStore.instance.setPending(null);
    }
  }

  /// The other phone started sending: show the progress screen by itself.
  void _onIncoming() {
    if (TransferScreen.isOpen) return;
    navigatorKey.currentState?.push(
      MaterialPageRoute(builder: (_) => const TransferScreen(receiving: true)),
    );
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      navigatorKey: navigatorKey,
      title: 'Mafx Share',
      debugShowCheckedModeBanner: false,
      theme: buildTheme(),
      home: const HomeScreen(),
    );
  }
}
