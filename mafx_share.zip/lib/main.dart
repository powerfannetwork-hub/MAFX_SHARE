import 'package:flutter/material.dart';
import 'package:hive/hive.dart';
import 'package:path_provider/path_provider.dart';

import 'screens/home_screen.dart';
import 'screens/transfer_screen.dart';
import 'services/history_service.dart';
import 'services/storage_service.dart';
import 'services/transfer_service.dart';
import 'theme.dart';

final GlobalKey<NavigatorState> navigatorKey = GlobalKey<NavigatorState>();

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final dir = await getApplicationDocumentsDirectory();
  Hive.init(dir.path);
  await StorageService.instance.init();
  await HistoryService.instance.init();
  runApp(const MafxShareApp());
}

class MafxShareApp extends StatefulWidget {
  const MafxShareApp({super.key});

  @override
  State<MafxShareApp> createState() => _MafxShareAppState();
}

class _MafxShareAppState extends State<MafxShareApp> {
  @override
  void initState() {
    super.initState();
    TransferService.instance.incomingStart.addListener(_onIncoming);
  }

  @override
  void dispose() {
    TransferService.instance.incomingStart.removeListener(_onIncoming);
    super.dispose();
  }

  /// The other phone started sending: show the progress screen by itself.
  void _onIncoming() {
    if (TransferScreen.isOpen) return;
    navigatorKey.currentState?.push(
      MaterialPageRoute(builder: (_) => const TransferScreen(receiving: true)),
    );
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      navigatorKey: navigatorKey,
      title: 'MAFX SHARE',
      debugShowCheckedModeBanner: false,
      theme: buildTheme(),
      home: const HomeScreen(),
    );
  }
}
