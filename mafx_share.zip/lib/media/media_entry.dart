import 'package:path/path.dart' as p;

import '../models.dart';

enum EntryKind { photo, video, audio, file }

enum SortMode {
  newest,
  oldest,
  nameAsc,
  nameDesc,
  largest,
  smallest,
  longest,
  shortest;

  String get label => switch (this) {
        SortMode.newest => 'Newest first',
        SortMode.oldest => 'Oldest first',
        SortMode.nameAsc => 'Name A-Z',
        SortMode.nameDesc => 'Name Z-A',
        SortMode.largest => 'Largest first',
        SortMode.smallest => 'Smallest first',
        SortMode.longest => 'Longest first',
        SortMode.shortest => 'Shortest first',
      };

  bool get needsDuration => this == SortMode.longest || this == SortMode.shortest;
}

/// One photo / video / song / file in the media browser.
class MediaEntry {
  const MediaEntry({
    required this.id,
    required this.kind,
    required this.uri,
    required this.path,
    required this.name,
    required this.size,
    required this.dateMs,
    this.mime = '',
    this.durationMs = 0,
    this.width = 0,
    this.height = 0,
    this.artist,
    this.album,
    this.albumId,
    this.title,
  });

  final String id;
  final EntryKind kind;

  /// content:// URI ('' for plain picked files).
  final String uri;

  /// File path when the system gives one ('' otherwise).
  final String path;
  final String name;
  final int size;
  final int dateMs;
  final String mime;
  final int durationMs;
  final int width;
  final int height;
  final String? artist;
  final String? album;
  final int? albumId;
  final String? title;

  /// What native helpers (thumbnails, share, delete, players) should use.
  String get source => uri.isNotEmpty ? uri : path;

  String get displayName =>
      (title != null && title!.trim().isNotEmpty && kind == EntryKind.audio)
          ? title!.trim()
          : name;

  String get key => '${kind.name}:$id';

  static EntryKind kindOf(String k) => switch (k) {
        'video' => EntryKind.video,
        'audio' => EntryKind.audio,
        'download' => EntryKind.file,
        _ => EntryKind.photo,
      };

  factory MediaEntry.fromMap(String kindName, Map<String, dynamic> m) {
    final kind = kindOf(kindName);
    int asInt(dynamic v) => v is num ? v.toInt() : 0;
    return MediaEntry(
      id: (m['id'] ?? '').toString(),
      kind: kind,
      uri: (m['uri'] ?? '').toString(),
      path: (m['path'] ?? '').toString(),
      name: (m['name'] ?? '').toString(),
      size: asInt(m['size']),
      dateMs: asInt(m['date']),
      mime: (m['mime'] ?? '').toString(),
      durationMs: asInt(m['durationMs']),
      width: asInt(m['width']),
      height: asInt(m['height']),
      artist: m['artist']?.toString(),
      album: m['album']?.toString(),
      albumId: m['albumId'] is num ? (m['albumId'] as num).toInt() : null,
      title: m['title']?.toString(),
    );
  }

  /// A file picked with the system file picker.
  factory MediaEntry.picked(String path, String name, int size) => MediaEntry(
        id: path,
        kind: EntryKind.file,
        uri: '',
        path: path,
        name: name.isEmpty ? p.basename(path) : name,
        size: size,
        dateMs: DateTime.now().millisecondsSinceEpoch,
      );

  PendingFile toPending() => PendingFile(
        id: key,
        path: path,
        name: name.isEmpty ? p.basename(path) : name,
        size: size,
      );
}

/// Sorting + search used by every tab.
List<MediaEntry> sortAndFilter(
    List<MediaEntry> all, SortMode sort, String query) {
  final q = query.trim().toLowerCase();
  final list = q.isEmpty
      ? List<MediaEntry>.of(all)
      : all.where((e) {
          return e.name.toLowerCase().contains(q) ||
              (e.title ?? '').toLowerCase().contains(q) ||
              (e.artist ?? '').toLowerCase().contains(q) ||
              (e.album ?? '').toLowerCase().contains(q);
        }).toList();
  int cmpName(MediaEntry a, MediaEntry b) =>
      a.displayName.toLowerCase().compareTo(b.displayName.toLowerCase());
  switch (sort) {
    case SortMode.newest:
      list.sort((a, b) => b.dateMs.compareTo(a.dateMs));
    case SortMode.oldest:
      list.sort((a, b) => a.dateMs.compareTo(b.dateMs));
    case SortMode.nameAsc:
      list.sort(cmpName);
    case SortMode.nameDesc:
      list.sort((a, b) => cmpName(b, a));
    case SortMode.largest:
      list.sort((a, b) => b.size.compareTo(a.size));
    case SortMode.smallest:
      list.sort((a, b) => a.size.compareTo(b.size));
    case SortMode.longest:
      list.sort((a, b) => b.durationMs.compareTo(a.durationMs));
    case SortMode.shortest:
      list.sort((a, b) => a.durationMs.compareTo(b.durationMs));
  }
  return list;
}
