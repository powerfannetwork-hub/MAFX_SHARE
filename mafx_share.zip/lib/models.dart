/// Transfer profiles. The preferred profile is 16 MiB chunks, 24 parallel TCP
/// streams, 2 MiB app buffer and 8 MiB socket buffers. Weaker phones fall
/// back to [balanced] or [safe] automatically ([forDevice]), and when two
/// phones connect the LOWER of the two profiles is used ([lower]).
class TransferMode {
  const TransferMode(this.wire, this.label, this.chunkSize, this.streams,
      this.maxStreams, this.bufferSize, this.socketBuffer, this.tier);

  /// Strong phones (lots of RAM and cores): starts with 32 streams and the
  /// sender keeps adding streams (up to 64) while the speed still grows.
  static const TransferMode ultra = TransferMode('ultra32', 'Ultra', 16 * 1048576,
      32, 64, 2 * 1048576, 8 * 1048576, 4);
  static const TransferMode turbo = TransferMode('turbo24', '5G+ High Speed',
      16 * 1048576, 24, 48, 2 * 1048576, 8 * 1048576, 3);
  static const TransferMode balanced = TransferMode(
      'balanced12', 'Balanced', 8 * 1048576, 12, 24, 1048576, 4 * 1048576, 2);
  static const TransferMode safe = TransferMode(
      'safe6', 'Safe mode', 4 * 1048576, 6, 12, 512 * 1024, 2 * 1048576, 1);

  /// Profile of older app versions (still understood).
  static const TransferMode legacy = TransferMode(
      '5g_plus', '5G+ High Speed', 8 * 1048576, 12, 12, 1048576, 4 * 1048576, 2);

  final String wire;
  final String label;
  final int chunkSize;

  /// Parallel TCP streams the sender starts with.
  final int streams;

  /// Most streams the sender may grow to while the speed keeps improving.
  final int maxStreams;

  /// Size of the read / write buffer used by the app.
  final int bufferSize;

  /// Wanted SO_SNDBUF / SO_RCVBUF (the OS may clamp it).
  final int socketBuffer;

  /// 4 = fastest, 1 = safest.
  final int tier;

  /// Profile chosen for THIS phone (set once at start-up by [forDevice]).
  static TransferMode recommended = turbo;

  static const List<TransferMode> all = [ultra, turbo, balanced, safe, legacy];

  static TransferMode parse(String? s) {
    for (final m in all) {
      if (m.wire == s) return m;
    }
    return recommended;
  }

  /// The slower (safer) of two profiles.
  static TransferMode lower(TransferMode a, TransferMode b) =>
      a.tier <= b.tier ? a : b;

  /// Picks a profile from what the phone can do. Average phones get
  /// Balanced / Turbo; only phones with plenty of RAM and cores get Ultra.
  static TransferMode forDevice({
    required int memoryClassMb,
    required int totalMemMb,
    required bool lowRam,
    required int cores,
  }) {
    if (lowRam || totalMemMb < 2500 || memoryClassMb < 128 || cores < 4) {
      return safe;
    }
    if (totalMemMb < 4500 || memoryClassMb < 256 || cores < 6) {
      return balanced;
    }
    if (totalMemMb >= 7000 && memoryClassMb >= 320 && cores >= 8) {
      return ultra;
    }
    return turbo;
  }

  @override
  bool operator ==(Object other) => other is TransferMode && other.wire == wire;

  @override
  int get hashCode => wire.hashCode;
}

class PairedPeer {
  const PairedPeer({
    required this.ip,
    required this.port,
    required this.tcpPort,
    required this.token,
    required this.mode,
  });

  final String ip;
  final int port;
  final int tcpPort;
  final String token;
  final TransferMode mode;
}

class PendingFile {
  const PendingFile({
    required this.id,
    required this.path,
    required this.name,
    required this.size,
  });

  final String id;
  final String path;
  final String name;
  final int size;
}

class TransferProgress {
  const TransferProgress({
    required this.direction,
    required this.currentName,
    required this.fileIndex,
    required this.fileCount,
    required this.doneBytes,
    required this.totalBytes,
    required this.speed,
    required this.mode,
    required this.finished,
  });

  final String direction; // 'sent' or 'received'
  final String currentName;
  final int fileIndex;
  final int fileCount;
  final int doneBytes;
  final int totalBytes;
  final double speed;
  final TransferMode mode;
  final bool finished;

  double get fraction {
    if (totalBytes <= 0) return finished ? 1.0 : 0.0;
    return (doneBytes / totalBytes).clamp(0.0, 1.0).toDouble();
  }
}

class HistoryEntry {
  const HistoryEntry({
    required this.key,
    required this.name,
    required this.size,
    required this.date,
    required this.type,
    required this.path,
    this.status = 'done',
    this.percent = 100,
  });

  /// 'done' or 'partial' (interrupted: can be continued).
  final String status;
  final int percent;
  final dynamic key;
  final String name;
  final int size;
  final DateTime date;
  final String type; // 'sent' or 'received'
  final String path;
}
