import 'package:flutter/material.dart';
import 'package:installed_apps/app_info.dart';
import 'package:installed_apps/installed_apps.dart';

import '../theme.dart';

String _s(Object? v) => v?.toString() ?? '';

/// Lists installed apps. Tap an app to Open or Delete (uninstall) it.
class AppsScreen extends StatefulWidget {
  const AppsScreen({super.key});

  @override
  State<AppsScreen> createState() => _AppsScreenState();
}

class _AppsScreenState extends State<AppsScreen> {
  List<AppInfo> _apps = [];
  bool _loading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final apps = await InstalledApps.getInstalledApps(true, true);
      apps.sort((a, b) => _s(a.name).toLowerCase().compareTo(_s(b.name).toLowerCase()));
      if (!mounted) return;
      setState(() {
        _apps = apps;
        _loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _loading = false;
        _error = 'Could not list apps: $e';
      });
    }
  }

  void _actions(AppInfo app) {
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: kPanel,
      builder: (ctx) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              title: Text(_s(app.name)),
              subtitle: Text(_s(app.packageName)),
            ),
            ListTile(
              leading: const Icon(Icons.open_in_new),
              title: const Text('Open'),
              onTap: () async {
                Navigator.pop(ctx);
                await InstalledApps.startApp(_s(app.packageName));
              },
            ),
            ListTile(
              leading: const Icon(Icons.delete_outline, color: Colors.redAccent),
              title: const Text('Delete (uninstall)'),
              onTap: () async {
                Navigator.pop(ctx);
                await InstalledApps.uninstallApp(_s(app.packageName));
                await Future.delayed(const Duration(seconds: 2));
                if (mounted) _load();
              },
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Apps')),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _error != null
              ? Center(child: Text(_error!, textAlign: TextAlign.center))
              : ListView.builder(
                  itemCount: _apps.length,
                  itemBuilder: (context, i) {
                    final app = _apps[i];
                    final icon = app.icon;
                    return ListTile(
                      leading: icon != null
                          ? Image.memory(icon, width: 42, height: 42)
                          : const Icon(Icons.android, size: 42),
                      title: Text(_s(app.name)),
                      subtitle: Text(_s(app.packageName)),
                      onTap: () => _actions(app),
                    );
                  },
                ),
    );
  }
}
