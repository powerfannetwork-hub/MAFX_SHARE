import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';

import '../services/transfer_service.dart';
import 'qr_screen.dart';
import 'scan_qr_screen.dart';

/// Step between Home and the QR screens: permissions, then WiFi / Hotspot.
class ConnectScreen extends StatefulWidget {
  const ConnectScreen({super.key, required this.receive});

  /// true = Received (show QR), false = Send (scan QR).
  final bool receive;

  @override
  State<ConnectScreen> createState() => _ConnectScreenState();
}

class _ConnectScreenState extends State<ConnectScreen> {
  String _status = 'Requesting permissions...';
  bool _denied = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _run());
  }

  Future<void> _run() async {
    setState(() {
      _denied = false;
      _status = 'Requesting permissions...';
    });
    final result = await [
      Permission.camera,
      Permission.locationWhenInUse,
      Permission.nearbyWifiDevices,
    ].request();
    if (!mounted) return;

    final cameraOk = result[Permission.camera]?.isGranted ?? false;
    if (!widget.receive && !cameraOk) {
      setState(() {
        _denied = true;
        _status = 'Camera permission is needed to scan the QR code.';
      });
      return;
    }

    setState(() => _status = 'Checking WiFi / Hotspot...');
    final ok = await _askNetwork();
    if (!mounted) return;
    if (!ok) {
      Navigator.pop(context);
      return;
    }
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (_) =>
            widget.receive ? const QrScreen() : const ScanQrScreen(),
      ),
    );
  }

  Future<bool> _askNetwork() async {
    String note = '';
    while (mounted) {
      final go = await showDialog<bool>(
        context: context,
        barrierDismissible: false,
        builder: (ctx) => AlertDialog(
          title: const Text('Turn on WiFi or Hotspot'),
          content: Text(
            '$note${widget.receive ? 'Turn on your Hotspot, or connect to a WiFi network. The other phone must join the same network.' : 'Connect to the same WiFi, or to the other phone\'s Hotspot.'}\n\nThen tap Continue.',
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('Cancel'),
            ),
            FilledButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('Continue'),
            ),
          ],
        ),
      );
      if (go != true) return false;
      final ip = await TransferService.instance.getLocalIp();
      if (ip != null) return true;
      note = 'No WiFi or Hotspot network found yet.\n\n';
    }
    return false;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.receive ? 'Received' : 'Send')),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              if (!_denied) const CircularProgressIndicator(),
              const SizedBox(height: 20),
              Text(_status, textAlign: TextAlign.center),
              if (_denied) ...[
                const SizedBox(height: 16),
                FilledButton(onPressed: _run, child: const Text('Try again')),
                TextButton(
                  onPressed: openAppSettings,
                  child: const Text('Open app settings'),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}
