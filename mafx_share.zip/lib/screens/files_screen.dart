import 'package:flutter/material.dart';

import '../widgets/media_browser.dart';

/// Opens the media browser on the Files tab.
class FilesScreen extends StatelessWidget {
  const FilesScreen({super.key});

  @override
  Widget build(BuildContext context) => const MediaHubScreen(initialTab: 5);
}
