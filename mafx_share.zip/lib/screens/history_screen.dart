import 'package:flutter/material.dart';

import '../widgets/media_browser.dart';

/// Opens the media browser on the History tab.
class HistoryScreen extends StatelessWidget {
  const HistoryScreen({super.key});

  @override
  Widget build(BuildContext context) => const MediaHubScreen(initialTab: 0);
}
