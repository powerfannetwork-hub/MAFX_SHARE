import 'package:flutter/material.dart';

import '../widgets/media_browser.dart';

/// Opens the media browser on the Photos tab.
class ImagesScreen extends StatelessWidget {
  const ImagesScreen({super.key});

  @override
  Widget build(BuildContext context) => const MediaHubScreen(initialTab: 2);
}
