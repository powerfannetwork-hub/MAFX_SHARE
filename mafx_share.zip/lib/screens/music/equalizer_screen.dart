import 'package:flutter/material.dart';

import '../../services/equalizer_service.dart';
import '../../services/music_service.dart';
import '../../theme.dart';

String _hz(double hz) => hz >= 1000
    ? '${(hz / 1000).toStringAsFixed(hz % 1000 == 0 ? 0 : 1)}k'
    : hz.toStringAsFixed(0);

/// Real Android equalizer (android.media.audiofx.Equalizer, LoudnessEnhancer
/// and BassBoost) connected to the music player.
class EqualizerScreen extends StatefulWidget {
  const EqualizerScreen({super.key});

  @override
  State<EqualizerScreen> createState() => _EqualizerScreenState();
}

class _EqualizerScreenState extends State<EqualizerScreen> {
  final svc = MusicService.instance;
  bool _loading = true;

  EqualizerService get eq => svc.eq;

  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<void> _init() async {
    if (svc.hasQueue) await eq.ensureReady();
    eq.takeSnapshot();
    if (mounted) setState(() => _loading = false);
  }

  void _snack(String m) => ScaffoldMessenger.of(context)
    ..hideCurrentSnackBar()
    ..showSnackBar(SnackBar(content: Text(m)));

  Future<void> _savePreset() async {
    final c = TextEditingController();
    final name = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Save preset'),
        content: TextField(
          controller: c,
          autofocus: true,
          decoration: const InputDecoration(hintText: 'Preset name'),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(ctx, c.text), child: const Text('Save')),
        ],
      ),
    );
    if (name != null && name.trim().isNotEmpty) {
      await eq.saveCustomPreset(name);
      _snack('Saved "${name.trim()}"');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Equalizer'),
        actions: [
          IconButton(
            tooltip: 'Restore previous settings',
            icon: const Icon(Icons.history),
            onPressed: () async {
              await eq.restoreSnapshot();
              _snack('Previous settings restored');
            },
          ),
          IconButton(
            tooltip: 'Reset',
            icon: const Icon(Icons.restart_alt),
            onPressed: () async {
              await eq.reset();
              _snack('Equalizer reset');
            },
          ),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : ListenableBuilder(listenable: eq, builder: (context, _) => _content()),
    );
  }

  Widget _content() {
    if (!svc.hasQueue) {
      return const Center(
        child: Padding(
          padding: EdgeInsets.all(24),
          child: Text(
            'Play a song first. The equalizer connects to the music player.',
            textAlign: TextAlign.center,
          ),
        ),
      );
    }
    if (!eq.supported) {
      return const Center(
        child: Padding(
          padding: EdgeInsets.all(24),
          child: Text(
            'This phone does not support the Android audio equalizer.\n'
            'Music still plays normally.',
            textAlign: TextAlign.center,
          ),
        ),
      );
    }
    if (!eq.ready) {
      return Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text('Equalizer is not ready yet.'),
            const SizedBox(height: 12),
            FilledButton(
              onPressed: () async {
                await eq.ensureReady();
                if (mounted) setState(() {});
              },
              child: const Text('Try again'),
            ),
          ],
        ),
      );
    }
    final names = eq.allPresetNames;
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        SwitchListTile(
          value: eq.enabled,
          activeColor: kGreen,
          title: const Text('Equalizer'),
          subtitle: Text('Preset: ${eq.preset}'),
          onChanged: eq.setEnabled,
        ),
        const SizedBox(height: 6),
        SizedBox(
          height: 42,
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            itemCount: names.length,
            separatorBuilder: (_, __) => const SizedBox(width: 8),
            itemBuilder: (context, i) {
              final n = names[i];
              final isCustom = eq.custom.containsKey(n);
              return GestureDetector(
                onLongPress: isCustom
                    ? () async {
                        await eq.deleteCustomPreset(n);
                        _snack('Deleted "$n"');
                      }
                    : null,
                child: ChoiceChip(
                  label: Text(n),
                  selected: eq.preset == n,
                  selectedColor: alpha(kGreen, 0.35),
                  onSelected: (_) => eq.applyPreset(n),
                ),
              );
            },
          ),
        ),
        const SizedBox(height: 4),
        const Text(
          'Long-press a saved preset to delete it.',
          style: TextStyle(fontSize: 11, color: Colors.white54),
        ),
        const SizedBox(height: 16),
        Container(
          padding: const EdgeInsets.fromLTRB(8, 16, 8, 8),
          decoration: BoxDecoration(
            color: kPanel,
            borderRadius: BorderRadius.circular(20),
          ),
          child: Column(
            children: [
              SizedBox(
                height: 210,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    for (var i = 0; i < eq.centersHz.length; i++)
                      Expanded(
                        child: Column(
                          children: [
                            Text('${eq.base[i].toStringAsFixed(0)} dB',
                                style: const TextStyle(fontSize: 11)),
                            Expanded(
                              child: RotatedBox(
                                quarterTurns: 3,
                                child: Slider(
                                  value: eq.base[i].clamp(eq.minDb, eq.maxDb).toDouble(),
                                  min: eq.minDb,
                                  max: eq.maxDb,
                                  activeColor: kBlue,
                                  onChanged: (v) => eq.setBand(i, v),
                                  onChangeEnd: (_) => eq.commit(),
                                ),
                              ),
                            ),
                            Text('${_hz(eq.centersHz[i])} Hz',
                                style: const TextStyle(fontSize: 11)),
                          ],
                        ),
                      ),
                  ],
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 16),
        _slider('Bass', eq.bass, -1, 1, eq.setBass),
        _slider('Treble', eq.treble, -1, 1, eq.setTreble),
        _slider('Loudness (volume boost)', eq.loudnessGain, 0, 12, eq.setLoudness,
            suffix: ' dB'),
        if (!eq.bassBoostOk)
          const Padding(
            padding: EdgeInsets.only(top: 6),
            child: Text(
              'The hardware Bass Boost effect is not available on this phone; '
              'the Bass slider uses the equalizer bands instead.',
              style: TextStyle(fontSize: 12, color: Colors.white60),
            ),
          ),
        const SizedBox(height: 16),
        Row(
          children: [
            Expanded(
              child: OutlinedButton.icon(
                onPressed: _savePreset,
                icon: const Icon(Icons.save_outlined),
                label: const Text('Save preset'),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: OutlinedButton.icon(
                onPressed: eq.reset,
                icon: const Icon(Icons.restart_alt),
                label: const Text('Reset'),
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _slider(String label, double value, double min, double max,
      Future<void> Function(double) onChanged,
      {String suffix = ''}) {
    final shown = suffix.isEmpty
        ? '${(value * 100).round()}%'
        : '${value.toStringAsFixed(0)}$suffix';
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(left: 4),
          child: Text('$label: $shown'),
        ),
        Slider(
          value: value.clamp(min, max).toDouble(),
          min: min,
          max: max,
          activeColor: kGreen,
          onChanged: (v) => onChanged(v),
          onChangeEnd: (_) => eq.commit(),
        ),
      ],
    );
  }
}
