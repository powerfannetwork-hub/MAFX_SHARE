import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:just_audio/just_audio.dart';

import '../../media/media_entry.dart';
import '../../services/music_service.dart';
import '../../theme.dart';
import '../../widgets/media_thumb.dart';
import 'equalizer_screen.dart';
import 'playlists_screen.dart';

String _fmt(Duration d) {
  final h = d.inHours;
  final m = d.inMinutes.remainder(60).toString().padLeft(2, '0');
  final s = d.inSeconds.remainder(60).toString().padLeft(2, '0');
  return h > 0 ? '$h:$m:$s' : '${d.inMinutes}:$s';
}

/// Full-screen music player: artwork, seek bar, play / pause, next /
/// previous, shuffle, repeat (off / all / one), speed, equalizer, queue.
class NowPlayingScreen extends StatelessWidget {
  const NowPlayingScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final svc = MusicService.instance;
    return ListenableBuilder(
      listenable: svc,
      builder: (context, _) {
        final cur = svc.current;
        return Scaffold(
          appBar: AppBar(
            title: const Text('Now playing'),
            actions: [
              IconButton(
                tooltip: 'Equalizer',
                icon: const Icon(Icons.equalizer),
                onPressed: () => Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const EqualizerScreen()),
                ),
              ),
              if (cur != null)
                IconButton(
                  tooltip: 'Add to playlist',
                  icon: const Icon(Icons.playlist_add),
                  onPressed: () => showAddToPlaylist(context, [cur]),
                ),
            ],
          ),
          body: cur == null
              ? const Center(child: Text('Nothing is playing.'))
              : SafeArea(
                  child: LayoutBuilder(builder: (context, box) {
                    final art = math.min(box.maxWidth - 48, box.maxHeight * 0.42);
                    return SingleChildScrollView(
                      padding: const EdgeInsets.symmetric(horizontal: 24),
                      child: ConstrainedBox(
                        constraints: BoxConstraints(minHeight: box.maxHeight),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            const SizedBox(height: 8),
                            Container(
                              width: art,
                              height: art,
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(24),
                                boxShadow: [
                                  BoxShadow(
                                    color: alpha(kBlue, 0.25),
                                    blurRadius: 28,
                                    spreadRadius: 1,
                                  ),
                                ],
                              ),
                              child: MediaThumb(entry: cur, size: 600, radius: 24),
                            ),
                            const SizedBox(height: 22),
                            Text(
                              cur.displayName,
                              maxLines: 2,
                              textAlign: TextAlign.center,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w700),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              [cur.artist, cur.album]
                                  .where((e) => e != null && e.isNotEmpty && e != '<unknown>')
                                  .join(' • '),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(color: Colors.white60),
                            ),
                            const SizedBox(height: 14),
                            _SeekBar(svc: svc, fallbackMs: cur.durationMs),
                            const SizedBox(height: 4),
                            _Controls(svc: svc),
                            const SizedBox(height: 8),
                            _Extras(svc: svc),
                            const SizedBox(height: 12),
                          ],
                        ),
                      ),
                    );
                  }),
                ),
        );
      },
    );
  }
}

class _SeekBar extends StatefulWidget {
  const _SeekBar({required this.svc, required this.fallbackMs});
  final MusicService svc;
  final int fallbackMs;

  @override
  State<_SeekBar> createState() => _SeekBarState();
}

class _SeekBarState extends State<_SeekBar> {
  double? _drag;

  @override
  Widget build(BuildContext context) {
    final player = widget.svc.player;
    return StreamBuilder<Duration?>(
      stream: player.durationStream,
      builder: (context, ds) {
        final total = ds.data ?? Duration(milliseconds: widget.fallbackMs);
        final totalMs = math.max(1, total.inMilliseconds).toDouble();
        return StreamBuilder<Duration>(
          stream: player.positionStream,
          builder: (context, ps) {
            final pos = (ps.data ?? Duration.zero).inMilliseconds.toDouble();
            final value = (_drag ?? pos).clamp(0.0, totalMs).toDouble();
            return Column(
              children: [
                SliderTheme(
                  data: SliderTheme.of(context).copyWith(
                    trackHeight: 4,
                    activeTrackColor: kGreen,
                    thumbColor: kGreen,
                    inactiveTrackColor: kPanel,
                  ),
                  child: Slider(
                    value: value,
                    max: totalMs,
                    onChanged: (v) => setState(() => _drag = v),
                    onChangeEnd: (v) async {
                      await widget.svc.seek(Duration(milliseconds: v.round()));
                      if (mounted) setState(() => _drag = null);
                    },
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(_fmt(Duration(milliseconds: value.round()))),
                      Text(_fmt(total)),
                    ],
                  ),
                ),
              ],
            );
          },
        );
      },
    );
  }
}

class _Controls extends StatelessWidget {
  const _Controls({required this.svc});
  final MusicService svc;

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<PlayerState>(
      stream: svc.player.playerStateStream,
      builder: (context, snap) {
        final st = snap.data;
        final playing = st?.playing ?? false;
        final loading = st?.processingState == ProcessingState.loading ||
            st?.processingState == ProcessingState.buffering;
        return Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            IconButton(
              iconSize: 32,
              tooltip: 'Shuffle',
              color: svc.shuffle ? kGreen : null,
              icon: const Icon(Icons.shuffle),
              onPressed: svc.toggleShuffle,
            ),
            IconButton(
              iconSize: 42,
              tooltip: 'Previous',
              icon: const Icon(Icons.skip_previous),
              onPressed: svc.previous,
            ),
            SizedBox(
              width: 72,
              height: 72,
              child: loading
                  ? const Padding(
                      padding: EdgeInsets.all(18),
                      child: CircularProgressIndicator(color: kGreen),
                    )
                  : IconButton.filled(
                      style: IconButton.styleFrom(
                        backgroundColor: kGreen,
                        foregroundColor: Colors.black,
                      ),
                      iconSize: 44,
                      tooltip: playing ? 'Pause' : 'Play',
                      icon: Icon(playing ? Icons.pause : Icons.play_arrow),
                      onPressed: svc.togglePlay,
                    ),
            ),
            IconButton(
              iconSize: 42,
              tooltip: 'Next',
              icon: const Icon(Icons.skip_next),
              onPressed: svc.next,
            ),
            IconButton(
              iconSize: 32,
              tooltip: switch (svc.loopMode) {
                LoopMode.off => 'Repeat off',
                LoopMode.all => 'Repeat all',
                LoopMode.one => 'Repeat one',
              },
              color: svc.loopMode == LoopMode.off ? null : kGreen,
              icon: Icon(svc.loopMode == LoopMode.one ? Icons.repeat_one : Icons.repeat),
              onPressed: svc.cycleRepeat,
            ),
          ],
        );
      },
    );
  }
}

class _Extras extends StatelessWidget {
  const _Extras({required this.svc});
  final MusicService svc;

  @override
  Widget build(BuildContext context) {
    final repeat = switch (svc.loopMode) {
      LoopMode.off => 'Repeat: Off',
      LoopMode.all => 'Repeat: All',
      LoopMode.one => 'Repeat: One',
    };
    return Wrap(
      alignment: WrapAlignment.center,
      spacing: 10,
      runSpacing: 6,
      children: [
        ActionChip(
          avatar: const Icon(Icons.speed, size: 18),
          label: Text('Speed ${svc.speed}x'),
          onPressed: () => _speedSheet(context),
        ),
        ActionChip(
          avatar: const Icon(Icons.queue_music, size: 18),
          label: const Text('Queue'),
          onPressed: () => _queueSheet(context),
        ),
        Chip(label: Text(repeat)),
      ],
    );
  }

  void _speedSheet(BuildContext context) {
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: kPanel,
      builder: (ctx) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const ListTile(title: Text('Playback speed')),
            for (final v in const [0.5, 0.75, 1.0, 1.25, 1.5, 2.0])
              ListTile(
                leading: Icon(
                  v == svc.speed ? Icons.radio_button_checked : Icons.radio_button_unchecked,
                  color: v == svc.speed ? kGreen : null,
                ),
                title: Text('${v}x'),
                onTap: () {
                  svc.setSpeed(v);
                  Navigator.pop(ctx);
                },
              ),
          ],
        ),
      ),
    );
  }

  void _queueSheet(BuildContext context) {
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: kPanel,
      isScrollControlled: true,
      builder: (ctx) => DraggableScrollableSheet(
        expand: false,
        initialChildSize: 0.7,
        builder: (context, scroll) => ListenableBuilder(
          listenable: svc,
          builder: (context, _) => ListView.builder(
            controller: scroll,
            itemCount: svc.queue.length,
            itemBuilder: (context, i) {
              final e = svc.queue[i];
              final on = svc.player.currentIndex == i;
              return ListTile(
                leading: SizedBox(
                  width: 44,
                  height: 44,
                  child: MediaThumb(entry: e, size: 96, radius: 8),
                ),
                title: Text(e.displayName,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(color: on ? kGreen : null)),
                subtitle: Text(e.artist ?? ''),
                onTap: () {
                  svc.playIndex(i);
                  Navigator.pop(ctx);
                },
              );
            },
          ),
        ),
      ),
    );
  }
}

/// Reusable: tap a song in a list -> play the whole list from that song.
Future<void> playFrom(BuildContext context, List<MediaEntry> list, int index,
    {bool openPlayer = true}) async {
  await MusicService.instance.playQueue(list, index);
  if (openPlayer && context.mounted) {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => const NowPlayingScreen()),
    );
  }
}
