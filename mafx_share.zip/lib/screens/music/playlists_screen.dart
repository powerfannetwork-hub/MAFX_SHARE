import 'package:flutter/material.dart';

import '../../media/media_entry.dart';
import '../../services/music_service.dart';
import '../../theme.dart';
import '../../widgets/media_thumb.dart';
import 'now_playing_screen.dart';

Future<String?> _askName(BuildContext context, String title, {String initial = ''}) {
  final c = TextEditingController(text: initial);
  return showDialog<String>(
    context: context,
    builder: (ctx) => AlertDialog(
      title: Text(title),
      content: TextField(
        controller: c,
        autofocus: true,
        decoration: const InputDecoration(hintText: 'Playlist name'),
      ),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
        FilledButton(onPressed: () => Navigator.pop(ctx, c.text), child: const Text('OK')),
      ],
    ),
  );
}

/// Bottom sheet: add songs to an existing or a new playlist.
Future<void> showAddToPlaylist(BuildContext context, List<MediaEntry> songs) async {
  final svc = MusicService.instance;
  final messenger = ScaffoldMessenger.of(context);
  await showModalBottomSheet<void>(
    context: context,
    backgroundColor: kPanel,
    builder: (ctx) => SafeArea(
      child: ListenableBuilder(
        listenable: svc,
        builder: (context, _) => ListView(
          shrinkWrap: true,
          children: [
            const ListTile(title: Text('Add to playlist')),
            ListTile(
              leading: const Icon(Icons.add, color: kGreen),
              title: const Text('New playlist'),
              onTap: () async {
                Navigator.pop(ctx);
                final name = await _askName(context, 'New playlist');
                if (name != null && await svc.createPlaylist(name)) {
                  await svc.addToPlaylist(name.trim(), songs);
                  messenger.showSnackBar(SnackBar(content: Text('Added to "${name.trim()}"')));
                }
              },
            ),
            for (final name in svc.playlists.keys)
              ListTile(
                leading: const Icon(Icons.queue_music),
                title: Text(name),
                subtitle: Text('${svc.playlists[name]!.length} songs'),
                onTap: () async {
                  Navigator.pop(ctx);
                  await svc.addToPlaylist(name, songs);
                  messenger.showSnackBar(SnackBar(content: Text('Added to "$name"')));
                },
              ),
          ],
        ),
      ),
    ),
  );
}

/// All playlists: create, rename, delete, open.
class PlaylistsView extends StatelessWidget {
  const PlaylistsView({super.key});

  @override
  Widget build(BuildContext context) {
    final svc = MusicService.instance;
    return ListenableBuilder(
      listenable: svc,
      builder: (context, _) {
        final names = svc.playlists.keys.toList();
        return ListView(
          padding: const EdgeInsets.only(bottom: 90),
          children: [
            ListTile(
              leading: const CircleAvatar(
                backgroundColor: kGreen,
                child: Icon(Icons.add, color: Colors.black),
              ),
              title: const Text('Create playlist'),
              onTap: () async {
                final name = await _askName(context, 'New playlist');
                if (name != null) await svc.createPlaylist(name);
              },
            ),
            if (names.isEmpty)
              const Padding(
                padding: EdgeInsets.all(24),
                child: Center(child: Text('No playlists yet.')),
              ),
            for (final n in names)
              ListTile(
                leading: CircleAvatar(
                  backgroundColor: alpha(kBlue, 0.25),
                  child: const Icon(Icons.queue_music, color: kBlue),
                ),
                title: Text(n),
                subtitle: Text('${svc.playlists[n]!.length} songs'),
                trailing: PopupMenuButton<String>(
                  color: kPanel,
                  onSelected: (v) async {
                    if (v == 'rename') {
                      final name = await _askName(context, 'Rename playlist', initial: n);
                      if (name != null) await svc.renamePlaylist(n, name);
                    } else if (v == 'delete') {
                      await svc.deletePlaylist(n);
                    } else if (v == 'play') {
                      await svc.playPlaylist(n);
                    } else if (v == 'shuffle') {
                      await svc.playPlaylist(n, shuffleOn: true);
                    }
                  },
                  itemBuilder: (_) => const [
                    PopupMenuItem(value: 'play', child: Text('Play')),
                    PopupMenuItem(value: 'shuffle', child: Text('Shuffle play')),
                    PopupMenuItem(value: 'rename', child: Text('Rename')),
                    PopupMenuItem(value: 'delete', child: Text('Delete')),
                  ],
                ),
                onTap: () => Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => PlaylistDetailScreen(name: n)),
                ),
              ),
          ],
        );
      },
    );
  }
}

/// Songs of one playlist: play, remove, re-order.
class PlaylistDetailScreen extends StatelessWidget {
  const PlaylistDetailScreen({super.key, required this.name});
  final String name;

  @override
  Widget build(BuildContext context) {
    final svc = MusicService.instance;
    return ListenableBuilder(
      listenable: svc,
      builder: (context, _) {
        final songs = svc.playlistSongs(name);
        return Scaffold(
          appBar: AppBar(
            title: Text(name),
            actions: [
              IconButton(
                tooltip: 'Add songs',
                icon: const Icon(Icons.add),
                onPressed: () => _pickSongs(context),
              ),
            ],
          ),
          floatingActionButton: songs.isEmpty
              ? null
              : FloatingActionButton.extended(
                  backgroundColor: kGreen,
                  foregroundColor: Colors.black,
                  icon: const Icon(Icons.play_arrow),
                  label: const Text('Play'),
                  onPressed: () => playFrom(context, songs, 0),
                ),
          body: songs.isEmpty
              ? const Center(child: Text('This playlist is empty.'))
              : ReorderableListView.builder(
                  padding: const EdgeInsets.only(bottom: 90),
                  itemCount: songs.length,
                  onReorder: (a, b) => svc.moveInPlaylist(name, a, b),
                  itemBuilder: (context, i) {
                    final e = songs[i];
                    return ListTile(
                      key: ValueKey(e.source),
                      leading: SizedBox(
                        width: 46,
                        height: 46,
                        child: MediaThumb(entry: e, size: 96, radius: 8),
                      ),
                      title: Text(e.displayName, maxLines: 1, overflow: TextOverflow.ellipsis),
                      subtitle: Text(e.artist ?? ''),
                      trailing: IconButton(
                        tooltip: 'Remove from playlist',
                        icon: const Icon(Icons.remove_circle_outline),
                        onPressed: () => svc.removeFromPlaylist(name, e.source),
                      ),
                      onTap: () => playFrom(context, songs, i),
                    );
                  },
                ),
        );
      },
    );
  }

  Future<void> _pickSongs(BuildContext context) async {
    final svc = MusicService.instance;
    await svc.loadLibrary();
    if (!context.mounted) return;
    final chosen = <String>{};
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: kPanel,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setS) => DraggableScrollableSheet(
          expand: false,
          initialChildSize: 0.85,
          builder: (ctx, scroll) => Column(
            children: [
              ListTile(
                title: const Text('Add songs'),
                trailing: FilledButton(
                  onPressed: () async {
                    final list = svc.library.where((e) => chosen.contains(e.source)).toList();
                    await svc.addToPlaylist(name, list);
                    if (ctx.mounted) Navigator.pop(ctx);
                  },
                  child: Text('Add (${chosen.length})'),
                ),
              ),
              Expanded(
                child: ListView.builder(
                  controller: scroll,
                  itemCount: svc.library.length,
                  itemBuilder: (ctx, i) {
                    final e = svc.library[i];
                    return CheckboxListTile(
                      value: chosen.contains(e.source),
                      title: Text(e.displayName, maxLines: 1, overflow: TextOverflow.ellipsis),
                      subtitle: Text(e.artist ?? ''),
                      onChanged: (v) => setS(() {
                        if (v == true) {
                          chosen.add(e.source);
                        } else {
                          chosen.remove(e.source);
                        }
                      }),
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
