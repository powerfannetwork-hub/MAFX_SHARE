import 'package:flutter/material.dart';

import '../widgets/media_browser.dart';

/// Opens the media browser on the Music tab.
class MusicScreen extends StatelessWidget {
  const MusicScreen({super.key});

  @override
  Widget build(BuildContext context) => const MediaHubScreen(initialTab: 4);
}
