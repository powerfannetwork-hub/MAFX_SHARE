import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../services/native_bridge.dart';
import '../theme.dart';

/// Asks for ONE permission when the app starts: access to all files. With it
/// the app can show and send photos, videos, music, documents, APKs and
/// everything in the file manager, run the cut / crop tools and save the
/// files it receives, without asking again for each part.
/// (Android still shows its own separate questions for Wi-Fi/Location,
/// notifications and the camera; they are asked together here, once.)
class PermissionGate extends StatefulWidget {
  const PermissionGate({super.key, required this.child});
  final Widget child;

  @override
  State<PermissionGate> createState() => _PermissionGateState();
}

class _PermissionGateState extends State<PermissionGate> with WidgetsBindingObserver {
  bool _checked = false;
  bool _granted = false;
  bool _skipped = false;
  bool _waitingSettings = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _check();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed && _waitingSettings) _check();
  }

  Future<void> _check() async {
    final sp = await SharedPreferences.getInstance();
    final ok = await Native.isAllFilesGranted();
    if (!mounted) return;
    setState(() {
      _granted = ok;
      _skipped = sp.getBool('gate_skipped') ?? false;
      _checked = true;
    });
    if (ok && _waitingSettings) {
      _waitingSettings = false;
      await _askRuntime();
    }
  }

  /// The runtime questions Android needs for Wi-Fi sharing, in one go.
  Future<void> _askRuntime() async {
    try {
      await [
        Permission.notification,
        Permission.locationWhenInUse,
        Permission.nearbyWifiDevices,
      ].request();
    } catch (_) {}
  }

  Future<void> _allow() async {
    final sdk = await Native.sdkInt();
    if (sdk >= 30) {
      _waitingSettings = true;
      final ok = await Native.requestAllFilesAccess();
      if (!ok) {
        _waitingSettings = false;
        await openAppSettings();
      }
    } else {
      await Permission.storage.request();
      await _askRuntime();
      await _check();
    }
  }

  Future<void> _skip() async {
    final sp = await SharedPreferences.getInstance();
    await sp.setBool('gate_skipped', true);
    if (mounted) setState(() => _skipped = true);
  }

  @override
  Widget build(BuildContext context) {
    if (!_checked) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }
    if (_granted || _skipped) return widget.child;
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            children: [
              const Spacer(),
              const Icon(Icons.folder_open, size: 96, color: kGreen),
              const SizedBox(height: 20),
              const Text('One permission',
                  style: TextStyle(fontSize: 26, fontWeight: FontWeight.w800)),
              const SizedBox(height: 12),
              const Text(
                'Allow MAFX SHARE to access all files.\n\n'
                'It lets the app show and send your photos, videos, music, documents and '
                'every file in the file manager, use the cut and crop tools, and save the '
                'files you receive.',
                textAlign: TextAlign.center,
              ),
              const Spacer(),
              SizedBox(
                width: double.infinity,
                height: 54,
                child: FilledButton(
                  style: FilledButton.styleFrom(
                    backgroundColor: kGreen,
                    foregroundColor: Colors.black,
                  ),
                  onPressed: _allow,
                  child: const Text('ALLOW', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w700)),
                ),
              ),
              TextButton(onPressed: _skip, child: const Text('Not now')),
            ],
          ),
        ),
      ),
    );
  }
}
