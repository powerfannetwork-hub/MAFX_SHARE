import 'package:flutter/material.dart';
import 'package:qr_flutter/qr_flutter.dart';

import '../models.dart';
import '../services/transfer_service.dart';
import '../theme.dart';

/// Receiver shows this QR code. The sender scans it.
class QrScreen extends StatefulWidget {
  const QrScreen({super.key});

  @override
  State<QrScreen> createState() => _QrScreenState();
}

class _QrScreenState extends State<QrScreen> {
  final svc = TransferService.instance;
  bool _ready = false;
  bool _paired = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    svc.pairedPeer.addListener(_onPaired);
    _start();
  }

  Future<void> _start() async {
    setState(() {
      _error = null;
      _ready = false;
    });
    try {
      await svc.startReceiver();
      if (mounted) setState(() => _ready = true);
    } catch (e) {
      if (mounted) {
        setState(() => _error = e.toString().replaceFirst('Exception: ', ''));
      }
    }
  }

  void _onPaired() {
    if (_paired || svc.pairedPeer.value == null || !mounted) return;
    _paired = true;
    // Connected: go back to Home. The transfer screen opens by itself when
    // files start to arrive, and this phone can also send from Home.
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Connection Successful')),
    );
    Navigator.of(context).popUntil((r) => r.isFirst);
  }

  @override
  void dispose() {
    svc.pairedPeer.removeListener(_onPaired);
    if (!_paired) svc.stopReceiver();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Scan to connect')),
      body: _error != null
          ? Center(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(_error!, textAlign: TextAlign.center),
                    const SizedBox(height: 16),
                    FilledButton(onPressed: _start, child: const Text('Try again')),
                  ],
                ),
              ),
            )
          : !_ready
              ? const Center(child: CircularProgressIndicator())
              : _content(),
    );
  }

  Widget _content() {
    final m = svc.mode.value;
    final is5g = m == TransferMode.fiveGPlus;
    const blue = Color(0xFF2196F3);
    const frame = Color(0xFF3DB5FF);
    final qrColor = is5g ? blue : Colors.black;
    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        const Text(
          'Scan this QR code to connect both phones.',
          textAlign: TextAlign.center,
        ),
        const SizedBox(height: 16),
        Center(
          child: SegmentedButton<TransferMode>(
            segments: const [
              ButtonSegment(
                value: TransferMode.standard,
                label: Text('Standard'),
              ),
              ButtonSegment(
                value: TransferMode.fiveGPlus,
                label: Text('5G+ (High Speed)'),
              ),
            ],
            selected: {m},
            onSelectionChanged: (s) {
              svc.mode.value = s.first;
              setState(() {});
            },
          ),
        ),
        const SizedBox(height: 16),
        Container(
          padding: const EdgeInsets.symmetric(vertical: 22, horizontal: 16),
          decoration: BoxDecoration(
            color: const Color(0xFF1B2733),
            borderRadius: BorderRadius.circular(30),
            border: Border.all(color: is5g ? frame : kGreen, width: 2),
          ),
          child: Column(
            children: [
              Icon(is5g ? Icons.speed : Icons.swap_horiz,
                  size: 44, color: is5g ? frame : kGreen),
              const SizedBox(height: 8),
              Text(
                is5g ? '5G+ High-Speed Mode' : 'Standard Mode',
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.w800,
                  color: is5g ? frame : kGreen,
                ),
              ),
              const SizedBox(height: 4),
              Text('Transfer mode',
                  style: TextStyle(color: alpha(Colors.white, 0.7))),
            ],
          ),
        ),
        const SizedBox(height: 20),
        Center(
          child: Container(
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(32),
              border: is5g ? Border.all(color: frame, width: 5) : null,
              boxShadow: [
                BoxShadow(color: alpha(is5g ? frame : kBlue, 0.5), blurRadius: 24),
              ],
            ),
            child: QrImageView(
              data: svc.qrPayload(),
              size: 250,
              backgroundColor: Colors.white,
              eyeStyle: QrEyeStyle(eyeShape: QrEyeShape.square, color: qrColor),
              dataModuleStyle: QrDataModuleStyle(
                dataModuleShape: QrDataModuleShape.square,
                color: qrColor,
              ),
            ),
          ),
        ),
        const SizedBox(height: 20),
        Container(
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
            color: const Color(0xFF1B2733),
            borderRadius: BorderRadius.circular(26),
          ),
          child: Column(
            children: [
              const Icon(Icons.wifi_tethering, size: 40, color: kGreen),
              const SizedBox(height: 8),
              const Text(
                'Waiting for connection',
                style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800),
              ),
              const SizedBox(height: 10),
              Text('Phone address',
                  style: TextStyle(color: alpha(Colors.white, 0.7))),
              Text(
                '${svc.localIp}:${svc.httpPort}',
                style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w700),
              ),
              const SizedBox(height: 10),
              Text('TCP Port',
                  style: TextStyle(color: alpha(Colors.white, 0.7))),
              Text(
                '${svc.tcpPort}',
                style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700),
              ),
              const SizedBox(height: 8),
              Text(
                'Mode: ${m.label} (${m.detail})',
                style: TextStyle(color: alpha(Colors.white, 0.6)),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
