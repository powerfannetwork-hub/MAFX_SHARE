import 'package:flutter/material.dart';
import 'package:mobile_scanner/mobile_scanner.dart';
import 'package:permission_handler/permission_handler.dart';

import '../services/transfer_service.dart';
import '../theme.dart';
import 'send_screen.dart';

/// Sender scans the receiver's QR code here.
class ScanQrScreen extends StatefulWidget {
  const ScanQrScreen({super.key});

  @override
  State<ScanQrScreen> createState() => _ScanQrScreenState();
}

class _ScanQrScreenState extends State<ScanQrScreen>
    with WidgetsBindingObserver {
  final MobileScannerController _controller = MobileScannerController(
    autoStart: false,
    detectionSpeed: DetectionSpeed.noDuplicates,
    formats: const [BarcodeFormat.qrCode],
  );
  final svc = TransferService.instance;
  bool _busy = false;
  bool _starting = false;
  bool _success = false;
  String? _error;
  String? _cameraError;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    WidgetsBinding.instance.addPostFrameCallback((_) => _startScanner());
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _controller.dispose();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed && !_success) {
      _startScanner();
    }
  }

  Future<void> _startScanner() async {
    if (!mounted || _starting || _controller.value.isRunning) return;
    _starting = true;
    setState(() => _cameraError = null);
    try {
      // Request camera permission explicitly before starting CameraX.
      final permission = await Permission.camera.request();
      if (!permission.isGranted) {
        if (mounted) {
          setState(() => _cameraError =
              permission.isPermanentlyDenied
                  ? 'Camera permission is permanently denied. Open app settings and allow Camera.'
                  : 'Camera permission was denied. Allow Camera permission and try again.');
        }
        return;
      }
      await _controller.start();
    } catch (e) {
      if (!mounted) return;
      var detail = e.toString();
      if (e is MobileScannerException) {
        detail = '${e.errorCode.name}: ${e.errorDetails?.message ?? ''}';
      }
      setState(() => _cameraError = detail);
    } finally {
      _starting = false;
    }
  }

  Future<void> _onDetect(BarcodeCapture capture) async {
    if (_busy) return;
    if (capture.barcodes.isEmpty) return;
    final raw = capture.barcodes.first.rawValue;
    if (raw == null) return;

    final data = svc.parseQr(raw);
    if (data == null) {
      setState(() => _error = 'This is not a MAFX SHARE code.');
      return;
    }

    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      await svc.connectToReceiver(
        'http://${data.ip}:${data.port}',
        data.token,
        data.mode,
        tcpPort: data.tcpPort,
      );
      await svc.announcePairing();
      if (!mounted) return;
      setState(() => _success = true);
      await Future.delayed(const Duration(milliseconds: 1300));
      if (!mounted) return;
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (_) => const SendScreen()),
      );
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _busy = false;
        _error =
            'Could not connect. Make sure both phones are on the same WiFi or Hotspot.\n(${e.toString().replaceFirst('Exception: ', '')})';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Scan QR code')),
      body: Stack(
        children: [
          MobileScanner(
            controller: _controller,
            onDetect: _onDetect,
            errorBuilder: (context, error, child) => Center(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Text(
                  'Camera error: ${error.errorCode.name}\n${error.errorDetails?.message ?? ''}\n\nAllow Camera permission in app settings, then tap Try again.',
                  textAlign: TextAlign.center,
                ),
              ),
            ),
          ),
          if (_cameraError == null)
            Center(
              child: Container(
                width: 250,
                height: 250,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(24),
                  border: Border.all(color: kGreen, width: 3),
                ),
              ),
            ),
          if (_cameraError != null)
            Container(
              color: Colors.black,
              padding: const EdgeInsets.all(24),
              child: Center(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(Icons.error_outline, size: 64, color: Colors.redAccent),
                    const SizedBox(height: 12),
                    const Text(
                      'The camera could not start',
                      style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700),
                    ),
                    const SizedBox(height: 8),
                    Text(_cameraError!, textAlign: TextAlign.center),
                    const SizedBox(height: 16),
                    FilledButton(
                      onPressed: _startScanner,
                      child: const Text('Try again'),
                    ),
                    TextButton(
                      onPressed: openAppSettings,
                      child: const Text('Open app settings'),
                    ),
                  ],
                ),
              ),
            ),
          if (_error != null)
            Positioned(
              left: 16,
              right: 16,
              bottom: 32,
              child: Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: Colors.black87,
                  borderRadius: BorderRadius.circular(16),
                ),
                child: Text(_error!, textAlign: TextAlign.center),
              ),
            ),
          if (_busy && !_success)
            Container(
              color: Colors.black54,
              child: const Center(child: CircularProgressIndicator()),
            ),
          if (_success)
            Container(
              color: kBg,
              child: const Center(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.check_circle, color: kGreen, size: 96),
                    SizedBox(height: 16),
                    Text(
                      'Connection Successful',
                      style: TextStyle(fontSize: 22, fontWeight: FontWeight.w700),
                    ),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }
}
