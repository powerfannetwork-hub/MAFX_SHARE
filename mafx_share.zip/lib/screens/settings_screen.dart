import 'package:flutter/material.dart';

import '../models.dart';
import '../services/native_bridge.dart';
import '../services/storage_service.dart';
import '../theme.dart';
import 'tools/tools_screen.dart';

/// Change storage: if the internal memory is full, save received files on
/// the SD Card / Memory Card instead.
class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  late final Future<List<StorageOption>> _options =
      StorageService.instance.options();
  int _index = StorageService.instance.selectedIndex;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Settings')),
      body: FutureBuilder<List<StorageOption>>(
        future: _options,
        builder: (context, snap) {
          if (!snap.hasData) {
            return const Center(child: CircularProgressIndicator());
          }
          final opts = snap.data!;
          return ListView(
            padding: const EdgeInsets.all(16),
            children: [
              const Text(
                'Change storage',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.w700),
              ),
              const SizedBox(height: 6),
              const Text(
                'Choose where received files are saved. If the internal '
                'storage is full, switch to the SD Card / Memory Card.',
              ),
              const SizedBox(height: 16),
              for (var i = 0; i < opts.length; i++)
                Container(
                  margin: const EdgeInsets.only(bottom: 10),
                  decoration: BoxDecoration(
                    color: kPanel,
                    borderRadius: BorderRadius.circular(18),
                    border: Border.all(
                      color: i == _index ? kGreen : Colors.transparent,
                    ),
                  ),
                  child: ListTile(
                    leading: Icon(
                      i == _index
                          ? Icons.radio_button_checked
                          : Icons.radio_button_unchecked,
                      color: i == _index ? kGreen : null,
                    ),
                    title: Text(opts[i].label),
                    subtitle: Text(opts[i].path),
                    onTap: () async {
                      await StorageService.instance.setSelectedIndex(i);
                      setState(() => _index = i);
                    },
                  ),
                ),
              if (opts.length == 1)
                const Padding(
                  padding: EdgeInsets.only(top: 8),
                  child: Text('No SD Card / Memory Card was found on this phone.'),
                ),
              const SizedBox(height: 8),
              const Text(
                'On the phone\'s main storage, received files are saved to the public '
                'folders Pictures, Movies, Music and Download (inside "MAFX SHARE") so '
                'other apps can see them. On an SD card they stay in the app folder.',
                style: TextStyle(fontSize: 12, color: Colors.white60),
              ),
              const SizedBox(height: 28),
              const _TransferInfo(),
              const SizedBox(height: 28),
              const ToolsSection(),
              const SizedBox(height: 24),
            ],
          );
        },
      ),
    );
  }
}

/// Shows the transfer profile chosen for this phone and lets the user allow
/// background transfers (battery optimisation).
class _TransferInfo extends StatefulWidget {
  const _TransferInfo();

  @override
  State<_TransferInfo> createState() => _TransferInfoState();
}

class _TransferInfoState extends State<_TransferInfo> with WidgetsBindingObserver {
  bool? _unrestricted;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _check();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) _check();
  }

  Future<void> _check() async {
    final v = await Native.isIgnoringBattery();
    if (mounted) setState(() => _unrestricted = v);
  }

  @override
  Widget build(BuildContext context) {
    final m = TransferMode.recommended;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Transfer engine',
          style: TextStyle(fontSize: 20, fontWeight: FontWeight.w700),
        ),
        const SizedBox(height: 8),
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(color: kPanel, borderRadius: BorderRadius.circular(18)),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Profile for this phone: ${m.label}',
                  style: const TextStyle(fontWeight: FontWeight.w700, color: kGreen)),
              const SizedBox(height: 6),
              Text('${m.chunkSize ~/ 1048576} MiB chunks • ${m.streams} parallel streams '
                  '(grows up to ${m.maxStreams} while the speed improves) • '
                  '${m.bufferSize ~/ 1024} KiB buffer'),
              const SizedBox(height: 6),
              const Text(
                'Chosen automatically from this phone\'s memory and processor. When two '
                'phones connect, the slower profile of the two is used.',
                style: TextStyle(fontSize: 12, color: Colors.white60),
              ),
            ],
          ),
        ),
        const SizedBox(height: 10),
        Container(
          decoration: BoxDecoration(color: kPanel, borderRadius: BorderRadius.circular(18)),
          child: ListTile(
            leading: Icon(
              _unrestricted == true ? Icons.battery_charging_full : Icons.battery_alert,
              color: _unrestricted == true ? kGreen : Colors.orangeAccent,
            ),
            title: const Text('Battery: allow background transfer'),
            subtitle: Text(_unrestricted == true
                ? 'Not restricted. Long transfers keep running.'
                : 'Tap and choose "Don\'t optimize" for MAFX SHARE so long transfers are not stopped.'),
            onTap: Native.openBatterySettings,
          ),
        ),
      ],
    );
  }
}
