import 'dart:io';
import 'dart:math' as math;
import 'dart:typed_data';
import 'dart:ui' as ui;

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:path/path.dart' as p;

import '../../services/native_bridge.dart';
import '../../theme.dart';
import 'tool_common.dart';

enum _Drag { none, move, tl, tr, bl, br }

/// Image Crop: choose an image, rotate it, drag the crop frame (free or fixed
/// aspect ratio), preview the result and save it to Pictures/MAFX SHARE.
class ImageCropScreen extends StatefulWidget {
  const ImageCropScreen({super.key});

  @override
  State<ImageCropScreen> createState() => _ImageCropScreenState();
}

class _ImageCropScreenState extends State<ImageCropScreen> {
  String? _path;
  ui.Image? _src;
  ui.Image? _view;
  int _turns = 0;
  Rect _crop = const Rect.fromLTRB(0.05, 0.05, 0.95, 0.95); // normalized
  double? _ratio; // width / height, null = free
  _Drag _mode = _Drag.none;
  bool _busy = false;

  @override
  void dispose() {
    _src?.dispose();
    if (_view != _src) _view?.dispose();
    super.dispose();
  }

  Future<void> _pick() async {
    final path = await pickOne(context, FileType.image);
    if (path == null) return;
    try {
      final bytes = await File(path).readAsBytes();
      final codec = await ui.instantiateImageCodec(bytes);
      final frame = await codec.getNextFrame();
      final img = frame.image;
      if (!mounted) return;
      _src?.dispose();
      if (_view != null && _view != _src) _view!.dispose();
      setState(() {
        _path = path;
        _src = img;
        _view = img;
        _turns = 0;
        _ratio = null;
        _crop = const Rect.fromLTRB(0.05, 0.05, 0.95, 0.95);
      });
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(const SnackBar(content: Text('This image cannot be opened.')));
      }
    }
  }

  Future<ui.Image> _rotated(ui.Image src, int turns) async {
    final t = turns % 4;
    if (t == 0) return src;
    final w = src.width.toDouble();
    final h = src.height.toDouble();
    final odd = t.isOdd;
    final ow = odd ? h : w;
    final oh = odd ? w : h;
    final rec = ui.PictureRecorder();
    final canvas = Canvas(rec);
    canvas.translate(ow / 2, oh / 2);
    canvas.rotate(t * math.pi / 2);
    canvas.translate(-w / 2, -h / 2);
    canvas.drawImage(src, Offset.zero, Paint());
    final pic = rec.endRecording();
    return pic.toImage(ow.round(), oh.round());
  }

  Future<void> _rotate(int dir) async {
    final src = _src;
    if (src == null) return;
    final turns = (_turns + dir) % 4;
    final next = await _rotated(src, turns < 0 ? turns + 4 : turns);
    if (!mounted) return;
    final old = _view;
    setState(() {
      _turns = turns < 0 ? turns + 4 : turns;
      _view = next;
      _crop = const Rect.fromLTRB(0.05, 0.05, 0.95, 0.95);
      _ratio = null;
    });
    if (old != null && old != _src && old != next) old.dispose();
  }

  void _setRatio(double? r) {
    final v = _view;
    if (v == null) return;
    setState(() {
      _ratio = r;
      if (r == null) return;
      // Largest centred frame with this ratio.
      final vw = v.width.toDouble();
      final vh = v.height.toDouble();
      var w = 0.9;
      var h = w * vw / (vh * r);
      if (h > 0.9) {
        h = 0.9;
        w = h * vh * r / vw;
      }
      _crop = Rect.fromCenter(center: const Offset(0.5, 0.5), width: w, height: h);
    });
  }

  Rect _destRect(Size box) {
    final v = _view!;
    final fitted = applyBoxFit(BoxFit.contain, Size(v.width.toDouble(), v.height.toDouble()), box);
    return Alignment.center.inscribe(fitted.destination, Offset.zero & box);
  }

  Rect _cropPx(Rect dest) => Rect.fromLTRB(
        dest.left + _crop.left * dest.width,
        dest.top + _crop.top * dest.height,
        dest.left + _crop.right * dest.width,
        dest.top + _crop.bottom * dest.height,
      );

  void _dragStart(Offset pos, Rect dest) {
    final r = _cropPx(dest);
    const t = 40.0;
    if ((pos - r.topLeft).distance < t) {
      _mode = _Drag.tl;
    } else if ((pos - r.topRight).distance < t) {
      _mode = _Drag.tr;
    } else if ((pos - r.bottomLeft).distance < t) {
      _mode = _Drag.bl;
    } else if ((pos - r.bottomRight).distance < t) {
      _mode = _Drag.br;
    } else if (r.contains(pos)) {
      _mode = _Drag.move;
    } else {
      _mode = _Drag.none;
    }
  }

  void _dragUpdate(Offset delta, Rect dest) {
    if (_mode == _Drag.none) return;
    final v = _view!;
    final dx = delta.dx / dest.width;
    final dy = delta.dy / dest.height;
    var r = _crop;
    const minSize = 0.06;
    if (_mode == _Drag.move) {
      var l = r.left + dx;
      var t = r.top + dy;
      l = l.clamp(0.0, 1.0 - r.width).toDouble();
      t = t.clamp(0.0, 1.0 - r.height).toDouble();
      setState(() => _crop = Rect.fromLTWH(l, t, r.width, r.height));
      return;
    }
    // The corner opposite to the dragged one stays still.
    late Offset anchor;
    late Offset moving;
    switch (_mode) {
      case _Drag.tl:
        anchor = r.bottomRight;
        moving = r.topLeft + Offset(dx, dy);
      case _Drag.tr:
        anchor = r.bottomLeft;
        moving = r.topRight + Offset(dx, dy);
      case _Drag.bl:
        anchor = r.topRight;
        moving = r.bottomLeft + Offset(dx, dy);
      case _Drag.br:
        anchor = r.topLeft;
        moving = r.bottomRight + Offset(dx, dy);
      default:
        return;
    }
    var mx = moving.dx.clamp(0.0, 1.0).toDouble();
    var my = moving.dy.clamp(0.0, 1.0).toDouble();
    if (_ratio != null) {
      final vw = v.width.toDouble();
      final vh = v.height.toDouble();
      var w = (mx - anchor.dx).abs();
      var h = w * vw / (vh * _ratio!);
      final sx = mx >= anchor.dx ? 1.0 : -1.0;
      final sy = my >= anchor.dy ? 1.0 : -1.0;
      // keep inside the picture
      final maxW = sx > 0 ? 1.0 - anchor.dx : anchor.dx;
      final maxH = sy > 0 ? 1.0 - anchor.dy : anchor.dy;
      if (w > maxW) {
        w = maxW;
        h = w * vw / (vh * _ratio!);
      }
      if (h > maxH) {
        h = maxH;
        w = h * vh * _ratio! / vw;
      }
      mx = anchor.dx + sx * w;
      my = anchor.dy + sy * h;
    }
    var nr = Rect.fromPoints(anchor, Offset(mx, my));
    if (nr.width < minSize || nr.height < minSize) return;
    setState(() => _crop = nr);
  }

  Future<Uint8List?> _renderCrop() async {
    final v = _view;
    if (v == null) return null;
    final src = Rect.fromLTRB(
      (_crop.left * v.width).roundToDouble(),
      (_crop.top * v.height).roundToDouble(),
      (_crop.right * v.width).roundToDouble(),
      (_crop.bottom * v.height).roundToDouble(),
    );
    final w = math.max(1, src.width.round());
    final h = math.max(1, src.height.round());
    final rec = ui.PictureRecorder();
    final canvas = Canvas(rec);
    canvas.drawImageRect(
      v,
      src,
      Rect.fromLTWH(0, 0, w.toDouble(), h.toDouble()),
      Paint()..filterQuality = FilterQuality.high,
    );
    final out = await rec.endRecording().toImage(w, h);
    final data = await out.toByteData(format: ui.ImageByteFormat.png);
    out.dispose();
    return data?.buffer.asUint8List();
  }

  Future<void> _previewAndSave() async {
    setState(() => _busy = true);
    final bytes = await _renderCrop();
    if (!mounted) return;
    setState(() => _busy = false);
    if (bytes == null) {
      ScaffoldMessenger.of(context)
          .showSnackBar(const SnackBar(content: Text('Could not create the image.')));
      return;
    }
    final format = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Preview'),
        content: SizedBox(
          width: 320,
          child: Image.memory(bytes, fit: BoxFit.contain),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Back')),
          TextButton(onPressed: () => Navigator.pop(ctx, 'png'), child: const Text('Save PNG')),
          FilledButton(onPressed: () => Navigator.pop(ctx, 'jpg'), child: const Text('Save JPG')),
        ],
      ),
    );
    if (format == null || !mounted) return;
    setState(() => _busy = true);
    try {
      final base = p.basenameWithoutExtension(_path ?? 'image');
      final r = await Native.saveImage(
        bytes,
        '${base}_crop_${DateTime.now().millisecondsSinceEpoch ~/ 1000}.$format',
        format: format,
      );
      if (mounted) await showSaved(context, r);
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text('Save failed: $e')));
      }
    }
    if (mounted) setState(() => _busy = false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Image Crop'),
        actions: [
          if (_view != null)
            IconButton(
              tooltip: 'Choose another image',
              icon: const Icon(Icons.image_search),
              onPressed: _busy ? null : _pick,
            ),
        ],
      ),
      body: _view == null
          ? PickPrompt(icon: Icons.crop, label: 'Choose an image', onTap: _pick)
          : Column(
              children: [
                Expanded(
                  child: LayoutBuilder(builder: (context, box) {
                    final size = Size(box.maxWidth, box.maxHeight);
                    final dest = _destRect(size);
                    return GestureDetector(
                      behavior: HitTestBehavior.opaque,
                      onPanStart: (d) => _dragStart(d.localPosition, dest),
                      onPanUpdate: (d) => _dragUpdate(d.delta, dest),
                      onPanEnd: (_) => _mode = _Drag.none,
                      child: CustomPaint(
                        size: size,
                        painter: _CropPainter(_view!, dest, _cropPx(dest)),
                      ),
                    );
                  }),
                ),
                SizedBox(
                  height: 44,
                  child: ListView(
                    scrollDirection: Axis.horizontal,
                    padding: const EdgeInsets.symmetric(horizontal: 12),
                    children: [
                      for (final e in <(String, double?)>[
                        ('Free', null),
                        ('1:1', 1),
                        ('4:3', 4 / 3),
                        ('3:4', 3 / 4),
                        ('16:9', 16 / 9),
                        ('9:16', 9 / 16),
                      ])
                        Padding(
                          padding: const EdgeInsets.only(right: 8),
                          child: ChoiceChip(
                            label: Text(e.$1),
                            selected: _ratio == e.$2,
                            selectedColor: alpha(kGreen, 0.35),
                            onSelected: (_) => _setRatio(e.$2),
                          ),
                        ),
                    ],
                  ),
                ),
                SafeArea(
                  top: false,
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(12, 4, 12, 8),
                    child: Row(
                      children: [
                        IconButton(
                          tooltip: 'Rotate left',
                          icon: const Icon(Icons.rotate_left),
                          onPressed: _busy ? null : () => _rotate(-1),
                        ),
                        IconButton(
                          tooltip: 'Rotate right',
                          icon: const Icon(Icons.rotate_right),
                          onPressed: _busy ? null : () => _rotate(1),
                        ),
                        const Spacer(),
                        FilledButton.icon(
                          style: FilledButton.styleFrom(
                              backgroundColor: kGreen, foregroundColor: Colors.black),
                          onPressed: _busy ? null : _previewAndSave,
                          icon: _busy
                              ? const SizedBox(
                                  width: 18,
                                  height: 18,
                                  child: CircularProgressIndicator(strokeWidth: 2, color: Colors.black),
                                )
                              : const Icon(Icons.check),
                          label: const Text('Preview & save'),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
    );
  }
}

class _CropPainter extends CustomPainter {
  _CropPainter(this.image, this.dest, this.crop);
  final ui.Image image;
  final Rect dest;
  final Rect crop;

  @override
  void paint(Canvas canvas, Size size) {
    paintImage(canvas: canvas, rect: dest, image: image, fit: BoxFit.fill);
    final shade = Paint()..color = const Color(0xAA000000);
    canvas.drawRect(Rect.fromLTRB(dest.left, dest.top, dest.right, crop.top), shade);
    canvas.drawRect(Rect.fromLTRB(dest.left, crop.bottom, dest.right, dest.bottom), shade);
    canvas.drawRect(Rect.fromLTRB(dest.left, crop.top, crop.left, crop.bottom), shade);
    canvas.drawRect(Rect.fromLTRB(crop.right, crop.top, dest.right, crop.bottom), shade);
    final line = Paint()
      ..color = Colors.white
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.5;
    canvas.drawRect(crop, line);
    final grid = Paint()
      ..color = const Color(0x66FFFFFF)
      ..strokeWidth = 0.8;
    for (var i = 1; i < 3; i++) {
      final x = crop.left + crop.width * i / 3;
      final y = crop.top + crop.height * i / 3;
      canvas.drawLine(Offset(x, crop.top), Offset(x, crop.bottom), grid);
      canvas.drawLine(Offset(crop.left, y), Offset(crop.right, y), grid);
    }
    final handle = Paint()..color = kGreen;
    for (final c in [crop.topLeft, crop.topRight, crop.bottomLeft, crop.bottomRight]) {
      canvas.drawCircle(c, 9, handle);
    }
  }

  @override
  bool shouldRepaint(covariant _CropPainter old) =>
      old.image != image || old.dest != dest || old.crop != crop;
}
