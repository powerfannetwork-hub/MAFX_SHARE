import 'dart:async';
import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:path/path.dart' as p;
import 'package:video_player/video_player.dart';

import '../../services/music_service.dart';
import '../../services/native_bridge.dart';
import '../../theme.dart';
import 'tool_common.dart';

/// MP3 Cutter: choose an audio file, preview, pick start / end and export
/// to Music/MAFX SHARE. MP3 files stay MP3 (frames are copied, no quality
/// loss); AAC/M4A stay M4A; other formats are saved as WAV.
class Mp3CutterScreen extends StatefulWidget {
  const Mp3CutterScreen({super.key});

  @override
  State<Mp3CutterScreen> createState() => _Mp3CutterScreenState();
}

class _Mp3CutterScreenState extends State<Mp3CutterScreen> {
  String? _path;
  VideoPlayerController? _c; // plays audio too; avoids a 2nd just_audio player
  RangeValues _range = const RangeValues(0, 1);
  bool _busy = false;
  bool _previewRange = false;

  @override
  void dispose() {
    _c?.removeListener(_tick);
    _c?.dispose();
    super.dispose();
  }

  Future<void> _pick() async {
    final path = await pickOne(context, FileType.audio);
    if (path == null) return;
    unawaited(MusicService.instance.pause());
    _c?.removeListener(_tick);
    await _c?.dispose();
    final c = VideoPlayerController.file(File(path));
    try {
      await c.initialize();
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(const SnackBar(content: Text('This audio file cannot be opened.')));
      }
      return;
    }
    c.addListener(_tick);
    if (!mounted) return;
    setState(() {
      _c = c;
      _path = path;
      _range = RangeValues(0, c.value.duration.inMilliseconds.toDouble());
    });
  }

  void _tick() {
    final c = _c;
    if (c == null) return;
    if (_previewRange && c.value.position.inMilliseconds >= _range.end) {
      c.pause();
      _previewRange = false;
    }
    if (mounted) setState(() {});
  }

  Future<void> _previewSelection() async {
    final c = _c;
    if (c == null) return;
    await c.seekTo(Duration(milliseconds: _range.start.round()));
    _previewRange = true;
    await c.play();
  }

  Future<void> _cut() async {
    final path = _path;
    if (path == null) return;
    setState(() => _busy = true);
    try {
      await _c?.pause();
      final base = p.basenameWithoutExtension(path);
      final r = await Native.cutAudio(path, _range.start.round(), _range.end.round(),
          '${base}_cut_${DateTime.now().millisecondsSinceEpoch ~/ 1000}');
      if (mounted) await showSaved(context, r);
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text('Export failed: ${cleanError(e)}')));
      }
    }
    if (mounted) setState(() => _busy = false);
  }


  @override
  Widget build(BuildContext context) {
    final c = _c;
    return Scaffold(
      appBar: AppBar(
        title: const Text('MP3 Cutter'),
        actions: [
          if (c != null)
            IconButton(
              tooltip: 'Choose another file',
              icon: const Icon(Icons.library_music_outlined),
              onPressed: _busy ? null : _pick,
            ),
        ],
      ),
      body: c == null
          ? PickPrompt(icon: Icons.audiotrack, label: 'Choose an audio file', onTap: _pick)
          : ListView(
              padding: const EdgeInsets.all(16),
              children: [
                ListTile(
                  leading: const CircleAvatar(
                    backgroundColor: kPanel,
                    child: Icon(Icons.music_note, color: kBlue),
                  ),
                  title: Text(p.basename(_path!), maxLines: 1, overflow: TextOverflow.ellipsis),
                  subtitle: Text('Length ${fmtMs(c.value.duration.inMilliseconds)}'),
                  trailing: IconButton.filled(
                    icon: Icon(c.value.isPlaying ? Icons.pause : Icons.play_arrow),
                    onPressed: () {
                      _previewRange = false;
                      c.value.isPlaying ? c.pause() : c.play();
                    },
                  ),
                ),
                Slider(
                  value: c.value.position.inMilliseconds
                      .clamp(0, c.value.duration.inMilliseconds)
                      .toDouble(),
                  max: c.value.duration.inMilliseconds.toDouble().clamp(1.0, double.infinity).toDouble(),
                  activeColor: kBlue,
                  onChanged: (v) => c.seekTo(Duration(milliseconds: v.round())),
                ),
                Text(fmtMs(c.value.position.inMilliseconds), textAlign: TextAlign.center),
                const SizedBox(height: 8),
                RangePicker(
                  totalMs: c.value.duration.inMilliseconds,
                  range: _range,
                  currentMs: c.value.position.inMilliseconds,
                  onChanged: (r) => setState(() => _range = r),
                ),
                const SizedBox(height: 12),
                Row(
                  children: [
                    Expanded(
                      child: OutlinedButton.icon(
                        onPressed: _busy ? null : _previewSelection,
                        icon: const Icon(Icons.play_circle_outline),
                        label: const Text('Preview'),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: FilledButton.icon(
                        style: FilledButton.styleFrom(backgroundColor: kGreen, foregroundColor: Colors.black),
                        onPressed: _busy ? null : _cut,
                        icon: _busy
                            ? const SizedBox(
                                width: 18,
                                height: 18,
                                child: CircularProgressIndicator(strokeWidth: 2, color: Colors.black),
                              )
                            : const Icon(Icons.content_cut),
                        label: Text(_busy ? 'Exporting...' : 'Export'),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                const Text(
                  'Saved to Music/MAFX SHARE.\nMP3 stays MP3, AAC/M4A stays M4A, other formats are saved as WAV.',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: Colors.white60, fontSize: 12),
                ),
              ],
            ),
    );
  }
}
