import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../services/native_bridge.dart';
import '../../theme.dart';

/// Readable message from a native error.
String cleanError(Object e) =>
    e is PlatformException ? (e.message ?? e.code) : e.toString();

String fmtMs(int ms) {
  final d = Duration(milliseconds: ms);
  final h = d.inHours;
  final m = d.inMinutes.remainder(60).toString().padLeft(2, '0');
  final s = d.inSeconds.remainder(60).toString().padLeft(2, '0');
  final t = (d.inMilliseconds.remainder(1000) ~/ 100).toString();
  return h > 0 ? '$h:$m:$s.$t' : '${d.inMinutes}:$s.$t';
}

/// Picks one file of [type]. Returns its path (null = cancelled).
Future<String?> pickOne(BuildContext context, FileType type) async {
  try {
    final r = await FilePicker.platform.pickFiles(type: type, allowMultiple: false);
    return r?.files.single.path;
  } catch (e) {
    if (context.mounted) {
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text('Could not pick a file: $e')));
    }
    return null;
  }
}

/// Shows where the result was saved.
Future<void> showSaved(BuildContext context, PublishResult r, {String? note}) {
  return showDialog<void>(
    context: context,
    builder: (ctx) => AlertDialog(
      title: const Text('Saved'),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Folder: ${r.dir}'),
          if (r.name.isNotEmpty) Text('File: ${r.name}'),
          if (note != null) ...[const SizedBox(height: 8), Text(note)],
        ],
      ),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('OK')),
      ],
    ),
  );
}

/// Start / end selector with fine-tune buttons.
class RangePicker extends StatelessWidget {
  const RangePicker({
    super.key,
    required this.totalMs,
    required this.range,
    required this.onChanged,
    required this.currentMs,
  });

  final int totalMs;
  final RangeValues range;
  final ValueChanged<RangeValues> onChanged;
  final int currentMs;

  @override
  Widget build(BuildContext context) {
    final total = totalMs <= 0 ? 1.0 : totalMs.toDouble();
    RangeValues clampR(double s, double e) {
      s = s.clamp(0.0, total).toDouble();
      e = e.clamp(0.0, total).toDouble();
      if (e - s < 500) {
        if (s + 500 <= total) {
          e = s + 500;
        } else {
          s = math(total - 500);
          e = total;
        }
      }
      return RangeValues(s, e);
    }

    Widget fine(String label, double start, double end) => Expanded(
          child: Column(
            children: [
              Text(label, style: const TextStyle(color: kGreen)),
              Text(fmtMs((label == 'Start' ? start : end).round()),
                  style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  IconButton(
                    visualDensity: VisualDensity.compact,
                    icon: const Icon(Icons.remove_circle_outline),
                    onPressed: () => onChanged(label == 'Start'
                        ? clampR(start - 1000, end)
                        : clampR(start, end - 1000)),
                  ),
                  IconButton(
                    visualDensity: VisualDensity.compact,
                    icon: const Icon(Icons.add_circle_outline),
                    onPressed: () => onChanged(label == 'Start'
                        ? clampR(start + 1000, end)
                        : clampR(start, end + 1000)),
                  ),
                ],
              ),
              TextButton(
                onPressed: () => onChanged(label == 'Start'
                    ? clampR(currentMs.toDouble(), end)
                    : clampR(start, currentMs.toDouble())),
                child: Text('Set $label = now'),
              ),
            ],
          ),
        );

    return Column(
      children: [
        RangeSlider(
          values: RangeValues(range.start.clamp(0.0, total).toDouble(),
              range.end.clamp(0.0, total).toDouble()),
          min: 0,
          max: total,
          activeColor: kGreen,
          onChanged: (v) => onChanged(clampR(v.start, v.end)),
        ),
        Row(children: [fine('Start', range.start, range.end), fine('End', range.start, range.end)]),
        Text('Selected: ${fmtMs((range.end - range.start).round())}'),
      ],
    );
  }

  static double math(double v) => v < 0 ? 0 : v;
}

/// Big "choose a file" placeholder.
class PickPrompt extends StatelessWidget {
  const PickPrompt({super.key, required this.icon, required this.label, required this.onTap});
  final IconData icon;
  final String label;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: InkWell(
        borderRadius: BorderRadius.circular(24),
        onTap: onTap,
        child: Container(
          width: 240,
          padding: const EdgeInsets.symmetric(vertical: 36),
          decoration: BoxDecoration(
            color: kPanel,
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: alpha(kBlue, 0.6)),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(icon, size: 56, color: kBlue),
              const SizedBox(height: 12),
              Text(label, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
            ],
          ),
        ),
      ),
    );
  }
}

bool fileExists(String path) => File(path).existsSync();
