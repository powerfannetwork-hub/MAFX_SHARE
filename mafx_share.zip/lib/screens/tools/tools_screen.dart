import 'package:flutter/material.dart';

import '../../theme.dart';
import 'image_crop_screen.dart';
import 'mp3_cutter_screen.dart';
import 'video_cutter_screen.dart';
import 'video_to_mp3_screen.dart';

/// "VIDEO & AUDIO TOOLS" section of Settings.
class ToolsSection extends StatelessWidget {
  const ToolsSection({super.key});

  @override
  Widget build(BuildContext context) {
    Widget tile(IconData icon, String title, String sub, Color color, Widget Function() page) {
      return Container(
        margin: const EdgeInsets.only(bottom: 10),
        decoration: BoxDecoration(color: kPanel, borderRadius: BorderRadius.circular(18)),
        child: ListTile(
          leading: CircleAvatar(
            backgroundColor: alpha(color, 0.22),
            child: Icon(icon, color: color),
          ),
          title: Text(title, style: const TextStyle(fontWeight: FontWeight.w600)),
          subtitle: Text(sub),
          trailing: const Icon(Icons.chevron_right),
          onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => page())),
        ),
      );
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'VIDEO & AUDIO TOOLS',
          style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800, letterSpacing: 0.6),
        ),
        const SizedBox(height: 10),
        tile(Icons.content_cut, 'Video Cutter', 'Cut a part of a video → Movies/MAFX SHARE',
            kBlue, () => const VideoCutterScreen()),
        tile(Icons.audiotrack, 'MP3 Cutter', 'Cut a part of a song → Music/MAFX SHARE',
            kGreen, () => const Mp3CutterScreen()),
        tile(Icons.audio_file_outlined, 'Video to MP3', 'Extract the sound of a video → Music/MAFX SHARE',
            kBlue, () => const VideoToMp3Screen()),
        tile(Icons.crop, 'Image Crop', 'Crop and rotate a picture → Pictures/MAFX SHARE',
            kGreen, () => const ImageCropScreen()),
      ],
    );
  }
}
