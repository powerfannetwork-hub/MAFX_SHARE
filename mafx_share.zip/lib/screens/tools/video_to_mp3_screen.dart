import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:path/path.dart' as p;

import '../../services/native_bridge.dart';
import '../../theme.dart';
import 'tool_common.dart';

/// Video to MP3: extracts the sound track of a video into Music/MAFX SHARE.
/// If the video's audio is MP3 the result is an .mp3 file. Android cannot
/// encode new MP3 files, so AAC audio (most videos) is saved as .m4a (no
/// quality loss) and other audio formats as .wav.
class VideoToMp3Screen extends StatefulWidget {
  const VideoToMp3Screen({super.key});

  @override
  State<VideoToMp3Screen> createState() => _VideoToMp3ScreenState();
}

class _VideoToMp3ScreenState extends State<VideoToMp3Screen> {
  String? _path;
  Map<String, dynamic> _info = {};
  bool _busy = false;

  Future<void> _pick() async {
    final path = await pickOne(context, FileType.video);
    if (path == null) return;
    final info = await Native.mediaInfo(path);
    if (!mounted) return;
    setState(() {
      _path = path;
      _info = info;
    });
  }

  Future<void> _extract() async {
    final path = _path;
    if (path == null) return;
    setState(() => _busy = true);
    try {
      final r = await Native.extractAudio(path, p.basenameWithoutExtension(path));
      if (mounted) {
        final isMp3 = r.name.toLowerCase().endsWith('.mp3');
        await showSaved(context, r,
            note: isMp3
                ? null
                : 'The audio of this video is not MP3, so it was saved without re-encoding '
                    'as ${p.extension(r.name).toUpperCase().replaceFirst('.', '')}.');
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text('Extraction failed: ${cleanError(e)}'),
        ));
      }
    }
    if (mounted) setState(() => _busy = false);
  }

  @override
  Widget build(BuildContext context) {
    final path = _path;
    final dur = int.tryParse((_info['durationMs'] ?? '0').toString()) ?? 0;
    int? size;
    if (path != null) {
      try {
        size = File(path).lengthSync();
      } catch (_) {}
    }
    return Scaffold(
      appBar: AppBar(title: const Text('Video to MP3')),
      body: path == null
          ? PickPrompt(icon: Icons.audio_file_outlined, label: 'Choose a video', onTap: _pick)
          : Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: kPanel,
                      borderRadius: BorderRadius.circular(18),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(p.basename(path),
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(fontWeight: FontWeight.w700)),
                        const SizedBox(height: 6),
                        Text('Length: ${fmtMs(dur)}'),
                        if (size != null) Text('Size: ${formatSize(size)}'),
                      ],
                    ),
                  ),
                  const SizedBox(height: 18),
                  FilledButton.icon(
                    style: FilledButton.styleFrom(
                      backgroundColor: kGreen,
                      foregroundColor: Colors.black,
                      padding: const EdgeInsets.symmetric(vertical: 14),
                    ),
                    onPressed: _busy ? null : _extract,
                    icon: _busy
                        ? const SizedBox(
                            width: 18,
                            height: 18,
                            child: CircularProgressIndicator(strokeWidth: 2, color: Colors.black),
                          )
                        : const Icon(Icons.audiotrack),
                    label: Text(_busy ? 'Extracting...' : 'Extract audio'),
                  ),
                  TextButton(
                    onPressed: _busy ? null : _pick,
                    child: const Text('Choose another video'),
                  ),
                  const Spacer(),
                  const Text(
                    'Saved to Music/MAFX SHARE.\nMP3 audio stays MP3. Other audio is saved '
                    'without re-encoding (M4A) or as WAV, because Android cannot create new MP3 files.',
                    textAlign: TextAlign.center,
                    style: TextStyle(color: Colors.white60, fontSize: 12),
                  ),
                ],
              ),
            ),
    );
  }
}
