import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:path/path.dart' as p;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:video_player/video_player.dart';

import '../services/music_service.dart';
import '../services/native_bridge.dart';
import '../services/subtitle.dart';
import '../theme.dart';

enum _Orient { auto, landscape, portrait }

enum _Fit { fit, fill, stretch, zoom }

/// Video player with MX-Player style gestures:
///  * tap = show / hide controls, double tap left / right = -10 s / +10 s
///  * swipe left / right = seek, swipe up / down on the left = brightness,
///    on the right = volume
///  * speed 0.5x - 2x, lock, fullscreen, rotation, picture size, SRT
///    subtitles with delay, resume, video info.
class VideoPlayerScreen extends StatefulWidget {
  const VideoPlayerScreen({
    super.key,
    required this.source,
    this.name,
    this.size,
  });

  /// File path or content:// URI.
  final String source;
  final String? name;
  final int? size;

  @override
  State<VideoPlayerScreen> createState() => _VideoPlayerScreenState();
}

class _VideoPlayerScreenState extends State<VideoPlayerScreen>
    with WidgetsBindingObserver {
  late final VideoPlayerController _c = widget.source.startsWith('content://')
      ? VideoPlayerController.contentUri(Uri.parse(widget.source))
      : VideoPlayerController.file(File(widget.source));

  bool _ready = false;
  String? _error;

  bool _showControls = true;
  bool _locked = false;
  bool _fullscreen = false;
  Timer? _hideTimer;
  _Orient _orient = _Orient.auto;
  _Fit _fit = _Fit.fit;
  int _turns = 0; // picture rotation (quarter turns)

  Duration? _pendingSeek;
  bool _seeking = false;

  bool _swiping = false;
  Duration _swipeStart = Duration.zero;
  Duration _swipeTarget = Duration.zero;
  double _swipeDx = 0;

  bool _scrubbing = false;
  double _scrubMs = 0;

  String? _flash;
  Timer? _flashTimer;
  double _speed = 1.0;

  // brightness / volume gestures
  String? _sideKind; // 'brightness' | 'volume' (null when no finger)
  String _sideShown = 'brightness';
  double _sideValue = 0;
  double _sideStart = 0;
  double _sideDy = 0;
  Timer? _sideTimer;
  bool _sideVisible = false;

  // subtitles
  List<SubtitleCue> _cues = [];
  bool _subsOn = true;
  int _subDelayMs = 0;
  String? _subText;
  String? _subName;

  Timer? _saveTimer;

  String get _title => widget.name ?? p.basename(Uri.parse(widget.source).path);
  String get _resumeKey => 'resume:${widget.name ?? ''}:${widget.source}';

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    SystemChrome.setPreferredOrientations(DeviceOrientation.values);
    Native.keepScreenOn(true);
    unawaited(MusicService.instance.pause());
    _init();
  }

  Future<void> _init() async {
    try {
      await _c.initialize();
      if (!mounted) return;
      setState(() => _ready = true);
      _c.addListener(_onTick);
      if (_c.value.aspectRatio > 1.0) _setOrient(_Orient.landscape);
      await _resume();
      await _autoSubtitle();
      await _c.play();
      _scheduleHide();
      _saveTimer = Timer.periodic(const Duration(seconds: 5), (_) => _saveResume());
    } catch (_) {
      if (mounted) setState(() => _error = 'This video cannot be played.');
    }
  }

  // ------------------------------------------------------------- resume

  Future<void> _resume() async {
    try {
      final sp = await SharedPreferences.getInstance();
      final ms = sp.getInt(_resumeKey) ?? 0;
      final total = _c.value.duration.inMilliseconds;
      if (ms > 5000 && ms < total - 5000) {
        await _c.seekTo(Duration(milliseconds: ms));
        if (!mounted) return;
        ScaffoldMessenger.of(context)
          ..hideCurrentSnackBar()
          ..showSnackBar(SnackBar(
            content: Text('Resumed from ${_fmt(Duration(milliseconds: ms))}'),
            action: SnackBarAction(
              label: 'Start over',
              onPressed: () => _requestSeek(Duration.zero),
            ),
          ));
      }
    } catch (_) {}
  }

  Future<void> _saveResume() async {
    if (!_ready) return;
    try {
      final sp = await SharedPreferences.getInstance();
      final pos = _c.value.position.inMilliseconds;
      final total = _c.value.duration.inMilliseconds;
      if (pos < 5000 || pos > total - 5000) {
        await sp.remove(_resumeKey);
      } else {
        await sp.setInt(_resumeKey, pos);
      }
    } catch (_) {}
  }

  // ---------------------------------------------------------- subtitles

  Future<void> _autoSubtitle() async {
    if (widget.source.startsWith('content://')) return;
    final base = p.withoutExtension(widget.source);
    for (final ext in const ['.srt', '.SRT']) {
      final f = File('$base$ext');
      if (f.existsSync()) {
        await _loadSubtitleFile(f.path);
        return;
      }
    }
  }

  Future<void> _loadSubtitleFile(String path) async {
    try {
      final bytes = await File(path).readAsBytes();
      String text;
      try {
        text = utf8.decode(bytes);
      } catch (_) {
        text = latin1.decode(bytes);
      }
      final cues = SrtParser.parse(text);
      if (!mounted) return;
      setState(() {
        _cues = cues;
        _subName = p.basename(path);
        _subsOn = true;
      });
      if (cues.isEmpty) _flashText('No subtitles found in file');
    } catch (_) {
      _flashText('Cannot read subtitle file');
    }
  }

  Future<void> _pickSubtitle() async {
    try {
      final r = await FilePicker.platform.pickFiles(type: FileType.any);
      final path = r?.files.single.path;
      if (path == null) return;
      if (!path.toLowerCase().endsWith('.srt')) {
        _flashText('Choose an .srt subtitle file');
        return;
      }
      await _loadSubtitleFile(path);
    } catch (_) {
      _flashText('Cannot open file picker');
    }
  }

  void _onTick() {
    if (!mounted) return;
    if (_cues.isEmpty || !_subsOn) {
      if (_subText != null) setState(() => _subText = null);
      return;
    }
    final cue = SrtParser.at(_cues, _c.value.position,
        offset: Duration(milliseconds: _subDelayMs));
    final t = cue?.text;
    if (t != _subText) setState(() => _subText = t);
  }

  // ------------------------------------------------------------ lifecycle

  @override
  void didChangeMetrics() {
    if (!mounted || _fullscreen) return;
    final size = WidgetsBinding.instance.platformDispatcher.views.first.physicalSize;
    SystemChrome.setEnabledSystemUIMode(
      size.width > size.height ? SystemUiMode.immersiveSticky : SystemUiMode.edgeToEdge,
    );
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.paused) {
      _saveResume();
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _hideTimer?.cancel();
    _flashTimer?.cancel();
    _sideTimer?.cancel();
    _saveTimer?.cancel();
    _saveResume();
    _c.removeListener(_onTick);
    _c.dispose();
    Native.keepScreenOn(false);
    Native.setBrightness(-1);
    SystemChrome.setPreferredOrientations(const <DeviceOrientation>[]);
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    super.dispose();
  }

  // -------------------------------------------------------------- helpers

  Duration get _duration => _c.value.duration;

  Duration _clamp(Duration d) {
    if (d < Duration.zero) return Duration.zero;
    if (d > _duration) return _duration;
    return d;
  }

  String _fmt(Duration d) {
    final h = d.inHours;
    final m = d.inMinutes.remainder(60).toString().padLeft(2, '0');
    final s = d.inSeconds.remainder(60).toString().padLeft(2, '0');
    return h > 0 ? '$h:$m:$s' : '${d.inMinutes}:$s';
  }

  void _requestSeek(Duration target) {
    _pendingSeek = _clamp(target);
    if (!_seeking) _drainSeeks();
  }

  Future<void> _drainSeeks() async {
    _seeking = true;
    try {
      while (_pendingSeek != null) {
        final t = _pendingSeek!;
        _pendingSeek = null;
        await _c.seekTo(t);
      }
    } catch (_) {
    } finally {
      _seeking = false;
    }
  }

  void _skip(int seconds) {
    final base = _pendingSeek ?? _c.value.position;
    _requestSeek(base + Duration(seconds: seconds));
    _flashText(seconds > 0 ? '+${seconds}s' : '${seconds}s');
  }

  void _flashText(String t) {
    _flashTimer?.cancel();
    if (!mounted) return;
    setState(() => _flash = t);
    _flashTimer = Timer(const Duration(milliseconds: 800), () {
      if (mounted) setState(() => _flash = null);
    });
  }

  void _scheduleHide() {
    _hideTimer?.cancel();
    _hideTimer = Timer(const Duration(seconds: 3), () {
      if (mounted && _c.value.isPlaying && !_scrubbing && !_swiping) {
        setState(() => _showControls = false);
      }
    });
  }

  void _toggleControls() {
    setState(() => _showControls = !_showControls);
    if (_showControls) _scheduleHide();
  }

  void _setOrient(_Orient o) {
    _orient = o;
    switch (o) {
      case _Orient.auto:
        SystemChrome.setPreferredOrientations(DeviceOrientation.values);
      case _Orient.landscape:
        SystemChrome.setPreferredOrientations(const [
          DeviceOrientation.landscapeLeft,
          DeviceOrientation.landscapeRight,
        ]);
      case _Orient.portrait:
        SystemChrome.setPreferredOrientations(const [DeviceOrientation.portraitUp]);
    }
    if (mounted) setState(() {});
  }

  void _cycleOrient() {
    const order = [_Orient.auto, _Orient.landscape, _Orient.portrait];
    _setOrient(order[(order.indexOf(_orient) + 1) % order.length]);
    _flashText(switch (_orient) {
      _Orient.auto => 'Auto rotate',
      _Orient.landscape => 'Landscape',
      _Orient.portrait => 'Portrait',
    });
  }

  void _toggleFullscreen() {
    setState(() => _fullscreen = !_fullscreen);
    if (_fullscreen) {
      SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
      _setOrient(_c.value.aspectRatio >= 1 ? _Orient.landscape : _Orient.portrait);
    } else {
      SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
      _setOrient(_Orient.auto);
    }
  }

  // -------------------------------------------------------------- gestures

  Offset _doubleTapAt = Offset.zero;

  void _swipeBegin() {
    _swiping = true;
    _swipeDx = 0;
    _swipeStart = _pendingSeek ?? _c.value.position;
    _swipeTarget = _swipeStart;
  }

  void _swipeUpdate(double dx, double width) {
    _swipeDx += dx;
    final span = math.min(_duration.inMilliseconds, 120000);
    final deltaMs = (_swipeDx / width * span).round();
    _swipeTarget = _clamp(_swipeStart + Duration(milliseconds: deltaMs));
    setState(() {});
  }

  void _swipeEnd() {
    if (!_swiping) return;
    _requestSeek(_swipeTarget);
    setState(() => _swiping = false);
    _scheduleHide();
  }

  Future<void> _sideBegin(Offset pos, double width) async {
    _sideDy = 0;
    if (pos.dx < width / 2) {
      _sideKind = 'brightness';
      _sideShown = 'brightness';
      _sideStart = await Native.getBrightness();
    } else {
      _sideKind = 'volume';
      _sideShown = 'volume';
      _sideStart = await Native.getVolume();
    }
    _sideValue = _sideStart;
  }

  void _sideUpdate(double dy, double height) {
    if (_sideKind == null) return;
    _sideDy += dy;
    final v = (_sideStart - _sideDy / (height * 0.7)).clamp(0.0, 1.0).toDouble();
    _sideValue = v;
    if (_sideKind == 'brightness') {
      Native.setBrightness(math.max(0.02, v));
    } else {
      Native.setVolume(v);
    }
    _sideTimer?.cancel();
    setState(() => _sideVisible = true);
  }

  void _sideEnd() {
    _sideKind = null;
    _sideTimer?.cancel();
    _sideTimer = Timer(const Duration(milliseconds: 700), () {
      if (mounted) setState(() => _sideVisible = false);
    });
  }

  // ------------------------------------------------------------------ build

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: !_locked,
      child: Scaffold(
        backgroundColor: Colors.black,
        body: _error != null
            ? SafeArea(
                child: Stack(
                  children: [
                    Center(child: Text(_error!)),
                    Positioned(
                      top: 8,
                      left: 8,
                      child: IconButton(
                        icon: const Icon(Icons.arrow_back),
                        onPressed: () => Navigator.pop(context),
                      ),
                    ),
                  ],
                ),
              )
            : !_ready
                ? const Center(child: CircularProgressIndicator())
                : LayoutBuilder(
                    builder: (context, box) => _player(box.maxWidth, box.maxHeight),
                  ),
      ),
    );
  }

  Widget _videoView() {
    final v = _c.value;
    final fit = switch (_fit) {
      _Fit.fit => BoxFit.contain,
      _Fit.fill => BoxFit.cover,
      _Fit.stretch => BoxFit.fill,
      _Fit.zoom => BoxFit.cover,
    };
    Widget child = RotatedBox(
      quarterTurns: _turns,
      child: SizedBox(
        width: v.size.width <= 0 ? 16 : v.size.width,
        height: v.size.height <= 0 ? 9 : v.size.height,
        child: VideoPlayer(_c),
      ),
    );
    child = FittedBox(fit: fit, clipBehavior: Clip.hardEdge, child: child);
    if (_fit == _Fit.zoom) {
      child = Transform.scale(scale: 1.25, child: child);
    }
    return SizedBox.expand(child: child);
  }

  Widget _player(double width, double height) {
    return Stack(
      fit: StackFit.expand,
      children: [
        GestureDetector(
          behavior: HitTestBehavior.opaque,
          onTap: _toggleControls,
          onDoubleTapDown: _locked ? null : (d) => _doubleTapAt = d.localPosition,
          onDoubleTap: _locked
              ? null
              : () => _skip(_doubleTapAt.dx < width / 2 ? -10 : 10),
          onHorizontalDragStart: _locked ? null : (_) => _swipeBegin(),
          onHorizontalDragUpdate: _locked ? null : (d) => _swipeUpdate(d.delta.dx, width),
          onHorizontalDragEnd: _locked ? null : (_) => _swipeEnd(),
          onHorizontalDragCancel: _locked ? null : () => setState(() => _swiping = false),
          onVerticalDragStart: _locked ? null : (d) => _sideBegin(d.localPosition, width),
          onVerticalDragUpdate: _locked ? null : (d) => _sideUpdate(d.delta.dy, height),
          onVerticalDragEnd: _locked ? null : (_) => _sideEnd(),
          onVerticalDragCancel: _locked ? null : _sideEnd,
          child: _videoView(),
        ),
        if (_subsOn && _subText != null)
          Positioned(
            left: 24,
            right: 24,
            bottom: _showControls && !_locked ? 130 : 36,
            child: IgnorePointer(
              child: Center(
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(
                    color: Colors.black54,
                    borderRadius: BorderRadius.circular(6),
                  ),
                  child: Text(
                    _subText!,
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.w600,
                      color: Colors.white,
                    ),
                  ),
                ),
              ),
            ),
          ),
        if (_swiping) Center(child: _hint('${_fmt(_swipeTarget)} / ${_fmt(_duration)}')),
        if (_flash != null && !_swiping) Center(child: _hint(_flash!)),
        if (_sideVisible)
          Positioned(
            top: 0,
            bottom: 0,
            left: _sideShown == 'volume' ? null : 28,
            right: _sideShown == 'volume' ? 28 : null,
            child: Center(child: _sideIndicator()),
          ),
        if (_locked)
          Positioned(
            left: 0,
            top: 0,
            bottom: 0,
            child: SafeArea(
              child: Center(
                child: AnimatedOpacity(
                  opacity: _showControls ? 1 : 0,
                  duration: const Duration(milliseconds: 200),
                  child: IgnorePointer(
                    ignoring: !_showControls,
                    child: IconButton.filled(
                      style: IconButton.styleFrom(backgroundColor: Colors.black54),
                      iconSize: 30,
                      tooltip: 'Unlock',
                      icon: const Icon(Icons.lock),
                      onPressed: () {
                        setState(() => _locked = false);
                        _flashText('Unlocked');
                        _scheduleHide();
                      },
                    ),
                  ),
                ),
              ),
            ),
          )
        else if (_showControls) ...[
          Positioned(top: 0, left: 0, right: 0, child: _topBar()),
          Positioned(bottom: 0, left: 0, right: 0, child: _bottomBar()),
        ],
      ],
    );
  }

  Widget _sideIndicator() {
    final isVol = _sideShown == 'volume';
    return Container(
      width: 46,
      padding: const EdgeInsets.symmetric(vertical: 12),
      decoration: BoxDecoration(
        color: Colors.black54,
        borderRadius: BorderRadius.circular(22),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(isVol ? Icons.volume_up : Icons.brightness_6, size: 22, color: kGreen),
          const SizedBox(height: 8),
          SizedBox(
            height: 110,
            width: 6,
            child: ClipRRect(
              borderRadius: BorderRadius.circular(3),
              child: RotatedBox(
                quarterTurns: 3,
                child: LinearProgressIndicator(
                  value: _sideValue,
                  color: kGreen,
                  backgroundColor: Colors.white24,
                ),
              ),
            ),
          ),
          const SizedBox(height: 8),
          Text('${(_sideValue * 100).round()}', style: const TextStyle(fontSize: 12)),
        ],
      ),
    );
  }

  Widget _hint(String text) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 10),
        decoration: BoxDecoration(
          color: Colors.black54,
          borderRadius: BorderRadius.circular(14),
        ),
        child: Text(
          text,
          style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w700),
        ),
      );

  Widget _topBar() {
    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [Colors.black87, Colors.transparent],
        ),
      ),
      child: SafeArea(
        bottom: false,
        child: Row(
          children: [
            IconButton(
              icon: const Icon(Icons.arrow_back),
              onPressed: () => Navigator.pop(context),
            ),
            Expanded(
              child: Text(
                _title,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(fontSize: 16),
              ),
            ),
            IconButton(
              tooltip: 'Subtitles',
              icon: Icon(Icons.subtitles_outlined, color: _cues.isNotEmpty && _subsOn ? kGreen : null),
              onPressed: _subtitleSheet,
            ),
            PopupMenuButton<double>(
              tooltip: 'Speed',
              color: kPanel,
              icon: const Icon(Icons.speed),
              onSelected: (v) {
                _speed = v;
                _c.setPlaybackSpeed(v);
                _flashText('${v}x');
              },
              itemBuilder: (_) => [
                for (final v in const [0.5, 0.75, 1.0, 1.25, 1.5, 2.0])
                  CheckedPopupMenuItem<double>(
                    value: v,
                    checked: v == _speed,
                    child: Text('${v}x'),
                  ),
              ],
            ),
            PopupMenuButton<String>(
              color: kPanel,
              onSelected: (v) {
                switch (v) {
                  case 'info':
                    _showInfo();
                  case 'picture':
                    _pictureSheet();
                  case 'rotate':
                    _cycleOrient();
                }
              },
              itemBuilder: (_) => const [
                PopupMenuItem(value: 'picture', child: Text('Picture size / rotate')),
                PopupMenuItem(value: 'rotate', child: Text('Screen rotation')),
                PopupMenuItem(value: 'info', child: Text('Video information')),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _bottomBar() {
    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.bottomCenter,
          end: Alignment.topCenter,
          colors: [Colors.black87, Colors.transparent],
        ),
      ),
      child: SafeArea(
        top: false,
        child: ValueListenableBuilder<VideoPlayerValue>(
          valueListenable: _c,
          builder: (context, v, _) {
            final durMs = math.max(1, v.duration.inMilliseconds).toDouble();
            final posMs = (_scrubbing ? _scrubMs : v.position.inMilliseconds.toDouble())
                .clamp(0.0, durMs)
                .toDouble();
            return Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Row(
                  children: [
                    const SizedBox(width: 16),
                    Text(_fmt(Duration(milliseconds: posMs.round()))),
                    Expanded(
                      child: Slider(
                        value: posMs,
                        max: durMs,
                        activeColor: kGreen,
                        inactiveColor: kPanel,
                        onChangeStart: (x) {
                          _scrubbing = true;
                          _scrubMs = x;
                          _hideTimer?.cancel();
                        },
                        onChanged: (x) {
                          setState(() => _scrubMs = x);
                          _requestSeek(Duration(milliseconds: x.round()));
                        },
                        onChangeEnd: (x) {
                          _requestSeek(Duration(milliseconds: x.round()));
                          setState(() => _scrubbing = false);
                          _scheduleHide();
                        },
                      ),
                    ),
                    Text(_fmt(v.duration)),
                    const SizedBox(width: 16),
                  ],
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    IconButton(
                      tooltip: 'Lock',
                      icon: const Icon(Icons.lock_open),
                      onPressed: () {
                        setState(() {
                          _locked = true;
                          _showControls = true;
                        });
                        _flashText('Locked');
                        _scheduleHide();
                      },
                    ),
                    IconButton(
                      iconSize: 34,
                      icon: const Icon(Icons.replay_10),
                      onPressed: () {
                        _skip(-10);
                        _scheduleHide();
                      },
                    ),
                    IconButton.filled(
                      iconSize: 44,
                      icon: Icon(v.isPlaying ? Icons.pause : Icons.play_arrow),
                      onPressed: () async {
                        if (v.isPlaying) {
                          await _c.pause();
                        } else {
                          if (v.position >= v.duration) _requestSeek(Duration.zero);
                          await _c.play();
                          _scheduleHide();
                        }
                      },
                    ),
                    IconButton(
                      iconSize: 34,
                      icon: const Icon(Icons.forward_10),
                      onPressed: () {
                        _skip(10);
                        _scheduleHide();
                      },
                    ),
                    IconButton(
                      tooltip: 'Fullscreen',
                      icon: Icon(_fullscreen ? Icons.fullscreen_exit : Icons.fullscreen),
                      onPressed: _toggleFullscreen,
                    ),
                  ],
                ),
                const SizedBox(height: 4),
              ],
            );
          },
        ),
      ),
    );
  }

  // ----------------------------------------------------------------- sheets

  void _subtitleSheet() {
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: kPanel,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setS) => SafeArea(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              ListTile(
                title: const Text('Subtitles'),
                subtitle: Text(_subName ?? 'No subtitle file loaded'),
              ),
              SwitchListTile(
                value: _subsOn,
                activeColor: kGreen,
                title: const Text('Show subtitles'),
                onChanged: _cues.isEmpty
                    ? null
                    : (v) {
                        setState(() => _subsOn = v);
                        setS(() {});
                      },
              ),
              ListTile(
                leading: const Icon(Icons.folder_open),
                title: const Text('Load .srt file'),
                onTap: () async {
                  Navigator.pop(ctx);
                  await _pickSubtitle();
                },
              ),
              ListTile(
                leading: const Icon(Icons.sync),
                title: Text('Delay: ${(_subDelayMs / 1000).toStringAsFixed(1)} s'),
                subtitle: const Text('Positive = subtitles appear later'),
                trailing: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    IconButton(
                      icon: const Icon(Icons.remove_circle_outline),
                      onPressed: () {
                        setState(() => _subDelayMs -= 500);
                        setS(() {});
                      },
                    ),
                    IconButton(
                      icon: const Icon(Icons.add_circle_outline),
                      onPressed: () {
                        setState(() => _subDelayMs += 500);
                        setS(() {});
                      },
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _pictureSheet() {
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: kPanel,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setS) => SafeArea(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const ListTile(title: Text('Picture size')),
              for (final f in _Fit.values)
                ListTile(
                  leading: Icon(
                    _fit == f ? Icons.radio_button_checked : Icons.radio_button_unchecked,
                    color: _fit == f ? kGreen : null,
                  ),
                  title: Text(switch (f) {
                    _Fit.fit => 'Fit to screen',
                    _Fit.fill => 'Fill (crop edges)',
                    _Fit.stretch => 'Stretch',
                    _Fit.zoom => 'Zoom 125%',
                  }),
                  onTap: () {
                    setState(() => _fit = f);
                    setS(() {});
                  },
                ),
              ListTile(
                leading: const Icon(Icons.rotate_90_degrees_cw),
                title: const Text('Rotate picture 90°'),
                subtitle: Text('${_turns * 90}°'),
                onTap: () {
                  setState(() => _turns = (_turns + 1) % 4);
                  setS(() {});
                },
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _showInfo() async {
    final info = await Native.mediaInfo(widget.source);
    int? size = widget.size;
    if (size == null && !widget.source.startsWith('content://')) {
      try {
        size = File(widget.source).lengthSync();
      } catch (_) {}
    }
    final v = _c.value;
    final rows = <MapEntry<String, String>>[
      MapEntry('Name', _title),
      if (size != null) MapEntry('Size', formatSize(size)),
      MapEntry('Duration', _fmt(v.duration)),
      MapEntry('Resolution', '${v.size.width.toInt()} x ${v.size.height.toInt()}'),
      if (info['bitrate'] != null)
        MapEntry('Bitrate', '${((int.tryParse(info['bitrate'].toString()) ?? 0) / 1000).round()} kbps'),
      if (info['fps'] != null) MapEntry('Frame rate', '${info['fps']} fps'),
      if (info['mime'] != null) MapEntry('Type', info['mime'].toString()),
      if (info['rotation'] != null) MapEntry('Rotation', '${info['rotation']}°'),
      MapEntry('Path', widget.source),
    ];
    if (!mounted) return;
    await showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Video information'),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              for (final r in rows)
                Padding(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: Text.rich(TextSpan(children: [
                    TextSpan(text: '${r.key}: ', style: const TextStyle(color: kGreen)),
                    TextSpan(text: r.value),
                  ])),
                ),
            ],
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Close')),
        ],
      ),
    );
  }
}
