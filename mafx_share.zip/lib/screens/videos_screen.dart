import 'package:flutter/material.dart';

import '../widgets/media_browser.dart';

/// Opens the media browser on the Videos tab.
class VideosScreen extends StatelessWidget {
  const VideosScreen({super.key});

  @override
  Widget build(BuildContext context) => const MediaHubScreen(initialTab: 3);
}
