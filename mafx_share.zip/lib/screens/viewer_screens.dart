import 'dart:io';

import 'package:flutter/material.dart';
import 'package:path/path.dart' as p;

import '../services/file_ops.dart';
import '../services/music_service.dart';
import '../theme.dart';
import 'music/now_playing_screen.dart';
import 'video_player_screen.dart';

const _videoExt = {'.mp4', '.mkv', '.3gp', '.webm', '.mov', '.avi', '.m4v', '.ts', '.flv', '.wmv'};
const _audioExt = {'.mp3', '.m4a', '.aac', '.wav', '.ogg', '.flac', '.opus', '.amr', '.wma'};
const _imageExt = {'.jpg', '.jpeg', '.png', '.gif', '.webp', '.bmp', '.heic'};

/// Opens a file inside the app (video player, music player or image viewer).
/// [path] can be a file path or a content:// URI (files published to
/// MediaStore). Because a URI has no extension, pass the file [name].
/// Other file types (APK, PDF, ZIP...) are opened with the matching app.
Future<void> openFileViewer(BuildContext context, String path,
    {String? name, int? size}) async {
  final ext = p.extension(name ?? path).toLowerCase();
  final nav = Navigator.of(context);
  if (_videoExt.contains(ext)) {
    nav.push(MaterialPageRoute(
      builder: (_) => VideoPlayerScreen(source: path, name: name, size: size),
    ));
  } else if (_audioExt.contains(ext)) {
    await MusicService.instance.playSource(path, name ?? p.basename(path));
    nav.push(MaterialPageRoute(builder: (_) => const NowPlayingScreen()));
  } else if (_imageExt.contains(ext)) {
    nav.push(MaterialPageRoute(
      builder: (_) => ImageViewerScreen(path: path, name: name),
    ));
  } else {
    final ok = await FileOps.openExternal(path);
    if (!ok && context.mounted) {
      ScaffoldMessenger.of(context)
        ..hideCurrentSnackBar()
        ..showSnackBar(
          const SnackBar(content: Text('No app can open this file type.')),
        );
    }
  }
}

/// Kept for older code paths: video -> video player, audio -> music player.
class PlayerScreen extends StatefulWidget {
  const PlayerScreen({super.key, required this.path, this.audio = false});

  final String path;
  final bool audio;

  @override
  State<PlayerScreen> createState() => _PlayerScreenState();
}

class _PlayerScreenState extends State<PlayerScreen> {
  @override
  void initState() {
    super.initState();
    if (widget.audio) {
      MusicService.instance.playSource(widget.path, p.basename(widget.path));
    }
  }

  @override
  Widget build(BuildContext context) {
    if (widget.audio) return const NowPlayingScreen();
    return VideoPlayerScreen(source: widget.path);
  }
}

class ImageViewerScreen extends StatefulWidget {
  const ImageViewerScreen({super.key, required this.path, this.name});
  final String path;
  final String? name;

  @override
  State<ImageViewerScreen> createState() => _ImageViewerScreenState();
}

class _ImageViewerScreenState extends State<ImageViewerScreen> {
  late final Future<File?> _file =
      FileOps.toFile(widget.path, widget.name ?? 'image.jpg');

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        title: Text(
          widget.name ?? p.basename(widget.path),
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
        ),
        actions: [
          IconButton(
            tooltip: 'Share',
            icon: const Icon(Icons.share),
            onPressed: () => FileOps.share([widget.path]),
          ),
        ],
      ),
      body: FutureBuilder<File?>(
        future: _file,
        builder: (context, snap) {
          if (snap.connectionState != ConnectionState.done) {
            return const Center(child: CircularProgressIndicator(color: kGreen));
          }
          final f = snap.data;
          if (f == null) return const Center(child: Text('Cannot open this image.'));
          return InteractiveViewer(
            maxScale: 6,
            child: Center(child: Image.file(f)),
          );
        },
      ),
    );
  }
}
