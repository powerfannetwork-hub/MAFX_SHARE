import 'dart:typed_data';

/// Wire format of one chunk on a TCP stream:
///
///   [4-byte uint32 chunkIndex][4-byte uint32 dataLength][chunk bytes]
///
/// (big-endian). The byte offset of a chunk inside the file is
/// `chunkIndex * chunkSize`, so chunks may arrive in any order and on any
/// stream. A header with chunkIndex 0xFFFFFFFF and length 0 is an
/// "end of file binding" marker: the next bytes on that socket are a new
/// handshake line (see TransferService).
class ChunkCodec {
  ChunkCodec._();

  static const int headerSize = 8;
  static const int endMarkerIndex = 0xFFFFFFFF;

  static Uint8List encodeHeader(int chunkIndex, int dataLength) {
    final b = ByteData(headerSize)
      ..setUint32(0, chunkIndex, Endian.big)
      ..setUint32(4, dataLength, Endian.big);
    return b.buffer.asUint8List();
  }

  static Uint8List endMarker() => encodeHeader(endMarkerIndex, 0);

  static int chunkIndexOf(Uint8List header) =>
      ByteData.sublistView(header).getUint32(0, Endian.big);

  static int dataLengthOf(Uint8List header) =>
      ByteData.sublistView(header).getUint32(4, Endian.big);

  static int chunkCount(int fileSize, int chunkSize) =>
      fileSize <= 0 ? 0 : (fileSize + chunkSize - 1) ~/ chunkSize;

  static int offsetOf(int chunkIndex, int chunkSize) => chunkIndex * chunkSize;

  /// Length of chunk [chunkIndex] (the last chunk may be shorter).
  static int lengthOf(int chunkIndex, int fileSize, int chunkSize) {
    final rest = fileSize - chunkIndex * chunkSize;
    return rest < chunkSize ? rest : chunkSize;
  }
}

/// Chooses the chunk size of one file. Small chunks give more chunks, so all
/// streams stay busy and a stopped transfer loses less; large files still use
/// the profile's maximum (16 MiB) so there is little overhead.
class ChunkPlan {
  ChunkPlan._();

  static const int minChunk = 1 << 20; // 1 MiB
  static const int step = 256 * 1024;

  /// Aims for about 3 chunks per stream, between 1 MiB and [maxChunk].
  static int sizeFor(int fileSize, int maxChunk, int streams) {
    if (fileSize <= 0) return maxChunk;
    var c = fileSize ~/ (streams * 3);
    c = (c ~/ step) * step;
    if (c < minChunk) c = minChunk;
    if (c > maxChunk) c = maxChunk;
    return c;
  }
}
