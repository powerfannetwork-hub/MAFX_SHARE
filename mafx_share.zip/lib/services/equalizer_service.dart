import 'dart:async';
import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter/foundation.dart';
import 'package:just_audio/just_audio.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'native_bridge.dart';

/// A preset is a curve of 5 anchor points (low -> high frequency, in dB).
/// It is stretched over however many bands the phone's equalizer has.
class EqPreset {
  const EqPreset(this.name, this.curve, {this.bass = 0});
  final String name;
  final List<double> curve;

  /// Extra BassBoost effect strength (0..1).
  final double bass;
}

/// Pure maths used by the equalizer (kept free of Android code so it can be
/// unit tested).
class EqMath {
  EqMath._();

  /// Stretches / squeezes [src] to [n] points (linear interpolation).
  static List<double> resample(List<double> src, int n) {
    if (n <= 0) return const [];
    if (src.isEmpty) return List<double>.filled(n, 0);
    if (src.length == n) return List<double>.of(src);
    if (src.length == 1) return List<double>.filled(n, src.first);
    final out = <double>[];
    for (var i = 0; i < n; i++) {
      final t = n == 1 ? 0.0 : i / (n - 1);
      final pos = t * (src.length - 1);
      final lo = pos.floor();
      final hi = math.min(src.length - 1, lo + 1);
      final f = pos - lo;
      out.add(src[lo] * (1 - f) + src[hi] * f);
    }
    return out;
  }

  /// Gain of band [i] of [n] after adding the Bass / Treble controls.
  /// [bass] and [treble] are -1..1.
  static double finalGain({
    required double base,
    required int i,
    required int n,
    required double bass,
    required double treble,
    required double minDb,
    required double maxDb,
  }) {
    final t = n <= 1 ? 0.0 : i / (n - 1);
    final range = math.max(maxDb.abs(), minDb.abs());
    final wLow = math.max(0.0, 1 - t / 0.4);
    final wHigh = math.max(0.0, (t - 0.6) / 0.4);
    final g = base + bass * 0.6 * range * wLow + treble * 0.6 * range * wHigh;
    return g.clamp(minDb, maxDb).toDouble();
  }
}

class EqualizerService extends ChangeNotifier {
  EqualizerService(this.equalizer, this.loudness, this._sessionId);

  final AndroidEqualizer equalizer;
  final AndroidLoudnessEnhancer loudness;
  final int? Function() _sessionId;

  static const List<EqPreset> presets = [
    EqPreset('Flat', [0, 0, 0, 0, 0]),
    EqPreset('Bass Boost', [6, 4, 1, 0, 0], bass: 0.6),
    EqPreset('Rock', [4.5, 2.5, -1.5, 2.5, 4.5]),
    EqPreset('Pop', [-1.5, 2, 4, 1.5, -1]),
    EqPreset('Jazz', [3, 1.5, -1.5, 1.5, 3.5]),
    EqPreset('Classical', [4, 2.5, -1, 2.5, 4]),
    EqPreset('Dance', [6, 3.5, 0, 2.5, 3], bass: 0.35),
    EqPreset('Hip-Hop', [5.5, 4, 0, 1.5, 3], bass: 0.5),
    EqPreset('Vocal', [-2.5, -1, 4, 3.5, 1]),
    EqPreset('Acoustic', [4, 3, 1.5, 2, 2.5]),
    EqPreset('Remix', [5, 2, -1, 3, 5], bass: 0.3),
  ];

  bool supported = true;
  bool ready = false;
  bool enabled = false;
  double minDb = -15;
  double maxDb = 15;
  List<double> centersHz = [];
  List<double> base = []; // dB per band chosen by preset / sliders
  String preset = 'Flat'; // preset name or 'Custom'
  double bass = 0; // -1..1
  double treble = 0; // -1..1
  double loudnessGain = 0; // dB, 0..12
  bool bassBoostOk = true;
  Map<String, List<double>> custom = {};

  AndroidEqualizerParameters? _params;
  Map<String, dynamic>? _snapshot;

  List<String> get allPresetNames =>
      [for (final p in presets) p.name, ...custom.keys];

  // ------------------------------------------------------------ storage

  Future<void> loadSaved() async {
    final sp = await SharedPreferences.getInstance();
    enabled = sp.getBool('eq_enabled') ?? false;
    preset = sp.getString('eq_preset') ?? 'Flat';
    bass = sp.getDouble('eq_bass') ?? 0;
    treble = sp.getDouble('eq_treble') ?? 0;
    loudnessGain = sp.getDouble('eq_loud') ?? 0;
    final b = sp.getString('eq_base');
    if (b != null) {
      try {
        base = [for (final v in jsonDecode(b) as List) (v as num).toDouble()];
      } catch (_) {}
    }
    final c = sp.getString('eq_custom');
    if (c != null) {
      try {
        final m = jsonDecode(c) as Map<String, dynamic>;
        custom = {
          for (final e in m.entries)
            e.key: [for (final v in e.value as List) (v as num).toDouble()],
        };
      } catch (_) {}
    }
    notifyListeners();
  }

  Future<void> _save() async {
    final sp = await SharedPreferences.getInstance();
    await sp.setBool('eq_enabled', enabled);
    await sp.setString('eq_preset', preset);
    await sp.setDouble('eq_bass', bass);
    await sp.setDouble('eq_treble', treble);
    await sp.setDouble('eq_loud', loudnessGain);
    await sp.setString('eq_base', jsonEncode(base));
    await sp.setString('eq_custom', jsonEncode(custom));
  }

  // -------------------------------------------------------------- setup

  /// Reads the real equalizer of the phone. Needs a loaded audio source.
  Future<bool> ensureReady() async {
    if (ready) return true;
    try {
      final params = await equalizer.parameters.timeout(const Duration(seconds: 4));
      _params = params;
      minDb = params.minDecibels;
      maxDb = params.maxDecibels;
      centersHz = [for (final b in params.bands) b.centerFrequency];
      final n = centersHz.length;
      if (base.length != n) {
        final p = presets.where((e) => e.name == preset);
        base = EqMath.resample(
            p.isNotEmpty ? p.first.curve : (custom[preset] ?? const [0, 0, 0, 0, 0]), n);
      }
      ready = true;
      supported = true;
      await _apply();
      notifyListeners();
      return true;
    } catch (_) {
      supported = false;
      notifyListeners();
      return false;
    }
  }

  Future<void> _apply() async {
    final params = _params;
    if (params == null) return;
    try {
      await equalizer.setEnabled(enabled);
      final n = params.bands.length;
      for (var i = 0; i < n; i++) {
        final g = EqMath.finalGain(
          base: i < base.length ? base[i] : 0,
          i: i,
          n: n,
          bass: bass,
          treble: treble,
          minDb: minDb,
          maxDb: maxDb,
        );
        await params.bands[i].setGain(g);
      }
    } catch (_) {
      supported = false;
    }
    try {
      await loudness.setEnabled(enabled && loudnessGain > 0);
      await loudness.setTargetGain(loudnessGain);
    } catch (_) {}
    final session = _sessionId();
    if (session != null && session != 0) {
      final p = presets.where((e) => e.name == preset);
      final presetBass = p.isNotEmpty ? p.first.bass : 0.0;
      final strength = enabled
          ? ((math.max(0.0, bass) + presetBass).clamp(0.0, 1.0) * 1000).round()
          : 0;
      bassBoostOk = await Native.setBassBoost(session, strength) || strength == 0;
    }
  }

  // ------------------------------------------------------------ actions

  Future<void> setEnabled(bool v) async {
    enabled = v;
    notifyListeners();
    await _apply();
    await _save();
  }

  Future<void> applyPreset(String name) async {
    if (!await ensureReady()) return;
    final n = centersHz.length;
    final p = presets.where((e) => e.name == name);
    if (p.isNotEmpty) {
      base = EqMath.resample(p.first.curve, n);
    } else if (custom.containsKey(name)) {
      base = EqMath.resample(custom[name]!, n);
    } else {
      return;
    }
    preset = name;
    bass = 0;
    treble = 0;
    enabled = true;
    notifyListeners();
    await _apply();
    await _save();
  }

  Future<void> setBand(int i, double db) async {
    if (!await ensureReady() || i >= base.length) return;
    base[i] = db.clamp(minDb, maxDb).toDouble();
    preset = 'Custom';
    enabled = true;
    notifyListeners();
    await _apply();
  }

  Future<void> setBass(double v) async {
    if (!await ensureReady()) return;
    bass = v.clamp(-1.0, 1.0).toDouble();
    enabled = true;
    notifyListeners();
    await _apply();
  }

  Future<void> setTreble(double v) async {
    if (!await ensureReady()) return;
    treble = v.clamp(-1.0, 1.0).toDouble();
    enabled = true;
    notifyListeners();
    await _apply();
  }

  Future<void> setLoudness(double db) async {
    loudnessGain = db.clamp(0.0, 12.0).toDouble();
    notifyListeners();
    await _apply();
  }

  /// Called when a slider is released.
  Future<void> commit() => _save();

  Future<void> reset() async {
    if (!await ensureReady()) return;
    base = List<double>.filled(centersHz.length, 0);
    preset = 'Flat';
    bass = 0;
    treble = 0;
    loudnessGain = 0;
    notifyListeners();
    await _apply();
    await _save();
  }

  Future<void> saveCustomPreset(String name) async {
    final n = name.trim();
    if (n.isEmpty || presets.any((p) => p.name.toLowerCase() == n.toLowerCase())) {
      return;
    }
    // Store what is really heard (base + bass + treble).
    final count = base.length;
    custom[n] = [
      for (var i = 0; i < count; i++)
        EqMath.finalGain(
          base: base[i],
          i: i,
          n: count,
          bass: bass,
          treble: treble,
          minDb: minDb,
          maxDb: maxDb,
        ),
    ];
    preset = n;
    bass = 0;
    treble = 0;
    base = List<double>.of(custom[n]!);
    notifyListeners();
    await _apply();
    await _save();
  }

  Future<void> deleteCustomPreset(String name) async {
    custom.remove(name);
    if (preset == name) preset = 'Custom';
    notifyListeners();
    await _save();
  }

  /// Remember the settings as they are now (taken when the screen opens).
  void takeSnapshot() {
    _snapshot = {
      'enabled': enabled,
      'preset': preset,
      'bass': bass,
      'treble': treble,
      'loud': loudnessGain,
      'base': List<double>.of(base),
    };
  }

  bool get hasSnapshot => _snapshot != null;

  /// Go back to the settings that were active when the screen was opened.
  Future<void> restoreSnapshot() async {
    final s = _snapshot;
    if (s == null) return;
    enabled = s['enabled'] as bool;
    preset = s['preset'] as String;
    bass = s['bass'] as double;
    treble = s['treble'] as double;
    loudnessGain = s['loud'] as double;
    base = List<double>.of(s['base'] as List<double>);
    notifyListeners();
    await _apply();
    await _save();
  }
}
