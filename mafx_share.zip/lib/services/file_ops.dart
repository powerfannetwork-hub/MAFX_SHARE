import 'dart:io';

import 'package:flutter/material.dart';
import 'package:path/path.dart' as p;
import 'package:photo_manager/photo_manager.dart';

import 'native_bridge.dart';

/// File actions that work for BOTH normal file paths and content:// URIs
/// (files published to MediaStore). History, Files, Media browser and the
/// viewers all go through here.
class FileOps {
  FileOps._();

  static bool isUri(String s) => s.startsWith('content://');

  static Future<bool> exists(String path) async {
    if (path.isEmpty) return false;
    if (isUri(path)) return Native.exists(path);
    return File(path).existsSync();
  }

  /// A real file for [source]; content:// URIs are copied to the cache.
  static Future<File?> toFile(String source, String name) async {
    if (!isUri(source)) {
      final f = File(source);
      return f.existsSync() ? f : null;
    }
    final copied = await Native.copyToCache(source, name);
    return copied == null ? null : File(copied);
  }

  static Future<bool> share(List<String> sources) => Native.share(sources);

  static Future<bool> openExternal(String source) => Native.openExternal(source);

  /// Deletes files / URIs. Returns the number of deleted items.
  static Future<int> delete(List<String> sources) async {
    if (sources.isEmpty) return 0;
    final deleted = (await Native.deleteSources(sources)).toSet();
    final left = sources.where((s) => !deleted.contains(s)).toList();
    // Media owned by other apps: let photo_manager ask the user (Android 11+).
    final ids = <String>[];
    for (final s in left) {
      if (isUri(s) && !s.contains('/downloads/')) {
        final id = p.basename(Uri.parse(s).path);
        if (int.tryParse(id) != null) ids.add(id);
      }
    }
    if (ids.isNotEmpty) {
      try {
        final r = await PhotoManager.editor.deleteWithIds(ids);
        for (final id in r) {
          for (final s in left) {
            if (isUri(s) && p.basename(Uri.parse(s).path) == id) deleted.add(s);
          }
        }
      } catch (_) {}
    }
    return deleted.length;
  }

  static Future<bool> confirmDelete(BuildContext context, int count) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Delete files?'),
        content: Text(count == 1
            ? 'Delete this file from the phone?'
            : 'Delete $count files from the phone?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Delete'),
          ),
        ],
      ),
    );
    return ok == true;
  }
}
