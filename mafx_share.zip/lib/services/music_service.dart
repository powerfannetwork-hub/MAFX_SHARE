import 'dart:async';
import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:just_audio/just_audio.dart';
import 'package:just_audio_background/just_audio_background.dart';
import 'package:path/path.dart' as p;
import 'package:permission_handler/permission_handler.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../media/media_entry.dart';
import 'equalizer_service.dart';
import 'native_bridge.dart';

/// The one music player of the app. Uses just_audio + just_audio_background,
/// so music keeps playing when the app is closed to the background, with a
/// notification and lock-screen controls (play/pause, next, previous, seek).
class MusicService extends ChangeNotifier {
  MusicService._() {
    _eqPlugin = AndroidEqualizer();
    _loudPlugin = AndroidLoudnessEnhancer();
    player = AudioPlayer(
      audioPipeline: AudioPipeline(androidAudioEffects: [_loudPlugin, _eqPlugin]),
    );
    eq = EqualizerService(_eqPlugin, _loudPlugin, () => player.androidAudioSessionId);
  }
  static final MusicService instance = MusicService._();

  late final AndroidEqualizer _eqPlugin;
  late final AndroidLoudnessEnhancer _loudPlugin;
  late final AudioPlayer player;
  late final EqualizerService eq;

  List<MediaEntry> library = [];
  bool libraryLoading = false;
  String? libraryError;

  List<MediaEntry> _queue = [];
  List<MediaEntry> get queue => _queue;

  /// name -> list of song URIs / paths (insertion ordered)
  final Map<String, List<String>> playlists = {};

  String? lastError;
  bool _inited = false;
  bool _eqAttached = false;
  double speed = 1.0;

  // ------------------------------------------------------------------ init

  Future<void> init() async {
    if (_inited) return;
    _inited = true;
    final sp = await SharedPreferences.getInstance();
    final pl = sp.getString('playlists');
    if (pl != null) {
      try {
        final m = jsonDecode(pl) as Map<String, dynamic>;
        for (final e in m.entries) {
          playlists[e.key] = [for (final v in e.value as List) v.toString()];
        }
      } catch (_) {}
    }
    speed = sp.getDouble('music_speed') ?? 1.0;
    try {
      await eq.loadSaved();
    } catch (_) {}

    player.currentIndexStream.listen((_) => notifyListeners());
    player.playerStateStream.listen((s) {
      if (s.processingState == ProcessingState.ready && !_eqAttached) {
        _eqAttached = true;
        // The audio session exists now: connect the real equalizer.
        unawaited(eq.ensureReady());
      }
      notifyListeners();
    });
    player.shuffleModeEnabledStream.listen((_) => notifyListeners());
    player.loopModeStream.listen((_) => notifyListeners());
    player.playbackEventStream.listen((_) {}, onError: (Object e, StackTrace st) {
      lastError = 'Cannot play this song.';
      notifyListeners();
    });
    try {
      final shuffle = sp.getBool('music_shuffle') ?? false;
      final loop = sp.getInt('music_loop') ?? 0;
      await player.setShuffleModeEnabled(shuffle);
      await player.setLoopMode(LoopMode.values[loop.clamp(0, 2).toInt()]);
    } catch (_) {}
  }

  // --------------------------------------------------------------- library

  Future<void> loadLibrary({bool force = false}) async {
    if (libraryLoading) return;
    if (library.isNotEmpty && !force) return;
    libraryLoading = true;
    libraryError = null;
    notifyListeners();
    try {
      final raw = await Native.queryMedia('audio');
      library = [for (final m in raw) MediaEntry.fromMap('audio', m)];
    } catch (e) {
      libraryError = 'Could not load music: $e';
    }
    libraryLoading = false;
    notifyListeners();
  }

  // -------------------------------------------------------------- playback

  MediaEntry? get current {
    final i = player.currentIndex;
    if (i == null || i < 0 || i >= _queue.length) return null;
    return _queue[i];
  }

  bool get hasQueue => _queue.isNotEmpty;
  bool get playing => player.playing;
  bool get shuffle => player.shuffleModeEnabled;
  LoopMode get loopMode => player.loopMode;

  Uri _uriOf(MediaEntry e) {
    final s = e.source;
    if (s.startsWith('content://')) return Uri.parse(s);
    return Uri.file(s);
  }

  AudioSource _sourceOf(MediaEntry e) {
    Uri? art;
    if (e.albumId != null && e.albumId! > 0) {
      art = Uri.parse('content://media/external/audio/albumart/${e.albumId}');
    }
    return AudioSource.uri(
      _uriOf(e),
      tag: MediaItem(
        id: e.key,
        title: e.displayName,
        artist: e.artist,
        album: e.album,
        duration: e.durationMs > 0 ? Duration(milliseconds: e.durationMs) : null,
        artUri: art,
      ),
    );
  }

  Future<void> playQueue(List<MediaEntry> list, int index) async {
    if (list.isEmpty) return;
    lastError = null;
    try {
      // Android 13+: the playback notification needs this permission.
      unawaited(Permission.notification.request());
    } catch (_) {}
    _queue = List<MediaEntry>.of(list);
    final start = index.clamp(0, _queue.length - 1).toInt();
    try {
      await player.setAudioSource(
        ConcatenatingAudioSource(
          children: [for (final e in _queue) _sourceOf(e)],
        ),
        initialIndex: start,
        initialPosition: Duration.zero,
      );
      await player.setSpeed(speed);
      unawaited(player.play());
    } catch (e) {
      lastError = 'Cannot play this song.';
    }
    notifyListeners();
  }

  /// Plays one file (from History / Files / another app's path).
  Future<void> playSource(String source, String name) async {
    final e = MediaEntry(
      id: source,
      kind: EntryKind.audio,
      uri: source.startsWith('content://') ? source : '',
      path: source.startsWith('content://') ? '' : source,
      name: name.isEmpty ? p.basename(source) : name,
      size: 0,
      dateMs: 0,
    );
    await playQueue([e], 0);
  }

  Future<void> togglePlay() async {
    if (player.playing) {
      await player.pause();
    } else {
      await player.play();
    }
  }

  Future<void> pause() async {
    try {
      await player.pause();
    } catch (_) {}
  }

  Future<void> next() async {
    if (player.hasNext) {
      await player.seekToNext();
    } else if (player.loopMode == LoopMode.all && _queue.isNotEmpty) {
      await player.seek(Duration.zero, index: 0);
    }
  }

  Future<void> previous() async {
    // After 3 seconds "previous" restarts the song, like most players.
    if (player.position > const Duration(seconds: 3) || !player.hasPrevious) {
      await player.seek(Duration.zero);
    } else {
      await player.seekToPrevious();
    }
  }

  Future<void> playIndex(int i) async {
    if (i < 0 || i >= _queue.length) return;
    await player.seek(Duration.zero, index: i);
    await player.play();
  }

  Future<void> seek(Duration d) => player.seek(d);

  Future<void> toggleShuffle() async {
    final on = !player.shuffleModeEnabled;
    if (on) await player.shuffle();
    await player.setShuffleModeEnabled(on);
    final sp = await SharedPreferences.getInstance();
    await sp.setBool('music_shuffle', on);
  }

  /// off -> repeat all -> repeat one -> off
  Future<void> cycleRepeat() async {
    final next = switch (player.loopMode) {
      LoopMode.off => LoopMode.all,
      LoopMode.all => LoopMode.one,
      LoopMode.one => LoopMode.off,
    };
    await player.setLoopMode(next);
    final sp = await SharedPreferences.getInstance();
    await sp.setInt('music_loop', next.index);
  }

  Future<void> setSpeed(double v) async {
    speed = v;
    try {
      await player.setSpeed(v);
    } catch (_) {}
    final sp = await SharedPreferences.getInstance();
    await sp.setDouble('music_speed', v);
    notifyListeners();
  }

  Future<void> stop() async {
    await player.stop();
    notifyListeners();
  }

  // ------------------------------------------------------------- playlists

  Future<void> _savePlaylists() async {
    final sp = await SharedPreferences.getInstance();
    await sp.setString('playlists', jsonEncode(playlists));
  }

  Future<bool> createPlaylist(String name) async {
    final n = name.trim();
    if (n.isEmpty || playlists.containsKey(n)) return false;
    playlists[n] = [];
    await _savePlaylists();
    notifyListeners();
    return true;
  }

  Future<void> renamePlaylist(String old, String name) async {
    final n = name.trim();
    if (n.isEmpty || n == old || playlists.containsKey(n) || !playlists.containsKey(old)) {
      return;
    }
    final items = playlists.remove(old)!;
    playlists[n] = items;
    await _savePlaylists();
    notifyListeners();
  }

  Future<void> deletePlaylist(String name) async {
    playlists.remove(name);
    await _savePlaylists();
    notifyListeners();
  }

  Future<void> addToPlaylist(String name, List<MediaEntry> songs) async {
    final list = playlists[name];
    if (list == null) return;
    for (final s in songs) {
      if (!list.contains(s.source)) list.add(s.source);
    }
    await _savePlaylists();
    notifyListeners();
  }

  Future<void> removeFromPlaylist(String name, String source) async {
    playlists[name]?.remove(source);
    await _savePlaylists();
    notifyListeners();
  }

  Future<void> moveInPlaylist(String name, int from, int to) async {
    final list = playlists[name];
    if (list == null || from < 0 || from >= list.length) return;
    var t = to;
    if (t > from) t -= 1;
    final item = list.removeAt(from);
    list.insert(t.clamp(0, list.length).toInt(), item);
    await _savePlaylists();
    notifyListeners();
  }

  /// Songs of a playlist (songs that no longer exist are left out).
  List<MediaEntry> playlistSongs(String name) {
    final out = <MediaEntry>[];
    for (final src in playlists[name] ?? const <String>[]) {
      for (final e in library) {
        if (e.source == src) {
          out.add(e);
          break;
        }
      }
    }
    return out;
  }

  Future<void> playPlaylist(String name, {bool shuffleOn = false}) async {
    final songs = playlistSongs(name);
    if (songs.isEmpty) return;
    await playQueue(songs, 0);
    if (shuffleOn && !player.shuffleModeEnabled) await toggleShuffle();
  }
}
