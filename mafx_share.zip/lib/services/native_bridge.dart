import 'dart:typed_data';

import 'package:flutter/services.dart';

/// Result of publishing / saving a file into a public Android folder.
class PublishResult {
  const PublishResult(
      {required this.uri, required this.path, required this.dir, this.name = ''});
  final String name;
  final String uri;
  final String path;
  final String dir;

  /// What history should store: the content:// URI (or the file path on
  /// Android 9 and older).
  String get location => uri;
}

/// Thin wrapper around the native channel "com.mafx.share/media"
/// (see android_overrides/MediaTools.kt).
class Native {
  Native._();

  static const MethodChannel _ch = MethodChannel('com.mafx.share/media');

  static int? _sdk;

  static Future<int> sdkInt() async {
    if (_sdk != null) return _sdk!;
    try {
      _sdk = await _ch.invokeMethod<int>('sdkInt') ?? 0;
    } catch (_) {
      _sdk = 0;
    }
    return _sdk!;
  }

  static Future<Map<String, dynamic>> deviceProfile() async {
    try {
      final m = await _ch.invokeMapMethod<String, dynamic>('deviceProfile');
      return m ?? <String, dynamic>{};
    } catch (_) {
      return <String, dynamic>{};
    }
  }

  static Future<List<Map<String, dynamic>>> queryMedia(String kind) async {
    final raw = await _ch.invokeListMethod<dynamic>('queryMedia', {'kind': kind});
    return [
      for (final e in raw ?? <dynamic>[])
        if (e is Map) Map<String, dynamic>.from(e),
    ];
  }

  static Future<Uint8List?> thumbnail(String source, String kind,
      {int size = 256, int albumId = -1}) async {
    try {
      return await _ch.invokeMethod<Uint8List>('thumbnail', {
        'source': source,
        'kind': kind,
        'size': size,
        'albumId': albumId,
      });
    } catch (_) {
      return null;
    }
  }

  /// Copies [path] into <Pictures|Movies|Music|Download>/MAFX SHARE.
  /// [dir] = null picks the folder from the file type.
  static Future<PublishResult?> publishFile(String path, String name,
      {String? dir}) async {
    try {
      final m = await _ch.invokeMapMethod<String, dynamic>(
          'publishFile', {'path': path, 'name': name, 'dir': dir});
      if (m == null) return null;
      return PublishResult(
        uri: (m['uri'] ?? '').toString(),
        path: (m['path'] ?? '').toString(),
        dir: (m['dir'] ?? '').toString(),
        name: (m['name'] ?? '').toString(),
      );
    } catch (_) {
      return null;
    }
  }

  static Future<PublishResult> saveImage(Uint8List bytes, String name,
      {String format = 'png'}) async {
    final m = await _ch.invokeMapMethod<String, dynamic>(
        'saveImage', {'bytes': bytes, 'name': name, 'format': format});
    return PublishResult(
      uri: (m?['uri'] ?? '').toString(),
      path: (m?['path'] ?? '').toString(),
      dir: (m?['dir'] ?? '').toString(),
      name: (m?['name'] ?? '').toString(),
    );
  }

  /// Returns the sources that were really deleted.
  static Future<List<String>> deleteSources(List<String> sources) async {
    try {
      final m = await _ch.invokeMapMethod<String, dynamic>(
          'deleteSources', {'sources': sources});
      return [for (final e in (m?['deleted'] as List? ?? const [])) e.toString()];
    } catch (_) {
      return [];
    }
  }

  static Future<bool> exists(String source) async {
    try {
      return await _ch.invokeMethod<bool>('exists', {'source': source}) ?? false;
    } catch (_) {
      return false;
    }
  }

  static Future<String?> copyToCache(String source, String name) async {
    try {
      return await _ch
          .invokeMethod<String>('copyToCache', {'source': source, 'name': name});
    } catch (_) {
      return null;
    }
  }

  static Future<bool> share(List<String> sources) async {
    try {
      return await _ch.invokeMethod<bool>('share', {'sources': sources}) ?? false;
    } catch (_) {
      return false;
    }
  }

  static Future<bool> openExternal(String source, {String? mime}) async {
    try {
      return await _ch.invokeMethod<bool>(
              'openExternal', {'source': source, 'mime': mime}) ??
          false;
    } catch (_) {
      return false;
    }
  }

  static Future<Map<String, dynamic>> mediaInfo(String source) async {
    try {
      final m = await _ch.invokeMapMethod<String, dynamic>(
          'mediaInfo', {'source': source});
      return m ?? <String, dynamic>{};
    } catch (_) {
      return <String, dynamic>{};
    }
  }

  static Future<PublishResult> cutVideo(
      String source, int startMs, int endMs, String name) async {
    final m = await _ch.invokeMapMethod<String, dynamic>('cutVideo',
        {'source': source, 'startMs': startMs, 'endMs': endMs, 'name': name});
    return PublishResult(
      uri: (m?['uri'] ?? '').toString(),
      path: (m?['path'] ?? '').toString(),
      dir: (m?['dir'] ?? '').toString(),
      name: (m?['name'] ?? '').toString(),
    );
  }

  static Future<PublishResult> cutAudio(
      String source, int startMs, int endMs, String name) async {
    final m = await _ch.invokeMapMethod<String, dynamic>('cutAudio',
        {'source': source, 'startMs': startMs, 'endMs': endMs, 'name': name});
    return PublishResult(
      uri: (m?['uri'] ?? '').toString(),
      path: (m?['path'] ?? '').toString(),
      dir: (m?['dir'] ?? '').toString(),
      name: (m?['name'] ?? '').toString(),
    );
  }

  static Future<PublishResult> extractAudio(String source, String name) async {
    final m = await _ch
        .invokeMapMethod<String, dynamic>('extractAudio', {'source': source, 'name': name});
    return PublishResult(
      uri: (m?['uri'] ?? '').toString(),
      path: (m?['path'] ?? '').toString(),
      dir: (m?['dir'] ?? '').toString(),
      name: (m?['name'] ?? '').toString(),
    );
  }

  /// Real Android BassBoost effect (0..1000). false = not supported.
  static Future<bool> setBassBoost(int session, int strength) async {
    try {
      return await _ch.invokeMethod<bool>(
              'setBassBoost', {'session': session, 'strength': strength}) ??
          false;
    } catch (_) {
      return false;
    }
  }

  static Future<bool> isIgnoringBattery() async {
    try {
      return await _ch.invokeMethod<bool>('isIgnoringBattery') ?? false;
    } catch (_) {
      return false;
    }
  }

  static Future<bool> openBatterySettings() async {
    try {
      return await _ch.invokeMethod<bool>('openBatterySettings') ?? false;
    } catch (_) {
      return false;
    }
  }

  static Future<double> getBrightness() async {
    try {
      return await _ch.invokeMethod<double>('getBrightness') ?? 0.5;
    } catch (_) {
      return 0.5;
    }
  }

  /// value < 0 gives the brightness control back to the system.
  static Future<void> setBrightness(double value) async {
    try {
      await _ch.invokeMethod<bool>('setBrightness', {'value': value});
    } catch (_) {}
  }

  static Future<double> getVolume() async {
    try {
      return await _ch.invokeMethod<double>('getVolume') ?? 0.5;
    } catch (_) {
      return 0.5;
    }
  }

  static Future<void> setVolume(double value) async {
    try {
      await _ch.invokeMethod<bool>('setVolume', {'value': value});
    } catch (_) {}
  }

  static Future<void> keepScreenOn(bool on) async {
    try {
      await _ch.invokeMethod<bool>('keepScreenOn', {'on': on});
    } catch (_) {}
  }
}
