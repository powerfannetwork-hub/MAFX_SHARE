/// One subtitle line.
class SubtitleCue {
  const SubtitleCue(this.start, this.end, this.text);
  final Duration start;
  final Duration end;
  final String text;
}

/// SubRip (.srt) parser + lookup.
class SrtParser {
  SrtParser._();

  static final RegExp _time = RegExp(
    r'(\d{1,2}):(\d{2}):(\d{2})[,.](\d{1,3})\s*-->\s*(\d{1,2}):(\d{2}):(\d{2})[,.](\d{1,3})',
  );

  static Duration _dur(String h, String m, String s, String ms) {
    final msv = int.parse(ms.padRight(3, '0').substring(0, 3));
    return Duration(
      hours: int.parse(h),
      minutes: int.parse(m),
      seconds: int.parse(s),
      milliseconds: msv,
    );
  }

  static List<SubtitleCue> parse(String content) {
    var text = content.replaceAll('\uFEFF', '').replaceAll('\r\n', '\n').replaceAll('\r', '\n');
    final cues = <SubtitleCue>[];
    final blocks = text.split(RegExp(r'\n\s*\n'));
    for (final block in blocks) {
      final lines = block.split('\n').where((l) => l.trim().isNotEmpty).toList();
      if (lines.isEmpty) continue;
      var ti = -1;
      for (var i = 0; i < lines.length && i < 3; i++) {
        if (_time.hasMatch(lines[i])) {
          ti = i;
          break;
        }
      }
      if (ti < 0) continue;
      final m = _time.firstMatch(lines[ti])!;
      final start = _dur(m.group(1)!, m.group(2)!, m.group(3)!, m.group(4)!);
      final end = _dur(m.group(5)!, m.group(6)!, m.group(7)!, m.group(8)!);
      final body = lines
          .skip(ti + 1)
          .join('\n')
          .replaceAll(RegExp(r'<[^>]+>'), '')
          .replaceAll(RegExp(r'\{\\[^}]*\}'), '')
          .trim();
      if (body.isEmpty) continue;
      cues.add(SubtitleCue(start, end, body));
    }
    cues.sort((a, b) => a.start.compareTo(b.start));
    return cues;
  }

  /// The cue shown at [position] (after applying [offset]: a positive offset
  /// makes the subtitles appear LATER).
  static SubtitleCue? at(List<SubtitleCue> cues, Duration position,
      {Duration offset = Duration.zero}) {
    if (cues.isEmpty) return null;
    final t = position - offset;
    var lo = 0;
    var hi = cues.length - 1;
    var found = -1;
    while (lo <= hi) {
      final mid = (lo + hi) >> 1;
      if (cues[mid].start <= t) {
        found = mid;
        lo = mid + 1;
      } else {
        hi = mid - 1;
      }
    }
    // Overlapping cues: look a few back for one that is still active.
    for (var i = found; i >= 0 && i > found - 4; i--) {
      if (t >= cues[i].start && t <= cues[i].end) return cues[i];
    }
    return null;
  }
}
