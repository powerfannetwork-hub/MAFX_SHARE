import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;
import 'dart:typed_data';

import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:path/path.dart' as p;
import 'package:uuid/uuid.dart';

import '../models.dart';
import '../theme.dart';
import 'chunk_codec.dart';
import 'history_service.dart';
import 'partial_store.dart';
import 'storage_service.dart';

/// A file that is being received. Chunks can arrive in any order, on any
/// stream; [chunkDone] remembers which ones are already on disk.
class _Incoming {
  _Incoming(this.key, this.name, this.size, this.finalPath, this.partPath,
      this.raf, this.chunkSize)
      : chunkCount = ChunkCodec.chunkCount(size, chunkSize),
        chunkDone = Uint8List(ChunkCodec.chunkCount(size, chunkSize));
  final String key; // same file again (name|size|date) => can be continued
  final String name;
  final int size;
  final String finalPath;
  final String partPath; // "<name>.mafxpart" until the file is complete
  final RandomAccessFile raf;
  final int chunkSize;
  final int chunkCount;
  final Uint8List chunkDone;
  int chunksDone = 0;
  bool done = false;
  bool loggedPartial = false;
}

class _Meter {
  final Stopwatch _sw = Stopwatch()..start();
  int _lastBytes = 0;
  int _lastMs = 0;
  double speed = 0;

  void update(int bytes) {
    final ms = _sw.elapsedMilliseconds;
    if (ms - _lastMs >= 400) {
      final inst = (bytes - _lastBytes) * 1000 / (ms - _lastMs);
      speed = speed == 0 ? inst : speed * 0.6 + inst * 0.4;
      _lastBytes = bytes;
      _lastMs = ms;
    }
  }
}

class _Job {
  const _Job(this.file, this.chunk);
  final int file;
  final int chunk;
}

/// Lets the UI (or sendFileTurbo's caller) stop a running transfer.
class _QueuedSend {
  _QueuedSend(this.files, this.cancel);
  final List<PendingFile> files;
  final TransferCancel? cancel;
  final Completer<void> done = Completer<void>();
}

class TransferCancel {
  bool cancelled = false;
  void cancel() => cancelled = true;
}

/// Pairing, the HTTP control server and the TCP chunk streams.
///
/// BOTH phones run the same two servers (HTTP for pairing / metadata / ack and
/// TCP for chunk data), and after pairing both know the other phone's
/// endpoints. So either phone can send and receive at any time, without a new
/// QR scan, until the session is ended.
///
/// Host  = the phone that shows the QR code (it also creates the hotspot).
/// Guest = the phone that scans it.
class TransferService {
  TransferService._() {
    pairedPeer.addListener(_onPeerChanged);
    progress.addListener(_onProgressForNotification);
  }
  static final TransferService instance = TransferService._();

  static const Map<String, String> _jsonHeaders = {
    'Content-Type': 'application/json',
  };

  final ValueNotifier<TransferMode> mode =
      ValueNotifier<TransferMode>(TransferMode.recommended);
  final ValueNotifier<PairedPeer?> pairedPeer = ValueNotifier<PairedPeer?>(null);
  final ValueNotifier<TransferProgress?> progress =
      ValueNotifier<TransferProgress?>(null);

  /// Progress of what THIS phone is sending / receiving (shown in two tabs).
  final ValueNotifier<TransferProgress?> sendProgress =
      ValueNotifier<TransferProgress?>(null);
  final ValueNotifier<TransferProgress?> receiveProgress =
      ValueNotifier<TransferProgress?>(null);

  /// How many send requests are waiting behind the one that is running.
  final ValueNotifier<int> queued = ValueNotifier<int>(0);

  /// How many TCP streams the sender uses right now.
  final ValueNotifier<int> activeStreams = ValueNotifier<int>(0);

  /// Live proof of the split: "Chunks 31/160 • per stream: 3 3 2 3 ...".
  final ValueNotifier<String> chunkInfo = ValueNotifier<String>('');

  /// Goes up by one every time the other phone starts sending us files.
  final ValueNotifier<int> incomingStart = ValueNotifier<int>(0);

  /// 'host', 'guest' or null (not connected).
  String? role;
  String? localIp;
  int? httpPort;
  int? tcpPort;
  String? sessionToken;

  HttpServer? _http;
  ServerSocket? _tcp;
  PairedPeer? _pending;
  TransferCancel? _activeCancel;
  final Map<String, _Incoming> _incoming = {};

  String? _rxTid;
  int _rxTotal = 0;
  int _rxDone = 0;
  int _rxCount = 0;
  int _rxFinished = 0;
  String _rxName = '';
  int _rxLastPub = 0;
  _Meter _rxMeter = _Meter();

  bool get isConnected => pairedPeer.value != null;

  /// 'idle', 'ok' or 'lost' (link broke, trying to reconnect by itself).
  final ValueNotifier<String> linkState = ValueNotifier<String>('idle');

  /// Set when the link ended because it could not be restored.
  final ValueNotifier<String?> linkNotice = ValueNotifier<String?>(null);

  /// Goes up when an interrupted send can be continued (ask the user).
  final ValueNotifier<int> resumeOffer = ValueNotifier<int>(0);

  int _boostGen = 0;
  Timer? _persistTimer;

  /// "Refresh speed": every stream gets a fresh TCP connection (a stalled or
  /// congested connection starts again from a clean state).
  void boostSpeed() => _boostGen++;

  void _afterLinkReady() {
    if (PartialStore.instance.pending != null) resumeOffer.value++;
  }

  // ------------------------------------------------------------------ IP

  static const MethodChannel _sys = MethodChannel('com.mafx.share/apps');

  /// Hotspot details found in the last scanned QR code (sender side).
  String? scannedSsid;
  String? scannedPassword;

  /// SSID / password of the hotspot this phone created for the QR code.
  String? hotspotSsid;
  String? hotspotPassword;

  /// Band of the hotspot this app created: 1 = 2.4 GHz, 2 = 5 GHz (0 = unknown).
  int hotspotBand = 0;
  bool _p2pActive = false;

  /// IP of our own Wi-Fi Direct group (the group owner), if one is running.
  Future<String?> _p2pIp() async {
    try {
      final ifs = await NetworkInterface.list(
          type: InternetAddressType.IPv4, includeLoopback: false);
      for (final i in ifs) {
        if (!i.name.toLowerCase().contains('p2p')) continue;
        for (final a in i.addresses) {
          if (!a.isLoopback) return a.address;
        }
      }
    } catch (_) {}
    return null;
  }

  Future<String?> getLocalIp({bool preferHotspot = false}) =>
      _getLocalIp(preferHotspot: preferHotspot);

  Future<String?> _getLocalIp({bool preferHotspot = false}) async {
    try {
      final interfaces = await NetworkInterface.list(
          type: InternetAddressType.IPv4, includeLoopback: false);
      bool isPrivateIpv4(String ip) {
        final parts = ip.split('.');
        if (parts.length != 4) return false;
        final first = int.tryParse(parts[0]) ?? -1;
        final second = int.tryParse(parts[1]) ?? -1;
        return first == 10 ||
            (first == 172 && second >= 16 && second <= 31) ||
            (first == 192 && second == 168);
      }

      final candidates = <Map<String, dynamic>>[];
      for (final interface in interfaces) {
        final name = interface.name.toLowerCase();
        // Wi-Fi Direct (p2p-wlan0-0, 192.168.49.1) and mobile data are NOT a
        // network the other phone can reach. This was the "Network is
        // unreachable" bug.
        if (name.contains('p2p') ||
            name.contains('dummy') ||
            name.contains('rmnet') ||
            name.contains('ccmni') ||
            name.contains('tun') ||
            name.contains('veth') ||
            name == 'lo') {
          continue;
        }
        final isHotspotIf = name.startsWith('ap') ||
            name.startsWith('swlan') ||
            name.startsWith('softap') ||
            name == 'wlan1' ||
            name == 'wlan2';
        final isWlan0 = name == 'wlan0' || name.startsWith('wlan') || name.contains('wifi');
        for (final address in interface.addresses) {
          final ip = address.address;
          if (address.isLoopback ||
              ip.startsWith('169.254.') ||
              !isPrivateIpv4(ip)) {
            continue;
          }
          if (ip == '192.168.49.1') continue; // Wi-Fi Direct group owner
          int priority;
          if (preferHotspot) {
            priority = isHotspotIf ? 0 : (isWlan0 ? 1 : 2);
          } else {
            priority = isWlan0 && !isHotspotIf ? 0 : (isHotspotIf ? 1 : 2);
          }
          candidates.add({'ip': ip, 'interface': interface.name, 'priority': priority});
        }
      }
      candidates.sort((a, b) => (a['priority'] as int).compareTo(b['priority'] as int));
      if (candidates.isEmpty) return null;
      final selected = candidates.first;
      debugPrint('Selected IP: ${selected['ip']} from ${selected['interface']}');
      return selected['ip'] as String;
    } catch (e) {
      return null;
    }
  }

  Future<bool> _call(String method, [Map<String, dynamic>? args]) async {
    try {
      return (await _sys.invokeMethod<bool>(method, args)) ?? false;
    } catch (_) {
      return false;
    }
  }

  Future<bool> isWifiOn() => _call('isWifiOn');
  Future<bool> isBluetoothOn() => _call('isBluetoothOn');
  Future<bool> isHotspotOn() => _call('isHotspotOn');

  // ------------------------------------------------------- Host (QR shown)

  /// [useHotspot] false = do not create a hotspot; use the Wi-Fi network both
  /// phones are already on (a 5 GHz router is usually much faster).
  Future<void> startReceiver({bool useHotspot = true, bool prefer5g = true}) async {
    await stopReceiver();
    String? ip;
    // 0) Try a 5 GHz Wi-Fi Direct group first (fast). If this phone cannot do
    //    it, fall back to the normal hotspot below (usually 2.4 GHz).
    if (useHotspot && prefer5g) {
      try {
        final r = await _sys.invokeMethod<Map>('startP2pGroup');
        if (r != null && (r['ssid'] as String?)?.isNotEmpty == true) {
          for (var i = 0; i < 12 && ip == null; i++) {
            ip = await _p2pIp();
            if (ip == null) await Future.delayed(const Duration(milliseconds: 400));
          }
          if (ip != null) {
            hotspotSsid = r['ssid'] as String;
            hotspotPassword = (r['password'] as String?) ?? '';
            hotspotBand = 2;
            _p2pActive = true;
          } else {
            await _call('stopP2pGroup');
          }
        }
      } catch (_) {
        await _call('stopP2pGroup');
      }
    }
    // 1) Create our own hotspot (like Xender). The other phone joins it by
    //    scanning the QR code - no router or manual hotspot needed.
    if (ip == null) try {
      final r = useHotspot ? await _sys.invokeMethod<Map>('startHotspot') : null;
      if (r != null && (r['ssid'] as String?)?.isNotEmpty == true) {
        hotspotSsid = r['ssid'] as String;
        hotspotPassword = (r['password'] as String?) ?? '';
        hotspotBand = 1; // normal hotspot: Android picks the band (usually 2.4 GHz)
        for (var i = 0; i < 10 && ip == null; i++) {
          ip = await _getLocalIp(preferHotspot: true);
          if (ip == null) await Future.delayed(const Duration(milliseconds: 400));
        }
        if (ip == null) {
          await _call('stopHotspot');
          hotspotSsid = null;
          hotspotPassword = null;
        }
      }
    } catch (_) {
      hotspotSsid = null;
      hotspotPassword = null;
    }
    // 2) Fall back to the WiFi / hotspot the user already turned on.
    ip ??= await _getLocalIp();
    if (ip == null) {
      throw Exception(
          'No WiFi or hotspot network found. Turn on WiFi (and Location) and try again.');
    }
    localIp = ip;
    sessionToken = const Uuid().v4();
    await _startServers();
  }

  /// Starts the HTTP + TCP servers (used by the host AND by the guest).
  Future<void> _startServers() async {
    await _stopServers();
    final server = await HttpServer.bind(InternetAddress.anyIPv4, 0);
    final tcp = await ServerSocket.bind(InternetAddress.anyIPv4, 0);
    _http = server;
    _tcp = tcp;
    httpPort = server.port;
    tcpPort = tcp.port;
    server.listen((req) {
      _onRequest(req);
    });
    tcp.listen((socket) {
      _onSocket(socket);
    });
  }

  Future<void> _stopServers() async {
    _persistTimer?.cancel();
    _persistTimer = null;
    await _persistPartials();
    for (final f in _incoming.values) {
      if (!f.done) {
        await _logPartial(f);
        try {
          f.raf.closeSync();
        } catch (_) {}
      }
    }
    _incoming.clear();
    final server = _http;
    final tcp = _tcp;
    _http = null;
    _tcp = null;
    try {
      await server?.close(force: true);
    } catch (_) {}
    try {
      await tcp?.close();
    } catch (_) {}
    httpPort = null;
    tcpPort = null;
    _rxTid = null;
  }

  /// Ends everything on this phone (servers, hotspot, connection).
  Future<void> stopReceiver() async {
    _activeCancel?.cancel();
    await _stopServers();
    sessionToken = null;
    hotspotBand = 0;
    if (_p2pActive) {
      _p2pActive = false;
      await _call('stopP2pGroup');
    }
    if (hotspotSsid != null) {
      hotspotSsid = null;
      hotspotPassword = null;
      await _call('stopHotspot');
    }
    disconnect();
  }

  /// Leave the other phone's hotspot (guest side).
  Future<void> releaseNetwork() => _call('releaseWifi');

  /// Forget the pairing (servers keep running until [stopReceiver]).
  void disconnect() {
    _pending = null;
    role = null;
    pairedPeer.value = null;
    progress.value = null;
    sendProgress.value = null;
    receiveProgress.value = null;
    linkState.value = 'idle';
    chunkInfo.value = '';
  }

  /// JSON shown in the QR code.
  String qrPayload() => jsonEncode({
        'app': 'MAFX_SHARE',
        'version': 2,
        'ip': localIp,
        'port': httpPort,
        'tcpPort': tcpPort,
        'token': sessionToken,
        'mode': mode.value.wire,
        if (hotspotSsid != null) 'ssid': hotspotSsid,
        if (hotspotSsid != null) 'pass': hotspotPassword ?? '',
      });

  void _json(HttpRequest req, Map<String, dynamic> body, {int status = 200}) {
    req.response
      ..statusCode = status
      ..headers.contentType = ContentType.json
      ..write(jsonEncode(body));
    req.response.close();
  }

  Future<Map<String, dynamic>> _readJson(HttpRequest req) async {
    final text = await utf8.decoder.bind(req).join();
    final v = jsonDecode(text);
    return v is Map<String, dynamic> ? v : <String, dynamic>{};
  }

  Future<void> _onRequest(HttpRequest req) async {
    try {
      final path = req.uri.path;
      if (path == '/ping') {
        _json(req, {'ok': true, 'app': 'MAFX_SHARE'});
        return;
      }
      if (path == '/pair' && req.method == 'POST') {
        final body = await _readJson(req);
        if (body['token'] != sessionToken) {
          _json(req, {'ok': false, 'error': 'bad token'}, status: 403);
          return;
        }
        final m = TransferMode.lower(
            TransferMode.parse(body['mode'] as String?), TransferMode.recommended);
        mode.value = m;
        final remote = req.connectionInfo?.remoteAddress.address ?? '';
        final reported = body['ip'];
        final peerIp =
            (reported is String && reported.isNotEmpty) ? reported : remote;
        role = 'host';
        pairedPeer.value = PairedPeer(
          ip: peerIp,
          port: (body['port'] as num?)?.toInt() ?? 0,
          tcpPort: (body['tcpPort'] as num?)?.toInt() ?? 0,
          token: sessionToken ?? '',
          mode: m,
        );
        linkState.value = 'ok';
        _beatFails = 0;
        _json(req, {'ok': true, 'tcpPort': tcpPort, 'mode': m.wire});
        _afterLinkReady();
        return;
      }
      if (path == '/send-metadata' && req.method == 'POST') {
        final body = await _readJson(req);
        if (body['token'] != sessionToken) {
          _json(req, {'ok': false, 'error': 'bad token'}, status: 403);
          return;
        }
        final have = await _prepareIncoming(body);
        _json(req, {'ok': true, 'have': have});
        return;
      }
      if (path == '/receive') {
        if (req.uri.queryParameters['token'] != sessionToken) {
          _json(req, {'ok': false, 'error': 'bad token'}, status: 403);
          return;
        }
        final id = req.uri.queryParameters['id'];
        final done = _rxTid != null &&
            _rxTid == id &&
            _rxCount > 0 &&
            _rxFinished >= _rxCount;
        // Chunks that never arrived, so the sender can send them again.
        final missing = <List<int>>[];
        if (!done && _rxTid == id) {
          for (final e in _incoming.entries) {
            if (!e.key.startsWith('$id:') || e.value.done) continue;
            final fileIndex = int.parse(e.key.split(':').last);
            final f = e.value;
            for (var c = 0; c < f.chunkCount && missing.length < 512; c++) {
              if (f.chunkDone[c] == 0) missing.add([fileIndex, c]);
            }
          }
        }
        _json(req, {
          'ok': true,
          'done': done,
          'received': _rxDone,
          'missing': missing,
        });
        return;
      }
      _json(req, {'ok': false, 'error': 'not found'}, status: 404);
    } catch (e) {
      debugPrint('HTTP error: $e');
      try {
        _json(req, {'ok': false, 'error': e.toString()}, status: 500);
      } catch (_) {}
    }
  }

  String _safeName(String name) {
    final n = p.basename(name).replaceAll(RegExp(r'[\\/:*?"<>|]'), '_');
    return n.isEmpty ? 'file' : n;
  }

  String _uniquePath(String dir, String name) {
    final first = p.join(dir, name);
    if (!File(first).existsSync() && !File('$first.mafxpart').existsSync()) {
      return first;
    }
    final base = p.basenameWithoutExtension(name);
    final ext = p.extension(name);
    var n = 1;
    while (File(p.join(dir, '$base ($n)$ext')).existsSync() ||
        File(p.join(dir, '$base ($n)$ext.mafxpart')).existsSync()) {
      n++;
    }
    return p.join(dir, '$base ($n)$ext');
  }

  /// Metadata arrives over HTTP (name, size, chunk size, mode). Every TCP
  /// stream then names the transfer + file in its first line, so nothing is
  /// assumed to be "already known" on a new socket.
  Future<Map<String, String>> _prepareIncoming(Map<String, dynamic> body) async {
    final tid = body['transferId'] as String;
    final files = (body['files'] as List).cast<Map>();
    final chunkSize =
        (body['chunkSize'] as num?)?.toInt() ?? TransferMode.turbo.chunkSize;
    final dir = await StorageService.instance.receiveDir();

    await _persistPartials();
    for (final f in _incoming.values) {
      if (!f.done) {
        await _logPartial(f);
        try {
          f.raf.closeSync();
        } catch (_) {}
      }
    }
    _incoming.clear();

    _rxTid = tid;
    _rxTotal = 0;
    _rxDone = 0;
    _rxCount = files.length;
    _rxFinished = 0;
    _rxName = '';
    _rxMeter = _Meter();
    final have = <String, String>{};

    for (var i = 0; i < files.length; i++) {
      final name = _safeName(files[i]['name'] as String);
      final size = (files[i]['size'] as num).toInt();
      final key = (files[i]['key'] as String?) ?? '$name|$size';
      final saved = PartialStore.instance.partial(key);

      String finalPath;
      String partPath;
      RandomAccessFile raf;
      Uint8List? resumed;
      if (saved != null &&
          saved['size'] == size &&
          File((saved['partPath'] ?? '') as String).existsSync()) {
        // The same file was received before and stopped half way: continue.
        finalPath = saved['finalPath'] as String;
        partPath = saved['partPath'] as String;
        resumed = _convertBitmap(
          base64Decode(saved['done'] as String),
          (saved['chunkSize'] as num).toInt(),
          chunkSize,
          size,
        );
        raf = await File(partPath).open(mode: FileMode.append);
      } else {
        finalPath = _uniquePath(dir.path, name);
        partPath = '$finalPath.mafxpart';
        raf = await File(partPath).open(mode: FileMode.write);
        if (size > 0) await raf.truncate(size);
      }
      final inc = _Incoming(key, name, size, finalPath, partPath, raf, chunkSize);
      if (resumed != null) {
        for (var c = 0; c < inc.chunkCount; c++) {
          if (resumed[c] == 1) {
            inc.chunkDone[c] = 1;
            inc.chunksDone++;
            _rxDone += ChunkCodec.lengthOf(c, size, chunkSize);
          }
        }
        if (inc.chunksDone > 0) have['$i'] = base64Encode(inc.chunkDone);
      }
      _incoming['$tid:$i'] = inc;
      _rxTotal += size;
    }
    for (final f in _incoming.values.toList()) {
      if (!f.done && f.chunksDone >= f.chunkCount) await _completeFile(f);
    }
    _persistTimer?.cancel();
    _persistTimer =
        Timer.periodic(const Duration(seconds: 3), (_) => _persistPartials());
    _publishRx(force: true);
    incomingStart.value++;
    return have;
  }

  /// Chunk bitmap saved with one chunk size -> the chunk size used now.
  Uint8List _convertBitmap(List<int> old, int oldSize, int newSize, int size) {
    final count = ChunkCodec.chunkCount(size, newSize);
    final out = Uint8List(count);
    for (var c = 0; c < count; c++) {
      final start = c * newSize;
      final end = math.min(size, start + newSize);
      var ok = true;
      for (var o = start ~/ oldSize; o <= (end - 1) ~/ oldSize; o++) {
        if (o >= old.length || old[o] != 1) {
          ok = false;
          break;
        }
      }
      out[c] = ok ? 1 : 0;
    }
    return out;
  }

  /// Saves which chunks are already on disk, so the file can be continued.
  Future<void> _persistPartials() async {
    final items = <String, Map<String, dynamic>>{};
    for (final f in _incoming.values) {
      if (f.done || f.chunksDone == 0) continue;
      items[f.key] = {
        'name': f.name,
        'size': f.size,
        'finalPath': f.finalPath,
        'partPath': f.partPath,
        'chunkSize': f.chunkSize,
        'done': base64Encode(f.chunkDone),
      };
    }
    await PartialStore.instance.putPartials(items);
  }

  /// History keeps interrupted transfers too.
  Future<void> _logPartial(_Incoming f) async {
    if (f.loggedPartial || f.chunksDone == 0 || f.chunksDone >= f.chunkCount) {
      return;
    }
    f.loggedPartial = true;
    await HistoryService.instance.add(
      name: f.name,
      size: f.size,
      type: 'received',
      path: f.partPath,
      status: 'partial',
      percent: (f.chunksDone * 100 ~/ f.chunkCount).clamp(0, 99),
    );
  }

  Future<void> _completeFile(_Incoming f) async {
    f.done = true;
    try {
      f.raf.closeSync();
    } catch (_) {}
    var finalPath = f.finalPath;
    try {
      await File(f.partPath).rename(f.finalPath);
    } catch (_) {
      finalPath = f.partPath;
    }
    // Integrity: the finished file must have exactly the announced size.
    var sizeOk = true;
    try {
      sizeOk = File(finalPath).lengthSync() == f.size;
    } catch (_) {}
    await PartialStore.instance.removePartial(f.key);
    if (sizeOk) {
      // Publish to the public Android folders only AFTER a complete,
      // verified transfer. The temporary file is removed once it is safe.
      try {
        final pub = await StorageService.instance.publish(finalPath, f.name);
        if (pub != null) {
          try {
            File(finalPath).deleteSync();
          } catch (_) {}
          finalPath = pub.location;
        }
      } catch (_) {}
    }
    _rxFinished++;
    await HistoryService.instance.add(
      name: f.name,
      size: f.size,
      type: 'received',
      path: finalPath,
    );
    _publishRx(force: true);
  }

  void _publishRx({bool force = false}) {
    final now = DateTime.now().millisecondsSinceEpoch;
    if (!force && now - _rxLastPub < 120) return;
    _rxLastPub = now;
    final index = math.min(_rxFinished + 1, math.max(_rxCount, 1));
    final tp = TransferProgress(
      direction: 'received',
      currentName: _rxName,
      fileIndex: index,
      fileCount: _rxCount,
      doneBytes: _rxDone,
      totalBytes: _rxTotal,
      speed: _rxMeter.speed,
      mode: mode.value,
      finished: _rxCount > 0 && _rxFinished >= _rxCount,
    );
    receiveProgress.value = tp;
    progress.value = tp;
  }

  void _tune(Socket s, TransferMode m) {
    try {
      s.setOption(SocketOption.tcpNoDelay, true);
    } catch (_) {}
    // Linux / Android: SOL_SOCKET = 1, SO_SNDBUF = 7, SO_RCVBUF = 8.
    // Android may clamp the value to its own limit; that is fine.
    try {
      s.setRawOption(RawSocketOption.fromInt(1, 7, m.socketBuffer));
    } catch (_) {}
    try {
      s.setRawOption(RawSocketOption.fromInt(1, 8, m.socketBuffer));
    } catch (_) {}
  }

  /// One TCP stream. Layout:
  ///   handshake line (JSON): {token, transferId, file, mode}\n
  ///   then any number of chunks: [u32 chunkIndex][u32 length][bytes]
  ///   optional end marker (index 0xFFFFFFFF) -> a new handshake line follows
  ///
  /// Bytes are collected in an app buffer and written to the file at
  /// chunkIndex * chunkSize. A chunk is only counted when ALL its bytes are on
  /// disk, so duplicates are ignored and half-received chunks are re-sent.
  Future<void> _onSocket(Socket socket) async {
    var m = mode.value;
    _tune(socket, m);

    final lineBuf = BytesBuilder(copy: false);
    final hdr = Uint8List(ChunkCodec.headerSize);
    var hdrLen = 0;
    var buf = Uint8List(math.min(m.bufferSize, TransferMode.recommended.bufferSize));
    var bufLen = 0;
    var bufPos = 0;
    var pos = 0;
    var remaining = 0;
    var chunkIndex = 0;
    var inChunk = false;
    var skipping = false;
    var chunkCounted = 0;
    var testing = false; // speed-test socket: data is thrown away
    _Incoming? file;

    void flush() {
      final f = file;
      if (f == null || bufLen == 0) {
        bufLen = 0;
        return;
      }
      f.raf.setPositionSync(bufPos);
      f.raf.writeFromSync(buf, 0, bufLen);
      _rxDone += bufLen;
      chunkCounted += bufLen;
      _rxName = f.name;
      _rxMeter.update(_rxDone);
      bufLen = 0;
      _publishRx();
    }

    void put(Uint8List data, int from, int count) {
      while (count > 0) {
        if (bufLen == 0) bufPos = pos;
        final n = math.min(buf.length - bufLen, count);
        buf.setRange(bufLen, bufLen + n, data, from);
        bufLen += n;
        from += n;
        count -= n;
        pos += n;
        if (bufLen == buf.length) flush();
      }
    }

    try {
      await for (final Uint8List data in socket) {
        if (testing) continue;
        var off = 0;
        while (off < data.length) {
          if (file == null) {
            // ---- handshake line
            final nl = data.indexOf(10, off);
            if (nl < 0) {
              lineBuf.add(Uint8List.sublistView(data, off));
              if (lineBuf.length > 4096) throw Exception('bad handshake');
              off = data.length;
              continue;
            }
            lineBuf.add(Uint8List.sublistView(data, off, nl));
            off = nl + 1;
            final h = jsonDecode(utf8.decode(lineBuf.takeBytes()))
                as Map<String, dynamic>;
            if (h['token'] != sessionToken) throw Exception('bad token');
            if (h['test'] == true) {
              testing = true;
              break;
            }
            final found = _incoming['${h['transferId']}:${h['file']}'];
            if (found == null || found.done) throw Exception('unknown file');
            file = found;
            m = TransferMode.parse(h['mode'] as String?);
            final wantBuf = math.min(m.bufferSize, TransferMode.recommended.bufferSize);
            if (buf.length != wantBuf) buf = Uint8List(wantBuf);
            bufLen = 0;
            hdrLen = 0;
            inChunk = false;
          } else if (!inChunk) {
            // ---- 8-byte chunk header (may be split over packets)
            final n = math.min(hdr.length - hdrLen, data.length - off);
            hdr.setRange(hdrLen, hdrLen + n, data, off);
            hdrLen += n;
            off += n;
            if (hdrLen < hdr.length) continue;
            hdrLen = 0;
            final idx = ChunkCodec.chunkIndexOf(hdr);
            final len = ChunkCodec.dataLengthOf(hdr);
            if (idx == ChunkCodec.endMarkerIndex) {
              file = null; // next: a new handshake line
              continue;
            }
            final f = file!;
            if (idx >= f.chunkCount ||
                len != ChunkCodec.lengthOf(idx, f.size, f.chunkSize)) {
              throw Exception('bad chunk');
            }
            chunkIndex = idx;
            skipping = f.chunkDone[idx] == 1; // duplicate: read and drop
            pos = ChunkCodec.offsetOf(idx, f.chunkSize);
            remaining = len;
            chunkCounted = 0;
            inChunk = true;
          } else {
            // ---- chunk data
            final take = math.min(data.length - off, remaining);
            if (!skipping) put(data, off, take);
            off += take;
            remaining -= take;
            if (remaining == 0) {
              inChunk = false;
              final f = file!;
              if (!skipping) {
                flush();
                if (f.chunkDone[chunkIndex] == 1) {
                  _rxDone -= chunkCounted; // another stream got it first
                } else {
                  f.chunkDone[chunkIndex] = 1;
                  f.chunksDone++;
                  if (f.chunksDone >= f.chunkCount && !f.done) {
                    await _completeFile(f);
                  }
                }
              }
              chunkCounted = 0;
            }
          }
        }
      }
    } catch (e) {
      debugPrint('Socket error: $e');
    } finally {
      try {
        if (inChunk && !skipping) {
          bufLen = 0; // half a chunk is useless; the sender will resend it
          _rxDone -= chunkCounted;
        }
      } catch (_) {}
      socket.destroy();
    }
  }

  // ----------------------------------------------------- Guest (QR scanned)

  Future<void> connectToReceiver(
    String receiverUrl,
    String token,
    TransferMode m, {
    int tcpPort = 0,
    String? ssid,
    String? password,
  }) async {
    disconnect();
    // If this phone is already on the other phone's Wi-Fi (its own hotspot),
    // make sure our traffic uses that Wi-Fi and not mobile data.
    await _call('bindToWifi');
    final uri = Uri.parse(receiverUrl);
    http.Response? res;
    Object? firstError;
    try {
      res = await http
          .get(Uri.parse('$receiverUrl/ping'))
          .timeout(const Duration(seconds: 4));
    } catch (e) {
      firstError = e;
    }
    // Not reachable on the current network: join the other phone's hotspot.
    if ((res == null || res.statusCode != 200) && ssid != null && ssid.isNotEmpty) {
      final joined =
          await _call('connectToWifi', {'ssid': ssid, 'password': password ?? ''});
      if (!joined) {
        throw Exception(
            'Could not join the other phone\'s hotspot. Allow the connection and try again.');
      }
      Object? err;
      for (var i = 0; i < 8; i++) {
        try {
          res = await http
              .get(Uri.parse('$receiverUrl/ping'))
              .timeout(const Duration(seconds: 3));
          if (res.statusCode == 200) break;
        } catch (e) {
          err = e;
        }
        await Future.delayed(const Duration(milliseconds: 800));
      }
      if (res == null || res.statusCode != 200) {
        throw Exception('The other phone did not answer. ${err ?? ''}');
      }
    } else if (res == null) {
      throw Exception(
          'Could not reach the other phone. Join its Wi-Fi / hotspot first, then scan again.');
    }
    if (res.statusCode != 200) {
      throw Exception('The other phone did not answer.');
    }
    final j = jsonDecode(res.body);
    if (j is! Map || j['app'] != 'MAFX_SHARE') {
      throw Exception('This is not a MAFX SHARE phone.');
    }
    _pending = PairedPeer(
      ip: uri.host,
      port: uri.port,
      tcpPort: tcpPort,
      token: token,
      mode: m,
    );
    mode.value = m;
  }

  /// The guest starts its own servers and tells the host where they are, so
  /// the host can send files back (two-way transfer).
  Future<void> announcePairing() async {
    final peer = _pending;
    if (peer == null) throw StateError('Call connectToReceiver first.');
    localIp = await _getLocalIp();
    sessionToken = peer.token;
    await _startServers();
    final http.Response res;
    try {
      res = await http
          .post(
            Uri.parse('http://${peer.ip}:${peer.port}/pair'),
            headers: _jsonHeaders,
            body: jsonEncode({
              'token': peer.token,
              'mode': peer.mode.wire,
              'ip': localIp,
              'port': httpPort,
              'tcpPort': tcpPort,
            }),
          )
          .timeout(const Duration(seconds: 6));
    } catch (_) {
      await _stopServers();
      rethrow;
    }
    if (res.statusCode != 200) {
      await _stopServers();
      throw Exception('The other phone refused the connection.');
    }
    final j = jsonDecode(res.body) as Map<String, dynamic>;
    final tcp = (j['tcpPort'] as num?)?.toInt() ?? peer.tcpPort;
    role = 'guest';
    _pending = null;
    pairedPeer.value = PairedPeer(
      ip: peer.ip,
      port: peer.port,
      tcpPort: tcp,
      token: peer.token,
      mode: peer.mode,
    );
    linkState.value = 'ok';
    _beatFails = 0;
    _afterLinkReady();
  }

  // ------------------------------------------------------------- Sending

  final List<_QueuedSend> _sendQueue = [];
  bool _pumping = false;

  /// Sends files to the paired phone (works from the host AND the guest).
  /// You can call this again while a transfer is running: the new files wait
  /// in line and are sent right after, so everything arrives (like Xender).
  Future<void> sendFiles(List<PendingFile> files, {TransferCancel? cancel}) {
    if (pairedPeer.value == null) throw StateError('Not connected.');
    final q = _QueuedSend(files, cancel);
    unawaited(q.done.future.catchError((_) {}));
    _sendQueue.add(q);
    queued.value = _pumping ? _sendQueue.length : _sendQueue.length - 1;
    unawaited(_pump());
    return q.done.future;
  }

  Future<void> _pump() async {
    if (_pumping) return;
    _pumping = true;
    try {
      while (_sendQueue.isNotEmpty) {
        final q = _sendQueue.removeAt(0);
        queued.value = _sendQueue.length;
        final peer = pairedPeer.value;
        if (peer == null) {
          q.done.completeError(StateError('Not connected.'));
          continue;
        }
        try {
          await _sendFilesTo(peer, q.files, mode.value, cancel: q.cancel);
          q.done.complete();
        } catch (e) {
          q.done.completeError(e);
          if (linkState.value == 'lost' || pairedPeer.value == null) {
            // Link broke: keep EVERYTHING that was waiting so it can all be
            // continued after reconnecting.
            final rest = <PendingFile>[...q.files];
            while (_sendQueue.isNotEmpty) {
              final n = _sendQueue.removeAt(0);
              rest.addAll(n.files);
              n.done.completeError(Exception('Connection lost.'));
            }
            final pct = (PartialStore.instance.pending?['percent'] as num?)?.toInt() ?? 0;
            await PartialStore.instance.setPending({
              'files': [
                for (final f in rest) {'path': f.path, 'name': f.name, 'size': f.size},
              ],
              'percent': pct,
              'time': DateTime.now().millisecondsSinceEpoch,
            });
          }
        }
      }
    } finally {
      _pumping = false;
      queued.value = 0;
    }
  }

  /// Single-file API: streams [file] to the given receiver with the chosen
  /// mode ('standard' or '5g_plus'). [onProgress] gets bytes sent, total
  /// bytes and the measured speed in MB/s. Completes only after the receiver
  /// confirmed that the whole file is on its disk.
  Future<void> sendFileTurbo({
    required String receiverIp,
    required int receiverTcpPort,
    required File file,
    required String mode,
    required void Function(int sent, int total, double speedMBps) onProgress,
    TransferCancel? cancel,
  }) async {
    final cur = pairedPeer.value;
    if (cur == null) throw StateError('Not connected.');
    final m = TransferMode.parse(mode);
    final peer = PairedPeer(
      ip: receiverIp,
      port: cur.port,
      tcpPort: receiverTcpPort,
      token: cur.token,
      mode: m,
    );
    final size = await file.length();
    await _sendFilesTo(
      peer,
      [
        PendingFile(
          id: file.path,
          path: file.path,
          name: p.basename(file.path),
          size: size,
        ),
      ],
      m,
      cancel: cancel,
      onProgress: onProgress,
    );
  }

  void cancelTransfer() => _activeCancel?.cancel();

  Future<void> _sendFilesTo(
    PairedPeer peer,
    List<PendingFile> files,
    TransferMode cfg, {
    TransferCancel? cancel,
    void Function(int sent, int total, double speedMBps)? onProgress,
  }) async {
    final token = cancel ?? TransferCancel();
    _activeCancel = token;
    final tid = const Uuid().v4();
    final base = 'http://${peer.ip}:${peer.port}';
    final total = files.fold<int>(0, (s, f) => s + f.size);

    // Same file again (name|size|date) lets the receiver continue a half file.
    final keys = <String>[];
    for (final f in files) {
      var mt = 0;
      try {
        mt = (await File(f.path).lastModified()).millisecondsSinceEpoch;
      } catch (_) {}
      keys.add('${f.name}|${f.size}|$mt');
    }
    Future<void> savePending(int percent) => PartialStore.instance.setPending({
          'files': [
            for (final f in files) {'path': f.path, 'name': f.name, 'size': f.size},
          ],
          'percent': percent,
          'time': DateTime.now().millisecondsSinceEpoch,
        });
    await savePending(0);

    // Is the other phone still there?
    try {
      final r = await http
          .get(Uri.parse('$base/ping'))
          .timeout(const Duration(seconds: 4));
      if (r.statusCode != 200) throw Exception('no answer');
    } catch (_) {
      unawaited(_connectionLost());
      throw Exception('Connection lost. Reconnecting... You can continue after that.');
    }

    final meta = await http
        .post(
          Uri.parse('$base/send-metadata'),
          headers: _jsonHeaders,
          body: jsonEncode({
            'token': peer.token,
            'transferId': tid,
            'mode': cfg.wire,
            'chunkSize': cfg.chunkSize,
            'files': [
              for (var i = 0; i < files.length; i++)
                {
                  'name': files[i].name,
                  'size': files[i].size,
                  'key': keys[i],
                  'chunks': ChunkCodec.chunkCount(files[i].size, cfg.chunkSize),
                },
            ],
          }),
        )
        .timeout(const Duration(seconds: 15));
    if (meta.statusCode != 200) {
      throw Exception('The other phone could not accept the files.');
    }

    // Chunks the receiver already has (continue after an interruption).
    final have = List<Uint8List?>.filled(files.length, null);
    try {
      final mj = jsonDecode(meta.body);
      final hm = (mj is Map ? mj['have'] : null) as Map?;
      hm?.forEach((k, v) {
        final i = int.tryParse(k.toString());
        if (i != null && i >= 0 && i < files.length && v is String) {
          have[i] = base64Decode(v);
        }
      });
    } catch (_) {}

    final jobs = <_Job>[];
    var haveBytes = 0;
    for (var i = 0; i < files.length; i++) {
      final n = ChunkCodec.chunkCount(files[i].size, cfg.chunkSize);
      for (var c = 0; c < n; c++) {
        final h = have[i];
        if (h != null && c < h.length && h[c] == 1) {
          haveBytes += ChunkCodec.lengthOf(c, files[i].size, cfg.chunkSize);
        } else {
          jobs.add(_Job(i, c));
        }
      }
    }

    final meter = _Meter();
    final fileSent = List<int>.filled(files.length, 0);
    var sent = 0; // bytes written to the network by us
    var ack = haveBytes; // bytes the RECEIVER confirmed are on its disk
    var lastPub = 0;

    // Progress is what the receiver confirmed, so both phones show the same
    // number and the same speed.
    int currentIndex() {
      var acc = 0;
      for (var i = 0; i < files.length; i++) {
        acc += files[i].size;
        if (ack < acc) return i;
      }
      return files.length - 1;
    }

    void publish({bool force = false, bool finished = false}) {
      final now = DateTime.now().millisecondsSinceEpoch;
      if (!force && now - lastPub < 150) return;
      lastPub = now;
      final idx = currentIndex();
      final tp = TransferProgress(
        direction: 'sent',
        currentName: files[idx].name,
        fileIndex: idx + 1,
        fileCount: files.length,
        doneBytes: ack,
        totalBytes: total,
        speed: meter.speed,
        mode: cfg,
        finished: finished,
      );
      sendProgress.value = tp;
      progress.value = tp;
      onProgress?.call(ack, total, meter.speed / 1048576);
    }

    meter.update(ack);
    publish(force: true);

    var polling = false;
    final poller = Timer.periodic(const Duration(milliseconds: 500), (_) async {
      if (polling) return;
      polling = true;
      try {
        final res = await http
            .get(Uri.parse('$base/receive?id=$tid&token=${peer.token}'))
            .timeout(const Duration(seconds: 3));
        if (res.statusCode == 200) {
          final j = jsonDecode(res.body);
          final r = j is Map ? (j['received'] as num?)?.toInt() : null;
          if (r != null && r >= ack) {
            ack = r;
            meter.update(ack);
            publish(force: true);
          }
        }
      } catch (_) {
      } finally {
        polling = false;
      }
    });

    // All streams (cfg.streams) start at once and take the next free chunk;
    // the receiver puts every chunk back at chunkIndex * chunkSize.
    Future<void> runJobs(List<_Job> list, {required bool count}) async {
      var next = 0;
      var failed = false;
      var connected = 0;
      var connectFails = 0;
      // Start with cfg.streams; the watchdog below adds more streams (up to
      // cfg.maxStreams) for as long as the speed really goes up.
      final workerCount = math.min(cfg.maxStreams, list.length);
      final sockets = <Socket>[];
      final perStream = List<int>.filled(workerCount, 0);
      var allowed = math.min(cfg.streams, workerCount);
      var started = 0;
      final running = <Future<void>>[];

      Future<void> worker(int w) async {
        Socket? socket;
        var gen = _boostGen;
        var bound = -1;
        final handles = <int, RandomAccessFile>{};
        try {
          while (!failed && next < list.length && w < allowed) {
            if (token.cancelled) throw Exception('Transfer cancelled.');
            // "Refresh speed" pressed: start again with a fresh connection.
            if (socket != null && gen != _boostGen) {
              try {
                await socket.flush();
                await socket.close();
              } catch (_) {}
              socket.destroy();
              sockets.remove(socket);
              socket = null;
              bound = -1;
            }
            final Socket sk;
            final existing = socket;
            if (existing != null) {
              sk = existing;
            } else {
              try {
                sk = await _openSocket(peer, cfg);
              } catch (_) {
                connectFails++;
                if (connected == 0 && connectFails >= workerCount) rethrow;
                return;
              }
              socket = sk;
              sockets.add(sk);
              gen = _boostGen;
              connected++;
            }
            if (next >= list.length) break;
            final job = list[next++];
            final f = files[job.file];
            if (bound != job.file) {
              if (bound >= 0) sk.add(ChunkCodec.endMarker());
              sk.add(utf8.encode('${jsonEncode({
                    'token': peer.token,
                    'transferId': tid,
                    'file': job.file,
                    'mode': cfg.wire,
                  })}\n'));
              bound = job.file;
            }
            var raf = handles[job.file];
            if (raf == null) {
              raf = await File(f.path).open();
              handles[job.file] = raf;
            }
            await _sendChunk(sk, raf, cfg, f.size, job.chunk, token, (n) {
              if (!count) return;
              sent += n;
              fileSent[job.file] += n;
            });
            if (count) {
              perStream[w]++;
              final done = perStream.fold<int>(0, (a, b) => a + b);
              chunkInfo.value =
                  'Chunks $done/${list.length} • per stream: ${perStream.join(' ')}';
            }
          }
          if (socket != null) {
            await socket.flush();
            await socket.close();
          }
        } catch (_) {
          failed = true;
          rethrow;
        } finally {
          for (final r in handles.values) {
            try {
              await r.close();
            } catch (_) {}
          }
          socket?.destroy();
        }
      }

      void launch() {
        while (started < allowed) {
          final f = worker(started++);
          unawaited(f.catchError((_) {}));
          running.add(f);
        }
        activeStreams.value = allowed;
      }

      // Watchdog: slow-down -> refresh the streams by itself; nothing moving
      // for 25 s -> the link is dead, stop (the transfer can be continued).
      Future<void> watchdog() async {
        var peak = 0.0;
        var slow = 0;
        var lastSent = sent;
        var lastAck = ack;
        var lastMove = DateTime.now();
        var lastBoost = DateTime.now();
        // Add streams (x1.5 each step) only while the speed really goes up
        // (10% or more); when it stops growing, go back to the best count.
        // More streams are not always faster on weak Wi-Fi.
        var rampBest = 0.0;
        var rampAllowed = allowed;
        var rampDone = allowed >= workerCount;
        while (!failed && next < list.length + workerCount) {
          for (var i = 0; i < 10 && !failed; i++) {
            await Future.delayed(const Duration(milliseconds: 250));
          }
          if (failed) break;
          final speed = (sent - lastSent) / 2.5;
          if (sent != lastSent || ack != lastAck) lastMove = DateTime.now();
          lastSent = sent;
          lastAck = ack;
          if (DateTime.now().difference(lastMove) > const Duration(seconds: 25)) {
            failed = true;
            for (final s in List<Socket>.of(sockets)) {
              s.destroy();
            }
            return;
          }
          if (!rampDone) {
            if (speed > rampBest * 1.10) {
              rampBest = speed;
              rampAllowed = allowed;
              if (allowed >= workerCount) {
                rampDone = true;
              } else {
                allowed = math.min(workerCount, allowed + math.max(4, allowed ~/ 2));
                launch();
              }
            } else {
              rampDone = true;
              if (allowed > rampAllowed) {
                allowed = rampAllowed;
                activeStreams.value = allowed;
              }
            }
          }
          if (speed > peak) peak = speed;
          slow = (peak > 0 && speed < peak * 0.5) ? slow + 1 : 0;
          if (slow >= 2 &&
              DateTime.now().difference(lastBoost) > const Duration(seconds: 15)) {
            boostSpeed();
            slow = 0;
            peak = speed;
            lastBoost = DateTime.now();
          }
        }
      }

      try {
        launch();
        final dog = count ? watchdog() : Future<void>.value();
        while (true) {
          final snapshot = List<Future<void>>.of(running);
          await Future.wait(snapshot, eagerError: true);
          if (running.length == snapshot.length) break;
        }
        failed = true; // ends the watchdog
        await dog;
      } finally {
        failed = true;
        activeStreams.value = 0;
      }
    }

    try {
      await runJobs(jobs, count: true);

      // Wait for the receiver's acknowledgement. If chunks are missing, send
      // exactly those again (up to 3 rounds).
      var rounds = 0;
      var lastReceived = -1;
      var stalledSince = DateTime.now();
      while (true) {
        if (token.cancelled) throw Exception('Transfer cancelled.');
        Map<String, dynamic>? st;
        try {
          final res = await http
              .get(Uri.parse('$base/receive?id=$tid&token=${peer.token}'))
              .timeout(const Duration(seconds: 5));
          if (res.statusCode == 200) {
            final j = jsonDecode(res.body);
            if (j is Map<String, dynamic>) st = j;
          }
        } catch (_) {}
        if (st != null && st['done'] == true) break;
        final received = (st?['received'] as num?)?.toInt() ?? -1;
        if (received != lastReceived) {
          lastReceived = received;
          stalledSince = DateTime.now();
        }
        final stalled = DateTime.now().difference(stalledSince);
        final missing = (st?['missing'] as List?) ?? const [];
        if (stalled > const Duration(seconds: 2) &&
            missing.isNotEmpty &&
            rounds < 3) {
          rounds++;
          stalledSince = DateTime.now();
          await runJobs([
            for (final m in missing.cast<List>())
              _Job((m[0] as num).toInt(), (m[1] as num).toInt()),
          ], count: false);
          continue;
        }
        if (stalled > const Duration(seconds: 60)) {
          throw Exception('The other phone did not confirm the files.');
        }
        await Future.delayed(const Duration(milliseconds: 250));
      }
      poller.cancel();
      ack = total;
      publish(force: true, finished: true); // -> green tick on both phones
      for (final f in files) {
        await HistoryService.instance.add(
          name: f.name,
          size: f.size,
          type: 'sent',
          path: f.path,
        );
      }
      await PartialStore.instance.setPending(null);
    } catch (e) {
      poller.cancel();
      final lost = linkState.value == 'lost';
      if (!token.cancelled || lost) {
        // History keeps what was interrupted, and the files are remembered so
        // the transfer can be continued after reconnecting.
        final pct = total == 0 ? 0 : (ack * 100 ~/ total).clamp(0, 99);
        await savePending(pct);
        for (var i = 0; i < files.length; i++) {
          if (files[i].size == 0) continue;
          await HistoryService.instance.add(
            name: files[i].name,
            size: files[i].size,
            type: 'sent',
            path: files[i].path,
            status: 'partial',
            percent: pct,
          );
        }
        if (!lost) unawaited(_connectionLost());
      }
      if (lost) {
        throw Exception('Connection lost. You can continue after it reconnects.');
      }
      rethrow;
    }
  }

  Future<Socket> _openSocket(PairedPeer peer, TransferMode m) async {
    final s = await Socket.connect(
      peer.ip,
      peer.tcpPort,
      timeout: const Duration(seconds: 10),
    );
    _tune(s, m);
    return s;
  }

  /// Sends one chunk. The next piece is read from disk while the previous
  /// piece is still going out on the network (read-ahead).
  Future<void> _sendChunk(
    Socket socket,
    RandomAccessFile raf,
    TransferMode m,
    int fileSize,
    int chunk,
    TransferCancel token,
    void Function(int bytes) onBytes,
  ) async {
    final length = ChunkCodec.lengthOf(chunk, fileSize, m.chunkSize);
    socket.add(ChunkCodec.encodeHeader(chunk, length));
    await raf.setPosition(ChunkCodec.offsetOf(chunk, m.chunkSize));
    var remaining = length;
    var unflushed = 0;
    final window = m.bufferSize * 2;
    Future<Uint8List> pending = raf.read(math.min(m.bufferSize, remaining));
    while (remaining > 0) {
      if (token.cancelled) throw Exception('Transfer cancelled.');
      final bytes = await pending;
      if (bytes.isEmpty) throw Exception('The file changed while sending.');
      remaining -= bytes.length;
      if (remaining > 0) pending = raf.read(math.min(m.bufferSize, remaining));
      socket.add(bytes);
      unflushed += bytes.length;
      // Keep the socket full: wait only after 2 buffers are queued, not
      // after every piece.
      if (unflushed >= window) {
        await socket.flush();
        onBytes(unflushed);
        unflushed = 0;
      }
    }
    if (unflushed > 0) {
      await socket.flush();
      onBytes(unflushed);
    }
  }

  // ------------------------------------------------- keep the link alive

  int _lastNotif = 0;
  Timer? _beatTimer;
  int _beatFails = 0;
  int _beatBytes = -1;

  /// While two phones are connected a foreground service keeps the app, the
  /// CPU and the Wi-Fi alive, even when the user leaves the app.
  void _onPeerChanged() {
    _beatTimer?.cancel();
    _beatTimer = null;
    if (pairedPeer.value != null) {
      unawaited(_call('startKeepAlive', {'text': 'Connected - ready to transfer'}));
      _beatFails = 0;
      _beatTimer = Timer.periodic(const Duration(seconds: 4), (_) => _beat());
    } else {
      unawaited(_call('stopKeepAlive'));
    }
  }

  Future<bool> _ping(PairedPeer peer) async {
    try {
      final r = await http
          .get(Uri.parse('http://${peer.ip}:${peer.port}/ping'))
          .timeout(const Duration(seconds: 3));
      return r.statusCode == 200;
    } catch (_) {
      return false;
    }
  }

  /// Notices when the other phone is really gone (not just busy).
  Future<void> _beat() async {
    final peer = pairedPeer.value;
    if (peer == null || peer.port == 0 || linkState.value == 'lost') return;
    final moved = (sendProgress.value?.doneBytes ?? 0) + _rxDone;
    final active = (sendProgress.value?.finished == false) ||
        (receiveProgress.value?.finished == false);
    if (active && moved != _beatBytes) {
      _beatBytes = moved; // data is moving, so it is alive
      _beatFails = 0;
      return;
    }
    _beatBytes = moved;
    if (await _ping(peer)) {
      _beatFails = 0;
      return;
    }
    if (++_beatFails >= 2) unawaited(_connectionLost());
  }

  /// The link broke (Wi-Fi off, out of range ...). Keep everything that
  /// arrived, show it on screen and try to reconnect by itself.
  Future<void> _connectionLost() async {
    if (linkState.value == 'lost' || pairedPeer.value == null) return;
    linkState.value = 'lost';
    _activeCancel?.cancel();
    final until = DateTime.now().add(const Duration(seconds: 90));
    while (linkState.value == 'lost' &&
        pairedPeer.value != null &&
        DateTime.now().isBefore(until)) {
      final peer = pairedPeer.value!;
      try {
        if (role == 'guest') {
          var ok = await _ping(peer);
          final ssid = scannedSsid;
          if (!ok && ssid != null && ssid.isNotEmpty) {
            await _call(
                'connectToWifi', {'ssid': ssid, 'password': scannedPassword ?? ''});
            ok = await _ping(peer);
          }
          if (ok) {
            await _repairPairing(peer);
            linkState.value = 'ok';
            _beatFails = 0;
            _afterLinkReady();
            return;
          }
        } else if (await _ping(peer)) {
          linkState.value = 'ok';
          _beatFails = 0;
          _afterLinkReady();
          return;
        }
        // (the host also gets linkState 'ok' when the guest calls /pair again)
      } catch (_) {}
      await Future.delayed(const Duration(seconds: 4));
    }
    if (linkState.value == 'lost') {
      // Could not be restored: end the session; the app goes back to Home and
      // the Send / Received cards come back.
      linkNotice.value = 'Connection ended. Connect the phones again.';
      await stopReceiver();
      await releaseNetwork();
    }
  }

  /// After the guest is back on the network it tells the host its address.
  Future<void> _repairPairing(PairedPeer peer) async {
    localIp = await _getLocalIp() ?? localIp;
    final res = await http
        .post(
          Uri.parse('http://${peer.ip}:${peer.port}/pair'),
          headers: _jsonHeaders,
          body: jsonEncode({
            'token': peer.token,
            'mode': peer.mode.wire,
            'ip': localIp,
            'port': httpPort,
            'tcpPort': tcpPort,
          }),
        )
        .timeout(const Duration(seconds: 6));
    if (res.statusCode != 200) throw Exception('pair refused');
  }

  void _onProgressForNotification() {
    final pr = progress.value;
    if (pr == null || pairedPeer.value == null) return;
    final now = DateTime.now().millisecondsSinceEpoch;
    if (!pr.finished && now - _lastNotif < 1500) return;
    _lastNotif = now;
    final pct = (pr.fraction * 100).round();
    final text = pr.finished
        ? 'Transfer complete'
        : '${pr.direction == 'sent' ? 'Sending' : 'Receiving'} $pct% - ${formatSpeed(pr.speed)}';
    unawaited(_call('updateKeepAlive', {'text': text}));
  }

  /// Wi-Fi band / link speed of this phone, if Android tells us.
  /// {freq: MHz, speed: Mbps, rssi: dBm} or null.
  Future<Map<String, int>?> wifiLinkInfo() async {
    try {
      final r = await _sys.invokeMethod<Map>('wifiLinkInfo');
      if (r == null) return null;
      return {
        'freq': (r['freq'] as num?)?.toInt() ?? -1,
        'speed': (r['speed'] as num?)?.toInt() ?? -1,
        'rssi': (r['rssi'] as num?)?.toInt() ?? 0,
      };
    } catch (_) {
      return null;
    }
  }

  /// Raw network speed to the other phone in MB/s. Nothing is written to disk
  /// on either side, so this shows what the Wi-Fi link can really do.
  Future<double> networkTest({int seconds = 5}) async {
    final peer = pairedPeer.value;
    if (peer == null) throw StateError('Not connected.');
    final cfg = mode.value;
    final block = Uint8List(1024 * 1024);
    final clock = Stopwatch()..start();
    final end = DateTime.now().add(Duration(seconds: seconds));
    var bytes = 0;
    var connected = 0;
    Future<void> run() async {
      Socket? s;
      try {
        s = await _openSocket(peer, cfg);
        connected++;
        s.add(utf8.encode(
            '${jsonEncode({'token': peer.token, 'test': true, 'mode': cfg.wire})}\n'));
        while (DateTime.now().isBefore(end)) {
          s.add(block);
          await s.flush();
          bytes += block.length;
        }
        await s.close();
      } catch (_) {
      } finally {
        s?.destroy();
      }
    }

    await Future.wait([for (var i = 0; i < cfg.streams; i++) run()]);
    if (connected == 0) throw Exception('Could not reach the other phone.');
    return bytes / 1048576 / math.max(0.001, clock.elapsedMilliseconds / 1000.0);
  }

  /// How fast THIS phone can write to its storage in MB/s (64 MB, fsync'ed).
  Future<double> diskTest({int megabytes = 64}) async {
    final dir = await StorageService.instance.receiveDir();
    final f = File(p.join(dir.path, '.mafx_speedtest'));
    final raf = await f.open(mode: FileMode.write);
    final block = Uint8List(1024 * 1024);
    final clock = Stopwatch()..start();
    try {
      for (var i = 0; i < megabytes; i++) {
        raf.writeFromSync(block);
      }
      raf.flushSync();
    } finally {
      clock.stop();
      await raf.close();
      try {
        await f.delete();
      } catch (_) {}
    }
    return megabytes / math.max(0.001, clock.elapsedMilliseconds / 1000.0);
  }

  /// Back button on the home screen while connected: hide the app instead
  /// of closing it, so the connection stays.
  Future<void> moveToBack() => _call('moveToBack');

  /// Ends the session on purpose (the user pressed Disconnect).
  Future<void> endSession() async {
    linkNotice.value = null;
    await stopReceiver();
    await releaseNetwork();
  }

  /// Parses and validates the text found in a QR code.
  PairedPeer? parseQr(String raw) {
    try {
      final j = jsonDecode(raw);
      if (j is! Map) return null;
      if (j['app'] != 'MAFX_SHARE') return null;
      if (j['version'] is! int) return null;
      final ip = j['ip'];
      final port = j['port'];
      final tcp = j['tcpPort'];
      final token = j['token'];
      if (ip is! String || ip.isEmpty) return null;
      if (port is! int || tcp is! int) return null;
      if (token is! String || token.isEmpty) return null;
      scannedSsid = j['ssid'] is String ? j['ssid'] as String : null;
      scannedPassword = j['pass'] is String ? j['pass'] as String : null;
      return PairedPeer(
        ip: ip,
        port: port,
        tcpPort: tcp,
        token: token,
        mode: TransferMode.lower(
            TransferMode.parse(j['mode'] as String?), TransferMode.recommended),
      );
    } catch (_) {
      return null;
    }
  }
}
