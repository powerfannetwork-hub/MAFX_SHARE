import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;
import 'dart:typed_data';

import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:path/path.dart' as p;
import 'package:uuid/uuid.dart';

import '../models.dart';
import '../theme.dart';
import 'chunk_codec.dart';
import 'history_service.dart';
import 'storage_service.dart';

/// A file that is being received. Chunks can arrive in any order, on any
/// stream; [chunkDone] remembers which ones are already on disk.
class _Incoming {
  _Incoming(this.name, this.size, this.path, this.raf, this.chunkSize)
      : chunkCount = ChunkCodec.chunkCount(size, chunkSize),
        chunkDone = Uint8List(ChunkCodec.chunkCount(size, chunkSize));
  final String name;
  final int size;
  final String path;
  final RandomAccessFile raf;
  final int chunkSize;
  final int chunkCount;
  final Uint8List chunkDone;
  int chunksDone = 0;
  bool done = false;
}

class _Meter {
  final Stopwatch _sw = Stopwatch()..start();
  int _lastBytes = 0;
  int _lastMs = 0;
  double speed = 0;

  void update(int bytes) {
    final ms = _sw.elapsedMilliseconds;
    if (ms - _lastMs >= 400) {
      final inst = (bytes - _lastBytes) * 1000 / (ms - _lastMs);
      speed = speed == 0 ? inst : speed * 0.6 + inst * 0.4;
      _lastBytes = bytes;
      _lastMs = ms;
    }
  }
}

class _Job {
  const _Job(this.file, this.chunk);
  final int file;
  final int chunk;
}

/// Lets the UI (or sendFileTurbo's caller) stop a running transfer.
class TransferCancel {
  bool cancelled = false;
  void cancel() => cancelled = true;
}

/// Pairing, the HTTP control server and the TCP chunk streams.
///
/// BOTH phones run the same two servers (HTTP for pairing / metadata / ack and
/// TCP for chunk data), and after pairing both know the other phone's
/// endpoints. So either phone can send and receive at any time, without a new
/// QR scan, until the session is ended.
///
/// Host  = the phone that shows the QR code (it also creates the hotspot).
/// Guest = the phone that scans it.
class TransferService {
  TransferService._() {
    pairedPeer.addListener(_onPeerChanged);
    progress.addListener(_onProgressForNotification);
  }
  static final TransferService instance = TransferService._();

  static const Map<String, String> _jsonHeaders = {
    'Content-Type': 'application/json',
  };

  final ValueNotifier<TransferMode> mode =
      ValueNotifier<TransferMode>(TransferMode.standard);
  final ValueNotifier<PairedPeer?> pairedPeer = ValueNotifier<PairedPeer?>(null);
  final ValueNotifier<TransferProgress?> progress =
      ValueNotifier<TransferProgress?>(null);

  /// Goes up by one every time the other phone starts sending us files.
  final ValueNotifier<int> incomingStart = ValueNotifier<int>(0);

  /// 'host', 'guest' or null (not connected).
  String? role;
  String? localIp;
  int? httpPort;
  int? tcpPort;
  String? sessionToken;

  HttpServer? _http;
  ServerSocket? _tcp;
  PairedPeer? _pending;
  TransferCancel? _activeCancel;
  final Map<String, _Incoming> _incoming = {};

  String? _rxTid;
  int _rxTotal = 0;
  int _rxDone = 0;
  int _rxCount = 0;
  int _rxFinished = 0;
  String _rxName = '';
  int _rxLastPub = 0;
  _Meter _rxMeter = _Meter();

  bool get isConnected => pairedPeer.value != null;

  // ------------------------------------------------------------------ IP

  static const MethodChannel _sys = MethodChannel('com.mafx.share/apps');

  /// Hotspot details found in the last scanned QR code (sender side).
  String? scannedSsid;
  String? scannedPassword;

  /// SSID / password of the hotspot this phone created for the QR code.
  String? hotspotSsid;
  String? hotspotPassword;

  Future<String?> getLocalIp({bool preferHotspot = false}) =>
      _getLocalIp(preferHotspot: preferHotspot);

  Future<String?> _getLocalIp({bool preferHotspot = false}) async {
    try {
      final interfaces = await NetworkInterface.list(
          type: InternetAddressType.IPv4, includeLoopback: false);
      bool isPrivateIpv4(String ip) {
        final parts = ip.split('.');
        if (parts.length != 4) return false;
        final first = int.tryParse(parts[0]) ?? -1;
        final second = int.tryParse(parts[1]) ?? -1;
        return first == 10 ||
            (first == 172 && second >= 16 && second <= 31) ||
            (first == 192 && second == 168);
      }

      final candidates = <Map<String, dynamic>>[];
      for (final interface in interfaces) {
        final name = interface.name.toLowerCase();
        // Wi-Fi Direct (p2p-wlan0-0, 192.168.49.1) and mobile data are NOT a
        // network the other phone can reach. This was the "Network is
        // unreachable" bug.
        if (name.contains('p2p') ||
            name.contains('dummy') ||
            name.contains('rmnet') ||
            name.contains('ccmni') ||
            name.contains('tun') ||
            name.contains('veth') ||
            name == 'lo') {
          continue;
        }
        final isHotspotIf = name.startsWith('ap') ||
            name.startsWith('swlan') ||
            name.startsWith('softap') ||
            name == 'wlan1' ||
            name == 'wlan2';
        final isWlan0 = name == 'wlan0' || name.startsWith('wlan') || name.contains('wifi');
        for (final address in interface.addresses) {
          final ip = address.address;
          if (address.isLoopback ||
              ip.startsWith('169.254.') ||
              !isPrivateIpv4(ip)) {
            continue;
          }
          if (ip == '192.168.49.1') continue; // Wi-Fi Direct group owner
          int priority;
          if (preferHotspot) {
            priority = isHotspotIf ? 0 : (isWlan0 ? 1 : 2);
          } else {
            priority = isWlan0 && !isHotspotIf ? 0 : (isHotspotIf ? 1 : 2);
          }
          candidates.add({'ip': ip, 'interface': interface.name, 'priority': priority});
        }
      }
      candidates.sort((a, b) => (a['priority'] as int).compareTo(b['priority'] as int));
      if (candidates.isEmpty) return null;
      final selected = candidates.first;
      debugPrint('Selected IP: ${selected['ip']} from ${selected['interface']}');
      return selected['ip'] as String;
    } catch (e) {
      return null;
    }
  }

  Future<bool> _call(String method, [Map<String, dynamic>? args]) async {
    try {
      return (await _sys.invokeMethod<bool>(method, args)) ?? false;
    } catch (_) {
      return false;
    }
  }

  Future<bool> isWifiOn() => _call('isWifiOn');
  Future<bool> isBluetoothOn() => _call('isBluetoothOn');
  Future<bool> isHotspotOn() => _call('isHotspotOn');

  // ------------------------------------------------------- Host (QR shown)

  Future<void> startReceiver() async {
    await stopReceiver();
    String? ip;
    // 1) Create our own hotspot (like Xender). The other phone joins it by
    //    scanning the QR code - no router or manual hotspot needed.
    try {
      final r = await _sys.invokeMethod<Map>('startHotspot');
      if (r != null && (r['ssid'] as String?)?.isNotEmpty == true) {
        hotspotSsid = r['ssid'] as String;
        hotspotPassword = (r['password'] as String?) ?? '';
        for (var i = 0; i < 10 && ip == null; i++) {
          ip = await _getLocalIp(preferHotspot: true);
          if (ip == null) await Future.delayed(const Duration(milliseconds: 400));
        }
        if (ip == null) {
          await _call('stopHotspot');
          hotspotSsid = null;
          hotspotPassword = null;
        }
      }
    } catch (_) {
      hotspotSsid = null;
      hotspotPassword = null;
    }
    // 2) Fall back to the WiFi / hotspot the user already turned on.
    ip ??= await _getLocalIp();
    if (ip == null) {
      throw Exception(
          'No WiFi or hotspot network found. Turn on WiFi (and Location) and try again.');
    }
    localIp = ip;
    sessionToken = const Uuid().v4();
    await _startServers();
  }

  /// Starts the HTTP + TCP servers (used by the host AND by the guest).
  Future<void> _startServers() async {
    await _stopServers();
    final server = await HttpServer.bind(InternetAddress.anyIPv4, 0);
    final tcp = await ServerSocket.bind(InternetAddress.anyIPv4, 0);
    _http = server;
    _tcp = tcp;
    httpPort = server.port;
    tcpPort = tcp.port;
    server.listen((req) {
      _onRequest(req);
    });
    tcp.listen((socket) {
      _onSocket(socket);
    });
  }

  Future<void> _stopServers() async {
    for (final f in _incoming.values) {
      if (!f.done) {
        try {
          f.raf.closeSync();
        } catch (_) {}
      }
    }
    _incoming.clear();
    final server = _http;
    final tcp = _tcp;
    _http = null;
    _tcp = null;
    try {
      await server?.close(force: true);
    } catch (_) {}
    try {
      await tcp?.close();
    } catch (_) {}
    httpPort = null;
    tcpPort = null;
    _rxTid = null;
  }

  /// Ends everything on this phone (servers, hotspot, connection).
  Future<void> stopReceiver() async {
    _activeCancel?.cancel();
    await _stopServers();
    sessionToken = null;
    if (hotspotSsid != null) {
      hotspotSsid = null;
      hotspotPassword = null;
      await _call('stopHotspot');
    }
    disconnect();
  }

  /// Leave the other phone's hotspot (guest side).
  Future<void> releaseNetwork() => _call('releaseWifi');

  /// Forget the pairing (servers keep running until [stopReceiver]).
  void disconnect() {
    _pending = null;
    role = null;
    pairedPeer.value = null;
    progress.value = null;
  }

  /// JSON shown in the QR code.
  String qrPayload() => jsonEncode({
        'app': 'MAFX_SHARE',
        'version': 2,
        'ip': localIp,
        'port': httpPort,
        'tcpPort': tcpPort,
        'token': sessionToken,
        'mode': mode.value.wire,
        if (hotspotSsid != null) 'ssid': hotspotSsid,
        if (hotspotSsid != null) 'pass': hotspotPassword ?? '',
      });

  void _json(HttpRequest req, Map<String, dynamic> body, {int status = 200}) {
    req.response
      ..statusCode = status
      ..headers.contentType = ContentType.json
      ..write(jsonEncode(body));
    req.response.close();
  }

  Future<Map<String, dynamic>> _readJson(HttpRequest req) async {
    final text = await utf8.decoder.bind(req).join();
    final v = jsonDecode(text);
    return v is Map<String, dynamic> ? v : <String, dynamic>{};
  }

  Future<void> _onRequest(HttpRequest req) async {
    try {
      final path = req.uri.path;
      if (path == '/ping') {
        _json(req, {'ok': true, 'app': 'MAFX_SHARE'});
        return;
      }
      if (path == '/pair' && req.method == 'POST') {
        final body = await _readJson(req);
        if (body['token'] != sessionToken) {
          _json(req, {'ok': false, 'error': 'bad token'}, status: 403);
          return;
        }
        final m = TransferMode.parse(body['mode'] as String?);
        mode.value = m;
        final remote = req.connectionInfo?.remoteAddress.address ?? '';
        final reported = body['ip'];
        final peerIp =
            (reported is String && reported.isNotEmpty) ? reported : remote;
        role = 'host';
        pairedPeer.value = PairedPeer(
          ip: peerIp,
          port: (body['port'] as num?)?.toInt() ?? 0,
          tcpPort: (body['tcpPort'] as num?)?.toInt() ?? 0,
          token: sessionToken ?? '',
          mode: m,
        );
        _json(req, {'ok': true, 'tcpPort': tcpPort, 'mode': m.wire});
        return;
      }
      if (path == '/send-metadata' && req.method == 'POST') {
        final body = await _readJson(req);
        if (body['token'] != sessionToken) {
          _json(req, {'ok': false, 'error': 'bad token'}, status: 403);
          return;
        }
        await _prepareIncoming(body);
        _json(req, {'ok': true});
        return;
      }
      if (path == '/receive') {
        if (req.uri.queryParameters['token'] != sessionToken) {
          _json(req, {'ok': false, 'error': 'bad token'}, status: 403);
          return;
        }
        final id = req.uri.queryParameters['id'];
        final done = _rxTid != null &&
            _rxTid == id &&
            _rxCount > 0 &&
            _rxFinished >= _rxCount;
        // Chunks that never arrived, so the sender can send them again.
        final missing = <List<int>>[];
        if (!done && _rxTid == id) {
          for (final e in _incoming.entries) {
            if (!e.key.startsWith('$id:') || e.value.done) continue;
            final fileIndex = int.parse(e.key.split(':').last);
            final f = e.value;
            for (var c = 0; c < f.chunkCount && missing.length < 512; c++) {
              if (f.chunkDone[c] == 0) missing.add([fileIndex, c]);
            }
          }
        }
        _json(req, {
          'ok': true,
          'done': done,
          'received': _rxDone,
          'missing': missing,
        });
        return;
      }
      _json(req, {'ok': false, 'error': 'not found'}, status: 404);
    } catch (e) {
      debugPrint('HTTP error: $e');
      try {
        _json(req, {'ok': false, 'error': e.toString()}, status: 500);
      } catch (_) {}
    }
  }

  String _safeName(String name) {
    final n = p.basename(name).replaceAll(RegExp(r'[\\/:*?"<>|]'), '_');
    return n.isEmpty ? 'file' : n;
  }

  String _uniquePath(String dir, String name) {
    final first = p.join(dir, name);
    if (!File(first).existsSync()) return first;
    final base = p.basenameWithoutExtension(name);
    final ext = p.extension(name);
    var n = 1;
    while (File(p.join(dir, '$base ($n)$ext')).existsSync()) {
      n++;
    }
    return p.join(dir, '$base ($n)$ext');
  }

  /// Metadata arrives over HTTP (name, size, chunk size, mode). Every TCP
  /// stream then names the transfer + file in its first line, so nothing is
  /// assumed to be "already known" on a new socket.
  Future<void> _prepareIncoming(Map<String, dynamic> body) async {
    final tid = body['transferId'] as String;
    final files = (body['files'] as List).cast<Map>();
    final chunkSize =
        (body['chunkSize'] as num?)?.toInt() ?? TransferMode.standard.chunkSize;
    final dir = await StorageService.instance.receiveDir();

    for (final f in _incoming.values) {
      if (!f.done) {
        try {
          f.raf.closeSync();
        } catch (_) {}
      }
    }
    _incoming.clear();

    _rxTid = tid;
    _rxTotal = 0;
    _rxDone = 0;
    _rxCount = files.length;
    _rxFinished = 0;
    _rxName = '';
    _rxMeter = _Meter();

    for (var i = 0; i < files.length; i++) {
      final name = _safeName(files[i]['name'] as String);
      final size = (files[i]['size'] as num).toInt();
      final path = _uniquePath(dir.path, name);
      final raf = await File(path).open(mode: FileMode.write);
      if (size > 0) await raf.truncate(size);
      _incoming['$tid:$i'] = _Incoming(name, size, path, raf, chunkSize);
      _rxTotal += size;
    }
    for (final f in _incoming.values.toList()) {
      if (f.size == 0 && !f.done) await _completeFile(f);
    }
    _publishRx(force: true);
    incomingStart.value++;
  }

  Future<void> _completeFile(_Incoming f) async {
    f.done = true;
    try {
      f.raf.closeSync();
    } catch (_) {}
    _rxFinished++;
    await HistoryService.instance.add(
      name: f.name,
      size: f.size,
      type: 'received',
      path: f.path,
    );
    _publishRx(force: true);
  }

  void _publishRx({bool force = false}) {
    final now = DateTime.now().millisecondsSinceEpoch;
    if (!force && now - _rxLastPub < 120) return;
    _rxLastPub = now;
    final index = math.min(_rxFinished + 1, math.max(_rxCount, 1));
    progress.value = TransferProgress(
      direction: 'received',
      currentName: _rxName,
      fileIndex: index,
      fileCount: _rxCount,
      doneBytes: _rxDone,
      totalBytes: _rxTotal,
      speed: _rxMeter.speed,
      mode: mode.value,
      finished: _rxCount > 0 && _rxFinished >= _rxCount,
    );
  }

  void _tune(Socket s, TransferMode m) {
    try {
      s.setOption(SocketOption.tcpNoDelay, true);
    } catch (_) {}
    // Linux / Android: SOL_SOCKET = 1, SO_SNDBUF = 7, SO_RCVBUF = 8.
    // Android may clamp the value to its own limit; that is fine.
    try {
      s.setRawOption(RawSocketOption.fromInt(1, 7, m.socketBuffer));
    } catch (_) {}
    try {
      s.setRawOption(RawSocketOption.fromInt(1, 8, m.socketBuffer));
    } catch (_) {}
  }

  /// One TCP stream. Layout:
  ///   handshake line (JSON): {token, transferId, file, mode}\n
  ///   then any number of chunks: [u32 chunkIndex][u32 length][bytes]
  ///   optional end marker (index 0xFFFFFFFF) -> a new handshake line follows
  ///
  /// Bytes are collected in an app buffer and written to the file at
  /// chunkIndex * chunkSize. A chunk is only counted when ALL its bytes are on
  /// disk, so duplicates are ignored and half-received chunks are re-sent.
  Future<void> _onSocket(Socket socket) async {
    var m = mode.value;
    _tune(socket, m);

    final lineBuf = BytesBuilder(copy: false);
    final hdr = Uint8List(ChunkCodec.headerSize);
    var hdrLen = 0;
    var buf = Uint8List(m.bufferSize);
    var bufLen = 0;
    var bufPos = 0;
    var pos = 0;
    var remaining = 0;
    var chunkIndex = 0;
    var inChunk = false;
    var skipping = false;
    var chunkCounted = 0;
    _Incoming? file;

    void flush() {
      final f = file;
      if (f == null || bufLen == 0) {
        bufLen = 0;
        return;
      }
      f.raf.setPositionSync(bufPos);
      f.raf.writeFromSync(buf, 0, bufLen);
      _rxDone += bufLen;
      chunkCounted += bufLen;
      _rxName = f.name;
      _rxMeter.update(_rxDone);
      bufLen = 0;
      _publishRx();
    }

    void put(Uint8List data, int from, int count) {
      while (count > 0) {
        if (bufLen == 0) bufPos = pos;
        final n = math.min(buf.length - bufLen, count);
        buf.setRange(bufLen, bufLen + n, data, from);
        bufLen += n;
        from += n;
        count -= n;
        pos += n;
        if (bufLen == buf.length) flush();
      }
    }

    try {
      await for (final Uint8List data in socket) {
        var off = 0;
        while (off < data.length) {
          if (file == null) {
            // ---- handshake line
            final nl = data.indexOf(10, off);
            if (nl < 0) {
              lineBuf.add(Uint8List.sublistView(data, off));
              if (lineBuf.length > 4096) throw Exception('bad handshake');
              off = data.length;
              continue;
            }
            lineBuf.add(Uint8List.sublistView(data, off, nl));
            off = nl + 1;
            final h = jsonDecode(utf8.decode(lineBuf.takeBytes()))
                as Map<String, dynamic>;
            if (h['token'] != sessionToken) throw Exception('bad token');
            final found = _incoming['${h['transferId']}:${h['file']}'];
            if (found == null || found.done) throw Exception('unknown file');
            file = found;
            m = TransferMode.parse(h['mode'] as String?);
            if (buf.length != m.bufferSize) buf = Uint8List(m.bufferSize);
            bufLen = 0;
            hdrLen = 0;
            inChunk = false;
          } else if (!inChunk) {
            // ---- 8-byte chunk header (may be split over packets)
            final n = math.min(hdr.length - hdrLen, data.length - off);
            hdr.setRange(hdrLen, hdrLen + n, data, off);
            hdrLen += n;
            off += n;
            if (hdrLen < hdr.length) continue;
            hdrLen = 0;
            final idx = ChunkCodec.chunkIndexOf(hdr);
            final len = ChunkCodec.dataLengthOf(hdr);
            if (idx == ChunkCodec.endMarkerIndex) {
              file = null; // next: a new handshake line
              continue;
            }
            final f = file!;
            if (idx >= f.chunkCount ||
                len != ChunkCodec.lengthOf(idx, f.size, f.chunkSize)) {
              throw Exception('bad chunk');
            }
            chunkIndex = idx;
            skipping = f.chunkDone[idx] == 1; // duplicate: read and drop
            pos = ChunkCodec.offsetOf(idx, f.chunkSize);
            remaining = len;
            chunkCounted = 0;
            inChunk = true;
          } else {
            // ---- chunk data
            final take = math.min(data.length - off, remaining);
            if (!skipping) put(data, off, take);
            off += take;
            remaining -= take;
            if (remaining == 0) {
              inChunk = false;
              final f = file!;
              if (!skipping) {
                flush();
                if (f.chunkDone[chunkIndex] == 1) {
                  _rxDone -= chunkCounted; // another stream got it first
                } else {
                  f.chunkDone[chunkIndex] = 1;
                  f.chunksDone++;
                  if (f.chunksDone >= f.chunkCount && !f.done) {
                    await _completeFile(f);
                  }
                }
              }
              chunkCounted = 0;
            }
          }
        }
      }
    } catch (e) {
      debugPrint('Socket error: $e');
    } finally {
      try {
        if (inChunk && !skipping) {
          bufLen = 0; // half a chunk is useless; the sender will resend it
          _rxDone -= chunkCounted;
        }
      } catch (_) {}
      socket.destroy();
    }
  }

  // ----------------------------------------------------- Guest (QR scanned)

  Future<void> connectToReceiver(
    String receiverUrl,
    String token,
    TransferMode m, {
    int tcpPort = 0,
    String? ssid,
    String? password,
  }) async {
    disconnect();
    final uri = Uri.parse(receiverUrl);
    http.Response? res;
    Object? firstError;
    try {
      res = await http
          .get(Uri.parse('$receiverUrl/ping'))
          .timeout(const Duration(seconds: 4));
    } catch (e) {
      firstError = e;
    }
    // Not reachable on the current network: join the other phone's hotspot.
    if ((res == null || res.statusCode != 200) && ssid != null && ssid.isNotEmpty) {
      final joined =
          await _call('connectToWifi', {'ssid': ssid, 'password': password ?? ''});
      if (!joined) {
        throw Exception(
            'Could not join the other phone\'s hotspot. Allow the connection and try again.');
      }
      Object? err;
      for (var i = 0; i < 8; i++) {
        try {
          res = await http
              .get(Uri.parse('$receiverUrl/ping'))
              .timeout(const Duration(seconds: 3));
          if (res.statusCode == 200) break;
        } catch (e) {
          err = e;
        }
        await Future.delayed(const Duration(milliseconds: 800));
      }
      if (res == null || res.statusCode != 200) {
        throw Exception('The other phone did not answer. ${err ?? ''}');
      }
    } else if (res == null) {
      throw firstError!;
    }
    if (res.statusCode != 200) {
      throw Exception('The other phone did not answer.');
    }
    final j = jsonDecode(res.body);
    if (j is! Map || j['app'] != 'MAFX_SHARE') {
      throw Exception('This is not a MAFX SHARE phone.');
    }
    _pending = PairedPeer(
      ip: uri.host,
      port: uri.port,
      tcpPort: tcpPort,
      token: token,
      mode: m,
    );
    mode.value = m;
  }

  /// The guest starts its own servers and tells the host where they are, so
  /// the host can send files back (two-way transfer).
  Future<void> announcePairing() async {
    final peer = _pending;
    if (peer == null) throw StateError('Call connectToReceiver first.');
    localIp = await _getLocalIp();
    sessionToken = peer.token;
    await _startServers();
    final http.Response res;
    try {
      res = await http
          .post(
            Uri.parse('http://${peer.ip}:${peer.port}/pair'),
            headers: _jsonHeaders,
            body: jsonEncode({
              'token': peer.token,
              'mode': peer.mode.wire,
              'ip': localIp,
              'port': httpPort,
              'tcpPort': tcpPort,
            }),
          )
          .timeout(const Duration(seconds: 6));
    } catch (_) {
      await _stopServers();
      rethrow;
    }
    if (res.statusCode != 200) {
      await _stopServers();
      throw Exception('The other phone refused the connection.');
    }
    final j = jsonDecode(res.body) as Map<String, dynamic>;
    final tcp = (j['tcpPort'] as num?)?.toInt() ?? peer.tcpPort;
    role = 'guest';
    _pending = null;
    pairedPeer.value = PairedPeer(
      ip: peer.ip,
      port: peer.port,
      tcpPort: tcp,
      token: peer.token,
      mode: peer.mode,
    );
  }

  // ------------------------------------------------------------- Sending

  /// Sends files to the paired phone (works from the host AND the guest).
  Future<void> sendFiles(List<PendingFile> files, {TransferCancel? cancel}) {
    final peer = pairedPeer.value;
    if (peer == null) throw StateError('Not connected.');
    return _sendFilesTo(peer, files, mode.value, cancel: cancel);
  }

  /// Single-file API: streams [file] to the given receiver with the chosen
  /// mode ('standard' or '5g_plus'). [onProgress] gets bytes sent, total
  /// bytes and the measured speed in MB/s. Completes only after the receiver
  /// confirmed that the whole file is on its disk.
  Future<void> sendFileTurbo({
    required String receiverIp,
    required int receiverTcpPort,
    required File file,
    required String mode,
    required void Function(int sent, int total, double speedMBps) onProgress,
    TransferCancel? cancel,
  }) async {
    final cur = pairedPeer.value;
    if (cur == null) throw StateError('Not connected.');
    final m = TransferMode.parse(mode);
    final peer = PairedPeer(
      ip: receiverIp,
      port: cur.port,
      tcpPort: receiverTcpPort,
      token: cur.token,
      mode: m,
    );
    final size = await file.length();
    await _sendFilesTo(
      peer,
      [
        PendingFile(
          id: file.path,
          path: file.path,
          name: p.basename(file.path),
          size: size,
        ),
      ],
      m,
      cancel: cancel,
      onProgress: onProgress,
    );
  }

  void cancelTransfer() => _activeCancel?.cancel();

  Future<void> _sendFilesTo(
    PairedPeer peer,
    List<PendingFile> files,
    TransferMode cfg, {
    TransferCancel? cancel,
    void Function(int sent, int total, double speedMBps)? onProgress,
  }) async {
    final token = cancel ?? TransferCancel();
    _activeCancel = token;
    final tid = const Uuid().v4();
    final base = 'http://${peer.ip}:${peer.port}';
    final total = files.fold<int>(0, (s, f) => s + f.size);

    // Is the other phone still there?
    try {
      final r = await http
          .get(Uri.parse('$base/ping'))
          .timeout(const Duration(seconds: 4));
      if (r.statusCode != 200) throw Exception('no answer');
    } catch (_) {
      disconnect();
      throw Exception('Connection lost. Please connect the two phones again.');
    }

    final meta = await http
        .post(
          Uri.parse('$base/send-metadata'),
          headers: _jsonHeaders,
          body: jsonEncode({
            'token': peer.token,
            'transferId': tid,
            'mode': cfg.wire,
            'chunkSize': cfg.chunkSize,
            'files': [
              for (final f in files)
                {
                  'name': f.name,
                  'size': f.size,
                  'chunks': ChunkCodec.chunkCount(f.size, cfg.chunkSize),
                },
            ],
          }),
        )
        .timeout(const Duration(seconds: 15));
    if (meta.statusCode != 200) {
      throw Exception('The other phone could not accept the files.');
    }

    final jobs = <_Job>[];
    for (var i = 0; i < files.length; i++) {
      final n = ChunkCodec.chunkCount(files[i].size, cfg.chunkSize);
      for (var c = 0; c < n; c++) {
        jobs.add(_Job(i, c));
      }
    }

    final meter = _Meter();
    final fileSent = List<int>.filled(files.length, 0);
    final recorded = List<bool>.filled(files.length, false);
    var sent = 0;
    var lastPub = 0;

    int currentIndex() {
      for (var i = 0; i < files.length; i++) {
        if (!recorded[i]) return i;
      }
      return files.length - 1;
    }

    void record(int i) {
      if (recorded[i]) return;
      recorded[i] = true;
      HistoryService.instance
          .add(
            name: files[i].name,
            size: files[i].size,
            type: 'sent',
            path: files[i].path,
          )
          .catchError((_) {});
    }

    void publish({bool force = false, bool finished = false}) {
      final now = DateTime.now().millisecondsSinceEpoch;
      if (!force && now - lastPub < 100) return;
      lastPub = now;
      final idx = currentIndex();
      progress.value = TransferProgress(
        direction: 'sent',
        currentName: files[idx].name,
        fileIndex: idx + 1,
        fileCount: files.length,
        doneBytes: sent,
        totalBytes: total,
        speed: meter.speed,
        mode: cfg,
        finished: finished,
      );
      onProgress?.call(sent, total, meter.speed / 1048576);
    }

    for (var i = 0; i < files.length; i++) {
      if (files[i].size == 0) record(i);
    }
    publish(force: true);

    // A pool of TCP streams takes the next free chunk. Every stream stays
    // busy until the very end; the receiver puts chunks back by offset.
    Future<void> runJobs(List<_Job> list, {required bool count}) async {
      var next = 0;
      var failed = false;
      var connected = 0;
      var connectFails = 0;
      final workerCount = math.min(cfg.streams, list.length);

      Future<void> worker() async {
        Socket? socket;
        var bound = -1;
        final handles = <int, RandomAccessFile>{};
        try {
          while (!failed && next < list.length) {
            if (token.cancelled) throw Exception('Transfer cancelled.');
            final Socket sk;
            final existing = socket;
            if (existing != null) {
              sk = existing;
            } else {
              try {
                sk = await _openSocket(peer, cfg);
              } catch (_) {
                // This phone/network cannot take that many streams: carry on
                // with the streams that did connect.
                connectFails++;
                if (connected == 0 && connectFails >= workerCount) rethrow;
                return;
              }
              socket = sk;
              connected++;
            }
            if (next >= list.length) break;
            final job = list[next++];
            final f = files[job.file];
            if (bound != job.file) {
              if (bound >= 0) sk.add(ChunkCodec.endMarker());
              sk.add(utf8.encode('${jsonEncode({
                    'token': peer.token,
                    'transferId': tid,
                    'file': job.file,
                    'mode': cfg.wire,
                  })}\n'));
              bound = job.file;
            }
            var raf = handles[job.file];
            if (raf == null) {
              raf = await File(f.path).open();
              handles[job.file] = raf;
            }
            await _sendChunk(sk, raf, cfg, f.size, job.chunk, token, (n) {
              if (!count) return;
              sent += n;
              fileSent[job.file] += n;
              if (fileSent[job.file] >= f.size) record(job.file);
              meter.update(sent);
              publish();
            });
          }
          if (socket != null) {
            await socket.flush();
            await socket.close();
          }
        } catch (_) {
          failed = true;
          rethrow;
        } finally {
          for (final r in handles.values) {
            try {
              await r.close();
            } catch (_) {}
          }
          socket?.destroy();
        }
      }

      await Future.wait(
        [for (var w = 0; w < workerCount; w++) worker()],
        eagerError: true,
      );
    }

    await runJobs(jobs, count: true);

    // Wait for the receiver's acknowledgement. If chunks are missing, send
    // exactly those again (up to 3 rounds).
    var rounds = 0;
    var lastReceived = -1;
    var stalledSince = DateTime.now();
    while (true) {
      if (token.cancelled) throw Exception('Transfer cancelled.');
      Map<String, dynamic>? st;
      try {
        final res = await http
            .get(Uri.parse('$base/receive?id=$tid&token=${peer.token}'))
            .timeout(const Duration(seconds: 5));
        if (res.statusCode == 200) {
          final j = jsonDecode(res.body);
          if (j is Map<String, dynamic>) st = j;
        }
      } catch (_) {}
      if (st != null && st['done'] == true) break;
      final received = (st?['received'] as num?)?.toInt() ?? -1;
      if (received != lastReceived) {
        lastReceived = received;
        stalledSince = DateTime.now();
      }
      final stalled = DateTime.now().difference(stalledSince);
      final missing = (st?['missing'] as List?) ?? const [];
      if (stalled > const Duration(seconds: 2) &&
          missing.isNotEmpty &&
          rounds < 3) {
        rounds++;
        stalledSince = DateTime.now();
        await runJobs([
          for (final m in missing.cast<List>())
            _Job((m[0] as num).toInt(), (m[1] as num).toInt()),
        ], count: false);
        continue;
      }
      if (stalled > const Duration(seconds: 60)) {
        throw Exception('The other phone did not confirm the files.');
      }
      await Future.delayed(const Duration(milliseconds: 250));
    }
    publish(force: true, finished: true);
  }

  Future<Socket> _openSocket(PairedPeer peer, TransferMode m) async {
    final s = await Socket.connect(
      peer.ip,
      peer.tcpPort,
      timeout: const Duration(seconds: 10),
    );
    _tune(s, m);
    return s;
  }

  /// Sends one chunk. The next piece is read from disk while the previous
  /// piece is still going out on the network (read-ahead).
  Future<void> _sendChunk(
    Socket socket,
    RandomAccessFile raf,
    TransferMode m,
    int fileSize,
    int chunk,
    TransferCancel token,
    void Function(int bytes) onBytes,
  ) async {
    final length = ChunkCodec.lengthOf(chunk, fileSize, m.chunkSize);
    socket.add(ChunkCodec.encodeHeader(chunk, length));
    await raf.setPosition(ChunkCodec.offsetOf(chunk, m.chunkSize));
    var remaining = length;
    Future<Uint8List> pending = raf.read(math.min(m.bufferSize, remaining));
    while (remaining > 0) {
      if (token.cancelled) throw Exception('Transfer cancelled.');
      final bytes = await pending;
      if (bytes.isEmpty) throw Exception('The file changed while sending.');
      remaining -= bytes.length;
      if (remaining > 0) pending = raf.read(math.min(m.bufferSize, remaining));
      socket.add(bytes);
      await socket.flush();
      onBytes(bytes.length);
    }
  }

  // ------------------------------------------------- keep the link alive

  int _lastNotif = 0;
  Timer? _beatTimer;
  int _beatFails = 0;

  /// While two phones are connected a foreground service keeps the app, the
  /// CPU and the Wi-Fi alive, even when the user leaves the app.
  void _onPeerChanged() {
    _beatTimer?.cancel();
    _beatTimer = null;
    if (pairedPeer.value != null) {
      unawaited(_call('startKeepAlive', {'text': 'Connected - ready to transfer'}));
      _beatFails = 0;
      _beatTimer = Timer.periodic(const Duration(seconds: 8), (_) => _beat());
    } else {
      unawaited(_call('stopKeepAlive'));
    }
  }

  /// Notices when the other phone is really gone (not just busy).
  Future<void> _beat() async {
    final peer = pairedPeer.value;
    if (peer == null || peer.port == 0) return;
    final pr = progress.value;
    if (pr != null && !pr.finished) {
      _beatFails = 0; // data is moving, so it is alive
      return;
    }
    try {
      final r = await http
          .get(Uri.parse('http://${peer.ip}:${peer.port}/ping'))
          .timeout(const Duration(seconds: 5));
      if (r.statusCode == 200) {
        _beatFails = 0;
        return;
      }
    } catch (_) {}
    if (++_beatFails >= 4) {
      await stopReceiver();
      await releaseNetwork();
    }
  }

  void _onProgressForNotification() {
    final pr = progress.value;
    if (pr == null || pairedPeer.value == null) return;
    final now = DateTime.now().millisecondsSinceEpoch;
    if (!pr.finished && now - _lastNotif < 1500) return;
    _lastNotif = now;
    final pct = (pr.fraction * 100).round();
    final text = pr.finished
        ? 'Transfer complete'
        : '${pr.direction == 'sent' ? 'Sending' : 'Receiving'} $pct% - ${formatSpeed(pr.speed)}';
    unawaited(_call('updateKeepAlive', {'text': text}));
  }

  /// Back button on the home screen while connected: hide the app instead
  /// of closing it, so the connection stays.
  Future<void> moveToBack() => _call('moveToBack');

  /// Ends the session on purpose (the user pressed Disconnect).
  Future<void> endSession() async {
    await stopReceiver();
    await releaseNetwork();
  }

  /// Parses and validates the text found in a QR code.
  PairedPeer? parseQr(String raw) {
    try {
      final j = jsonDecode(raw);
      if (j is! Map) return null;
      if (j['app'] != 'MAFX_SHARE') return null;
      if (j['version'] is! int) return null;
      final ip = j['ip'];
      final port = j['port'];
      final tcp = j['tcpPort'];
      final token = j['token'];
      if (ip is! String || ip.isEmpty) return null;
      if (port is! int || tcp is! int) return null;
      if (token is! String || token.isEmpty) return null;
      scannedSsid = j['ssid'] is String ? j['ssid'] as String : null;
      scannedPassword = j['pass'] is String ? j['pass'] as String : null;
      return PairedPeer(
        ip: ip,
        port: port,
        tcpPort: tcp,
        token: token,
        mode: TransferMode.parse(j['mode'] as String?),
      );
    } catch (_) {
      return null;
    }
  }
}
