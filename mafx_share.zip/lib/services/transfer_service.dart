import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;
import 'dart:typed_data';

import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:path/path.dart' as p;
import 'package:uuid/uuid.dart';

import '../models.dart';
import 'history_service.dart';
import 'storage_service.dart';

class _Incoming {
  _Incoming(this.name, this.size, this.path, this.raf);
  final String name;
  final int size;
  final String path;
  final RandomAccessFile raf;
  int received = 0;
  bool done = false;
}

class _Meter {
  final Stopwatch _sw = Stopwatch()..start();
  int _lastBytes = 0;
  int _lastMs = 0;
  double speed = 0;

  void update(int bytes) {
    final ms = _sw.elapsedMilliseconds;
    if (ms - _lastMs >= 400) {
      final inst = (bytes - _lastBytes) * 1000 / (ms - _lastMs);
      speed = speed == 0 ? inst : speed * 0.6 + inst * 0.4;
      _lastBytes = bytes;
      _lastMs = ms;
    }
  }
}

/// Handles pairing, the HTTP control server and the TCP file streams.
///
/// Receiver: startReceiver() -> HttpServer + ServerSocket on random ports.
/// Sender:   connectToReceiver() -> announcePairing() -> sendFiles().
class TransferService {
  TransferService._();
  static final TransferService instance = TransferService._();

  static const int _bufferSize = 64 * 1024;
  static const Map<String, String> _jsonHeaders = {
    'Content-Type': 'application/json',
  };

  final ValueNotifier<TransferMode> mode =
      ValueNotifier<TransferMode>(TransferMode.standard);
  final ValueNotifier<PairedPeer?> pairedPeer = ValueNotifier<PairedPeer?>(null);
  final ValueNotifier<TransferProgress?> progress =
      ValueNotifier<TransferProgress?>(null);

  /// 'sender', 'receiver' or null.
  String? role;
  String? localIp;
  int? httpPort;
  int? tcpPort;
  String? sessionToken;

  HttpServer? _http;
  ServerSocket? _tcp;
  PairedPeer? _pending;
  final Map<String, _Incoming> _incoming = {};

  String? _rxTid;
  int _rxTotal = 0;
  int _rxDone = 0;
  int _rxCount = 0;
  int _rxFinished = 0;
  String _rxName = '';
  int _rxLastPub = 0;
  _Meter _rxMeter = _Meter();

  bool get isConnected => pairedPeer.value != null;

  // ------------------------------------------------------------------ IP

  Future<String?> getLocalIp() => _getLocalIp();

  Future<String?> _getLocalIp() async {
    try {
      final interfaces = await NetworkInterface.list(type: InternetAddressType.IPv4, includeLoopback: false);
      final candidates = <Map<String, dynamic>>[];
      bool isPrivateIpv4(String ip) {
        final parts = ip.split('.');
        if (parts.length != 4) return false;
        final first = int.tryParse(parts[0]) ?? -1;
        final second = int.tryParse(parts[1]) ?? -1;
        return first == 10 || (first == 172 && second >= 16 && second <= 31) || (first == 192 && second == 168);
      }
      for (final interface in interfaces) {
        final name = interface.name.toLowerCase();
        final isWifi = name.contains('wlan') || name.contains('wifi') || name.contains('swlan') || name.contains('ap');
        for (final address in interface.addresses) {
          final ip = address.address;
          if (address.isLoopback || address.type != InternetAddressType.IPv4 || ip.startsWith('169.254.') || !isPrivateIpv4(ip)) continue;
          final is192 = ip.startsWith('192.168.');
          final priority = isWifi ? (is192 ? 0 : 1) : (is192 ? 2 : 3);
          candidates.add({'ip': ip, 'interface': interface.name, 'priority': priority});
        }
      }
      candidates.sort((a, b) => (a['priority'] as int).compareTo(b['priority'] as int));
      if (candidates.isEmpty) return null;
      final selected = candidates.first;
      debugPrint('Selected IP: ${selected['ip']} from ${selected['interface']}');
      return selected['ip'] as String;
    } catch (e) { return null; }
  }

  // ------------------------------------------------------------ Receiver

  Future<void> startReceiver() async {
    await stopReceiver();
    disconnect();
    final ip = await _getLocalIp();
    if (ip == null) {
      throw Exception(
          'No WiFi or hotspot network found. Turn on WiFi or Hotspot first.');
    }
    localIp = ip;
    sessionToken = const Uuid().v4();
    final server = await HttpServer.bind(InternetAddress.anyIPv4, 0);
    final tcp = await ServerSocket.bind(InternetAddress.anyIPv4, 0);
    _http = server;
    _tcp = tcp;
    httpPort = server.port;
    tcpPort = tcp.port;
    server.listen((req) {
      _onRequest(req);
    });
    tcp.listen((socket) {
      _onSocket(socket);
    });
  }

  Future<void> stopReceiver() async {
    for (final f in _incoming.values) {
      if (!f.done) {
        try {
          f.raf.closeSync();
        } catch (_) {}
      }
    }
    _incoming.clear();
    final server = _http;
    final tcp = _tcp;
    _http = null;
    _tcp = null;
    try {
      await server?.close(force: true);
    } catch (_) {}
    try {
      await tcp?.close();
    } catch (_) {}
    httpPort = null;
    tcpPort = null;
    sessionToken = null;
    _rxTid = null;
    if (role == 'receiver') disconnect();
  }

  void disconnect() {
    _pending = null;
    role = null;
    pairedPeer.value = null;
    progress.value = null;
  }

  /// JSON shown in the QR code.
  String qrPayload() => jsonEncode({
        'app': 'MAFX_SHARE',
        'version': 1,
        'ip': localIp,
        'port': httpPort,
        'tcpPort': tcpPort,
        'token': sessionToken,
        'mode': mode.value.wire,
      });

  void _json(HttpRequest req, Map<String, dynamic> body, {int status = 200}) {
    req.response
      ..statusCode = status
      ..headers.contentType = ContentType.json
      ..write(jsonEncode(body));
    req.response.close();
  }

  Future<Map<String, dynamic>> _readJson(HttpRequest req) async {
    final text = await utf8.decoder.bind(req).join();
    final v = jsonDecode(text);
    return v is Map<String, dynamic> ? v : <String, dynamic>{};
  }

  Future<void> _onRequest(HttpRequest req) async {
    try {
      final path = req.uri.path;
      if (path == '/ping') {
        _json(req, {'ok': true, 'app': 'MAFX_SHARE'});
        return;
      }
      if (path == '/pair' && req.method == 'POST') {
        final body = await _readJson(req);
        if (body['token'] != sessionToken) {
          _json(req, {'ok': false, 'error': 'bad token'}, status: 403);
          return;
        }
        final m = TransferMode.parse(body['mode'] as String?);
        mode.value = m;
        role = 'receiver';
        pairedPeer.value = PairedPeer(
          ip: req.connectionInfo?.remoteAddress.address ?? '',
          port: httpPort ?? 0,
          tcpPort: tcpPort ?? 0,
          token: sessionToken ?? '',
          mode: m,
        );
        _json(req, {'ok': true, 'tcpPort': tcpPort, 'mode': m.wire});
        return;
      }
      if (path == '/send-metadata' && req.method == 'POST') {
        final body = await _readJson(req);
        if (body['token'] != sessionToken) {
          _json(req, {'ok': false, 'error': 'bad token'}, status: 403);
          return;
        }
        await _prepareIncoming(body);
        _json(req, {'ok': true});
        return;
      }
      if (path == '/receive') {
        if (req.uri.queryParameters['token'] != sessionToken) {
          _json(req, {'ok': false, 'error': 'bad token'}, status: 403);
          return;
        }
        final done = _rxTid != null &&
            _rxTid == req.uri.queryParameters['id'] &&
            _rxCount > 0 &&
            _rxFinished >= _rxCount;
        _json(req, {'ok': true, 'done': done, 'received': _rxDone});
        return;
      }
      _json(req, {'ok': false, 'error': 'not found'}, status: 404);
    } catch (e) {
      debugPrint('HTTP error: $e');
      try {
        _json(req, {'ok': false, 'error': e.toString()}, status: 500);
      } catch (_) {}
    }
  }

  String _safeName(String name) {
    final n = p.basename(name).replaceAll(RegExp(r'[\\/:*?"<>|]'), '_');
    return n.isEmpty ? 'file' : n;
  }

  String _uniquePath(String dir, String name) {
    final first = p.join(dir, name);
    if (!File(first).existsSync()) return first;
    final base = p.basenameWithoutExtension(name);
    final ext = p.extension(name);
    var n = 1;
    while (File(p.join(dir, '$base ($n)$ext')).existsSync()) {
      n++;
    }
    return p.join(dir, '$base ($n)$ext');
  }

  Future<void> _prepareIncoming(Map<String, dynamic> body) async {
    final tid = body['transferId'] as String;
    final files = (body['files'] as List).cast<Map>();
    final dir = await StorageService.instance.receiveDir();

    _rxTid = tid;
    _rxTotal = 0;
    _rxDone = 0;
    _rxCount = files.length;
    _rxFinished = 0;
    _rxName = '';
    _rxMeter = _Meter();

    for (var i = 0; i < files.length; i++) {
      final name = _safeName(files[i]['name'] as String);
      final size = (files[i]['size'] as num).toInt();
      final path = _uniquePath(dir.path, name);
      final raf = await File(path).open(mode: FileMode.write);
      if (size > 0) await raf.truncate(size);
      final incoming = _Incoming(name, size, path, raf);
      _incoming['$tid:$i'] = incoming;
      _rxTotal += size;
    }
    for (final f in _incoming.values.toList()) {
      if (f.size == 0 && !f.done) await _completeFile(f);
    }
    _publishRx(force: true);
  }

  Future<void> _completeFile(_Incoming f) async {
    f.done = true;
    try {
      f.raf.closeSync();
    } catch (_) {}
    _rxFinished++;
    await HistoryService.instance.add(
      name: f.name,
      size: f.size,
      type: 'received',
      path: f.path,
    );
    _publishRx(force: true);
  }

  void _publishRx({bool force = false}) {
    final now = DateTime.now().millisecondsSinceEpoch;
    if (!force && now - _rxLastPub < 120) return;
    _rxLastPub = now;
    final index = math.min(_rxFinished + 1, math.max(_rxCount, 1));
    progress.value = TransferProgress(
      direction: 'received',
      currentName: _rxName,
      fileIndex: index,
      fileCount: _rxCount,
      doneBytes: _rxDone,
      totalBytes: _rxTotal,
      speed: _rxMeter.speed,
      mode: mode.value,
      finished: _rxCount > 0 && _rxFinished >= _rxCount,
    );
  }

  /// Receives raw file bytes. First line = JSON header, then the bytes.
  Future<void> _onSocket(Socket socket) async {
    try {
      socket.setOption(SocketOption.tcpNoDelay, true);
    } catch (_) {}
    final headerBuf = BytesBuilder(copy: false);
    _Incoming? file;
    var pos = 0;
    var remaining = 0;
    try {
      await for (final chunk in socket) {
        var data = chunk;
        if (file == null) {
          final nl = data.indexOf(10);
          if (nl < 0) {
            headerBuf.add(data);
            if (headerBuf.length > 4096) throw Exception('bad header');
            continue;
          }
          headerBuf.add(Uint8List.sublistView(data, 0, nl));
          data = Uint8List.sublistView(data, nl + 1);
          final h = jsonDecode(utf8.decode(headerBuf.takeBytes()))
              as Map<String, dynamic>;
          if (h['token'] != sessionToken) throw Exception('bad token');
          final found = _incoming['${h['transferId']}:${h['index']}'];
          if (found == null || found.done) throw Exception('unknown file');
          file = found;
          pos = (h['offset'] as num).toInt();
          remaining = (h['length'] as num).toInt();
        }
        final f = file;
        if (data.isEmpty) continue;
        final take = math.min(data.length, remaining);
        if (take <= 0) continue;
        f.raf.setPositionSync(pos);
        f.raf.writeFromSync(data, 0, take);
        pos += take;
        remaining -= take;
        f.received += take;
        _rxDone += take;
        _rxName = f.name;
        _rxMeter.update(_rxDone);
        _publishRx();
        if (f.received >= f.size && !f.done) {
          await _completeFile(f);
        }
      }
    } catch (e) {
      debugPrint('Socket error: $e');
    } finally {
      socket.destroy();
    }
  }

  // -------------------------------------------------------------- Sender

  Future<void> connectToReceiver(
    String receiverUrl,
    String token,
    TransferMode m, {
    int tcpPort = 0,
  }) async {
    disconnect();
    final uri = Uri.parse(receiverUrl);
    final res = await http
        .get(Uri.parse('$receiverUrl/ping'))
        .timeout(const Duration(seconds: 6));
    if (res.statusCode != 200) {
      throw Exception('The other phone did not answer.');
    }
    final j = jsonDecode(res.body);
    if (j is! Map || j['app'] != 'MAFX_SHARE') {
      throw Exception('This is not a MAFX SHARE phone.');
    }
    _pending = PairedPeer(
      ip: uri.host,
      port: uri.port,
      tcpPort: tcpPort,
      token: token,
      mode: m,
    );
    mode.value = m;
  }

  Future<void> announcePairing() async {
    final peer = _pending;
    if (peer == null) throw StateError('Call connectToReceiver first.');
    final res = await http
        .post(
          Uri.parse('http://${peer.ip}:${peer.port}/pair'),
          headers: _jsonHeaders,
          body: jsonEncode({'token': peer.token, 'mode': peer.mode.wire}),
        )
        .timeout(const Duration(seconds: 6));
    if (res.statusCode != 200) {
      throw Exception('The other phone refused the connection.');
    }
    final j = jsonDecode(res.body) as Map<String, dynamic>;
    final tcp = (j['tcpPort'] as num?)?.toInt() ?? peer.tcpPort;
    role = 'sender';
    _pending = null;
    pairedPeer.value = PairedPeer(
      ip: peer.ip,
      port: peer.port,
      tcpPort: tcp,
      token: peer.token,
      mode: peer.mode,
    );
  }

  Future<void> sendFiles(List<PendingFile> files) async {
    final peer = pairedPeer.value;
    if (peer == null) throw StateError('Not connected.');
    final cfg = mode.value;
    final tid = const Uuid().v4();
    final base = 'http://${peer.ip}:${peer.port}';
    final total = files.fold<int>(0, (s, f) => s + f.size);

    final meta = await http
        .post(
          Uri.parse('$base/send-metadata'),
          headers: _jsonHeaders,
          body: jsonEncode({
            'token': peer.token,
            'transferId': tid,
            'files': [
              for (final f in files) {'name': f.name, 'size': f.size},
            ],
          }),
        )
        .timeout(const Duration(seconds: 15));
    if (meta.statusCode != 200) {
      throw Exception('The other phone could not accept the files.');
    }

    final meter = _Meter();
    var sent = 0;
    var currentIndex = 0;
    var lastPub = 0;

    void publish({bool force = false, bool finished = false}) {
      final now = DateTime.now().millisecondsSinceEpoch;
      if (!force && now - lastPub < 100) return;
      lastPub = now;
      progress.value = TransferProgress(
        direction: 'sent',
        currentName: files[currentIndex].name,
        fileIndex: currentIndex + 1,
        fileCount: files.length,
        doneBytes: sent,
        totalBytes: total,
        speed: meter.speed,
        mode: cfg,
        finished: finished,
      );
    }

    publish(force: true);

    for (var i = 0; i < files.length; i++) {
      currentIndex = i;
      final f = files[i];
      publish(force: true);
      if (f.size > 0) {
        final streams = f.size <= cfg.chunkSize
            ? 1
            : math.min(cfg.streams, (f.size / cfg.chunkSize).ceil());
        final part = (f.size / streams).ceil();
        final jobs = <Future<void>>[];
        for (var s = 0; s < streams; s++) {
          final start = s * part;
          final end = math.min(f.size, start + part);
          if (start >= end) continue;
          jobs.add(_sendRange(
            peer: peer,
            file: File(f.path),
            transferId: tid,
            index: i,
            start: start,
            end: end,
            chunkSize: cfg.chunkSize,
            onBytes: (n) {
              sent += n;
              meter.update(sent);
              publish();
            },
          ));
        }
        await Future.wait(jobs, eagerError: true);
      }
      await HistoryService.instance.add(
        name: f.name,
        size: f.size,
        type: 'sent',
        path: f.path,
      );
    }

    await _waitReceiverDone(base, peer.token, tid);
    publish(force: true, finished: true);
  }

  Future<void> _sendRange({
    required PairedPeer peer,
    required File file,
    required String transferId,
    required int index,
    required int start,
    required int end,
    required int chunkSize,
    required void Function(int bytes) onBytes,
  }) async {
    final socket = await Socket.connect(
      peer.ip,
      peer.tcpPort,
      timeout: const Duration(seconds: 10),
    );
    try {
      socket.setOption(SocketOption.tcpNoDelay, true);
    } catch (_) {}
    final header = jsonEncode({
      'token': peer.token,
      'transferId': transferId,
      'index': index,
      'offset': start,
      'length': end - start,
    });
    socket.add(utf8.encode('$header\n'));

    final raf = await file.open();
    try {
      await raf.setPosition(start);
      var remaining = end - start;
      while (remaining > 0) {
        final bytes = await raf.read(math.min(chunkSize, remaining));
        if (bytes.isEmpty) break;
        for (var o = 0; o < bytes.length; o += _bufferSize) {
          final e = math.min(o + _bufferSize, bytes.length);
          socket.add(Uint8List.sublistView(bytes, o, e));
        }
        await socket.flush();
        remaining -= bytes.length;
        onBytes(bytes.length);
      }
    } finally {
      await raf.close();
    }
    await socket.flush();
    await socket.close();
  }

  Future<void> _waitReceiverDone(String base, String token, String tid) async {
    final deadline = DateTime.now().add(const Duration(seconds: 60));
    while (DateTime.now().isBefore(deadline)) {
      try {
        final res = await http
            .get(Uri.parse('$base/receive?id=$tid&token=$token'))
            .timeout(const Duration(seconds: 5));
        if (res.statusCode == 200) {
          final j = jsonDecode(res.body);
          if (j is Map && j['done'] == true) return;
        }
      } catch (_) {}
      await Future.delayed(const Duration(milliseconds: 300));
    }
  }

  /// Parses and validates the text found in a QR code.
  PairedPeer? parseQr(String raw) {
    try {
      final j = jsonDecode(raw);
      if (j is! Map) return null;
      if (j['app'] != 'MAFX_SHARE') return null;
      if (j['version'] is! int) return null;
      final ip = j['ip'];
      final port = j['port'];
      final tcp = j['tcpPort'];
      final token = j['token'];
      if (ip is! String || ip.isEmpty) return null;
      if (port is! int || tcp is! int) return null;
      if (token is! String || token.isEmpty) return null;
      return PairedPeer(
        ip: ip,
        port: port,
        tcpPort: tcp,
        token: token,
        mode: TransferMode.parse(j['mode'] as String?),
      );
    } catch (_) {
      return null;
    }
  }
}
