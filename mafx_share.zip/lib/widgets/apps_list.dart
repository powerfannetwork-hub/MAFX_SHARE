import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../theme.dart';

const MethodChannel _channel = MethodChannel('com.mafx.share/apps');

class _AppItem {
  const _AppItem(this.name, this.pkg, this.icon);
  final String name;
  final String pkg;
  final Uint8List? icon;
}

/// Lists the apps on the phone. Tap an app to Open or Delete (uninstall) it.
class AppsList extends StatefulWidget {
  const AppsList({super.key, this.query = ''});
  final String query;

  @override
  State<AppsList> createState() => _AppsListState();
}

class _AppsListState extends State<AppsList> {
  List<_AppItem> _apps = [];
  bool _loading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final raw = await _channel.invokeMethod<List<dynamic>>('listApps');
      final items = <_AppItem>[];
      for (final e in raw ?? <dynamic>[]) {
        final m = e as Map;
        items.add(_AppItem(
          (m['name'] ?? '').toString(),
          (m['package'] ?? '').toString(),
          m['icon'] as Uint8List?,
        ));
      }
      if (!mounted) return;
      setState(() {
        _apps = items;
        _loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _loading = false;
        _error = 'Could not list apps: $e';
      });
    }
  }

  void _actions(_AppItem app) {
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: kPanel,
      builder: (ctx) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(title: Text(app.name), subtitle: Text(app.pkg)),
            ListTile(
              leading: const Icon(Icons.open_in_new),
              title: const Text('Open'),
              onTap: () async {
                Navigator.pop(ctx);
                await _channel.invokeMethod<bool>('openApp', {'package': app.pkg});
              },
            ),
            ListTile(
              leading: const Icon(Icons.delete_outline, color: Colors.redAccent),
              title: const Text('Delete (uninstall)'),
              onTap: () async {
                Navigator.pop(ctx);
                await _channel.invokeMethod<bool>('uninstallApp', {'package': app.pkg});
                await Future.delayed(const Duration(seconds: 3));
                if (mounted) _load();
              },
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) return const Center(child: CircularProgressIndicator());
    if (_error != null) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(_error!, textAlign: TextAlign.center),
              const SizedBox(height: 12),
              FilledButton(onPressed: _load, child: const Text('Try again')),
            ],
          ),
        ),
      );
    }
    final q = widget.query.trim().toLowerCase();
    final apps = q.isEmpty
        ? _apps
        : _apps.where((a) => a.name.toLowerCase().contains(q) || a.pkg.toLowerCase().contains(q)).toList();
    if (apps.isEmpty) return const Center(child: Text('No apps found.'));
    return RefreshIndicator(
      onRefresh: _load,
      child: ListView.builder(
        itemCount: apps.length,
        itemBuilder: (context, i) {
          final app = apps[i];
          final icon = app.icon;
          return ListTile(
            leading: icon != null
                ? Image.memory(icon, width: 42, height: 42)
                : const Icon(Icons.android, size: 42),
            title: Text(app.name),
            subtitle: Text(app.pkg),
            onTap: () => _actions(app),
          );
        },
      ),
    );
  }
}
