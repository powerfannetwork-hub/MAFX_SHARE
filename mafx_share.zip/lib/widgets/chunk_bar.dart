import 'dart:typed_data';

import 'package:flutter/material.dart';

import '../theme.dart';

/// Progress bar cut into pieces, one piece per chunk of the file:
/// green = arrived, blue = on its way, dark = waiting. Without chunk data
/// it is a normal bar. Files with many chunks are grouped into at most
/// about one piece per 6 pixels.
class ChunkBar extends StatelessWidget {
  const ChunkBar({super.key, this.chunks, required this.fraction, this.height = 12});

  final Uint8List? chunks;
  final double fraction;
  final double height;

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(height / 2.5),
      child: SizedBox(
        height: height,
        width: double.infinity,
        child: CustomPaint(painter: _ChunkPainter(chunks, fraction)),
      ),
    );
  }
}

class _ChunkPainter extends CustomPainter {
  _ChunkPainter(this.chunks, this.fraction);

  final Uint8List? chunks;
  final double fraction;

  @override
  void paint(Canvas canvas, Size size) {
    final back = Paint()..color = kBg;
    canvas.drawRect(Offset.zero & size, back);
    final c = chunks;
    if (c == null || c.isEmpty) {
      canvas.drawRect(
        Rect.fromLTWH(0, 0, size.width * fraction.clamp(0.0, 1.0), size.height),
        Paint()..color = kGreen,
      );
      return;
    }
    final n = c.length;
    final cells = n <= 80 ? n : (size.width / 6).floor().clamp(20, n);
    final gap = cells > 100 ? 1.0 : 2.0;
    final w = size.width / cells;
    final done = Paint()..color = kGreen;
    final flying = Paint()..color = kBlue;
    final half = Paint()..color = alpha(kGreen, 0.45);
    final wait = Paint()..color = alpha(Colors.white, 0.10);
    for (var i = 0; i < cells; i++) {
      final from = (i * n / cells).floor();
      final to = (((i + 1) * n / cells).ceil()).clamp(from + 1, n).toInt();
      var d = 0;
      var f = 0;
      for (var k = from; k < to; k++) {
        if (c[k] == 1) {
          d++;
        } else if (c[k] == 2) {
          f++;
        }
      }
      final total = to - from;
      final Paint p;
      if (d == total) {
        p = done;
      } else if (f > 0) {
        p = flying;
      } else if (d > 0) {
        p = half;
      } else {
        p = wait;
      }
      canvas.drawRect(Rect.fromLTWH(i * w, 0, (w - gap).clamp(1.0, w), size.height), p);
    }
  }

  @override
  bool shouldRepaint(covariant _ChunkPainter old) =>
      !identical(old.chunks, chunks) || old.fraction != fraction;
}
