import 'dart:io';

import 'package:flutter/material.dart';
import 'package:path/path.dart' as p;

import '../media/media_entry.dart';
import '../models.dart';
import '../theme.dart';
import 'media_thumb.dart';

/// File manager for the whole storage (needs "all files access").
/// Folders first, tap a folder to enter it, tap a file to open it, tick the
/// box (or long-press) to select it for sending / sharing / deleting.
class FileBrowserView extends StatefulWidget {
  const FileBrowserView({
    super.key,
    required this.query,
    required this.sort,
    required this.selected,
    required this.onToggle,
    required this.onOpen,
  });

  final String query;
  final SortMode sort;
  final bool Function(MediaEntry) selected;
  final void Function(MediaEntry) onToggle;
  final void Function(MediaEntry) onOpen;

  @override
  State<FileBrowserView> createState() => _FileBrowserViewState();
}

class _Item {
  _Item(this.path, this.name, this.isDir, this.size, this.date);
  final String path;
  final String name;
  final bool isDir;
  final int size;
  final DateTime date;
}

const _root = '/storage/emulated/0';

class _FileBrowserViewState extends State<FileBrowserView> {
  String _dir = _root;
  List<_Item> _items = [];
  bool _loading = true;
  String? _error;

  static const _img = {'.jpg', '.jpeg', '.png', '.gif', '.webp', '.bmp', '.heic'};
  static const _vid = {'.mp4', '.mkv', '.3gp', '.webm', '.mov', '.avi', '.m4v', '.ts', '.flv'};
  static const _aud = {'.mp3', '.m4a', '.aac', '.wav', '.ogg', '.flac', '.opus', '.amr'};

  @override
  void initState() {
    super.initState();
    _load(_dir);
  }

  Future<void> _load(String dir) async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final out = <_Item>[];
      await for (final e in Directory(dir).list(followLinks: false)) {
        final name = p.basename(e.path);
        if (name.startsWith('.')) continue;
        try {
          final st = await e.stat();
          out.add(_Item(
            e.path,
            name,
            st.type == FileSystemEntityType.directory,
            st.type == FileSystemEntityType.directory ? 0 : st.size,
            st.modified,
          ));
        } catch (_) {}
      }
      if (!mounted) return;
      setState(() {
        _dir = dir;
        _items = out;
        _loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _loading = false;
        _error = 'Cannot open this folder. Is "all files access" on?';
      });
    }
  }

  MediaEntry _entry(_Item i) {
    final ext = p.extension(i.name).toLowerCase();
    final base = MediaEntry.picked(i.path, i.name, i.size);
    final kind = _img.contains(ext)
        ? EntryKind.photo
        : _vid.contains(ext)
            ? EntryKind.video
            : _aud.contains(ext)
                ? EntryKind.audio
                : EntryKind.file;
    return MediaEntry(
      id: i.path,
      kind: kind,
      uri: '',
      path: i.path,
      name: i.name,
      size: i.size,
      dateMs: i.date.millisecondsSinceEpoch,
      mime: base.mime,
    );
  }

  List<_Item> _visible() {
    final q = widget.query.trim().toLowerCase();
    final list = q.isEmpty ? _items.toList() : _items.where((e) => e.name.toLowerCase().contains(q)).toList();
    int by(_Item a, _Item b) {
      switch (widget.sort) {
        case SortMode.newest:
          return b.date.compareTo(a.date);
        case SortMode.oldest:
          return a.date.compareTo(b.date);
        case SortMode.nameDesc:
          return b.name.toLowerCase().compareTo(a.name.toLowerCase());
        case SortMode.largest:
          return b.size.compareTo(a.size);
        case SortMode.smallest:
          return a.size.compareTo(b.size);
        default:
          return a.name.toLowerCase().compareTo(b.name.toLowerCase());
      }
    }

    list.sort((a, b) {
      if (a.isDir != b.isDir) return a.isDir ? -1 : 1;
      return by(a, b);
    });
    return list;
  }

  bool get _atTop => _dir == '/storage' || _dir == '/';

  void _up() {
    if (_atTop) return;
    if (_dir == _root) {
      _load('/storage'); // other storage (SD card)
      return;
    }
    final parent = p.dirname(_dir);
    _load(parent == _dir ? _root : parent);
  }

  String _date(DateTime d) {
    String two(int n) => n.toString().padLeft(2, '0');
    return '${d.year}-${two(d.month)}-${two(d.day)}';
  }

  @override
  Widget build(BuildContext context) {
    final list = _visible();
    return Column(
      children: [
        Material(
          color: kPanel,
          child: ListTile(
            dense: true,
            leading: const Icon(Icons.arrow_upward, color: kGreen),
            title: Text(_dir, maxLines: 1, overflow: TextOverflow.ellipsis),
            subtitle: const Text('Tap to go up'),
            onTap: _atTop ? null : _up,
          ),
        ),
        Expanded(
          child: _loading
              ? const Center(child: CircularProgressIndicator())
              : _error != null
                  ? Center(
                      child: Padding(
                        padding: const EdgeInsets.all(24),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Text(_error!, textAlign: TextAlign.center),
                            const SizedBox(height: 12),
                            FilledButton(onPressed: () => _load(_dir), child: const Text('Try again')),
                          ],
                        ),
                      ),
                    )
                  : list.isEmpty
                      ? const Center(child: Text('Empty folder.'))
                      : RefreshIndicator(
                          onRefresh: () => _load(_dir),
                          child: ListView.builder(
                            padding: const EdgeInsets.only(bottom: 90),
                            itemCount: list.length,
                            itemBuilder: (context, i) {
                              final it = list[i];
                              if (it.isDir) {
                                return ListTile(
                                  leading: const SizedBox(
                                    width: 52,
                                    height: 52,
                                    child: Icon(Icons.folder, color: kBlue, size: 34),
                                  ),
                                  title: Text(it.name, maxLines: 1, overflow: TextOverflow.ellipsis),
                                  subtitle: Text(_date(it.date)),
                                  trailing: const Icon(Icons.chevron_right),
                                  onTap: () => _load(it.path),
                                );
                              }
                              final e = _entry(it);
                              final on = widget.selected(e);
                              return ListTile(
                                key: ValueKey(it.path),
                                selected: on,
                                selectedTileColor: alpha(kBlue, 0.15),
                                leading: SizedBox(
                                  width: 52,
                                  height: 52,
                                  child: MediaThumb(entry: e, size: 128, radius: 12),
                                ),
                                title: Text(it.name, maxLines: 1, overflow: TextOverflow.ellipsis),
                                subtitle: Text('${formatSize(it.size)} • ${_date(it.date)}'),
                                trailing: Checkbox(value: on, onChanged: (_) => widget.onToggle(e)),
                                onTap: () => widget.onOpen(e),
                                onLongPress: () => widget.onToggle(e),
                              );
                            },
                          ),
                        ),
        ),
      ],
    );
  }
}
