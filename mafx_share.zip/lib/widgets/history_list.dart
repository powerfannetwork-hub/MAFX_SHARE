import 'package:flutter/material.dart';

import '../media/media_entry.dart';
import '../models.dart';
import '../screens/viewer_screens.dart';
import '../services/file_ops.dart';
import '../services/history_service.dart';
import '../theme.dart';

String _date(DateTime d) {
  String two(int n) => n.toString().padLeft(2, '0');
  return '${d.year}-${two(d.month)}-${two(d.day)} ${two(d.hour)}:${two(d.minute)}';
}

/// Everything sent or received (entries older than 2 months disappear).
/// Files received by this version are content:// URIs in the public folders;
/// older entries are plain file paths. Both are handled.
class HistoryList extends StatelessWidget {
  const HistoryList({super.key, this.query = '', this.sort = SortMode.newest});

  final String query;
  final SortMode sort;

  List<HistoryEntry> _prepare(List<HistoryEntry> all) {
    final q = query.trim().toLowerCase();
    final list = q.isEmpty ? all.toList() : all.where((e) => e.name.toLowerCase().contains(q)).toList();
    switch (sort) {
      case SortMode.newest:
        list.sort((a, b) => b.date.compareTo(a.date));
      case SortMode.oldest:
        list.sort((a, b) => a.date.compareTo(b.date));
      case SortMode.nameAsc:
        list.sort((a, b) => a.name.toLowerCase().compareTo(b.name.toLowerCase()));
      case SortMode.nameDesc:
        list.sort((a, b) => b.name.toLowerCase().compareTo(a.name.toLowerCase()));
      case SortMode.largest:
        list.sort((a, b) => b.size.compareTo(a.size));
      case SortMode.smallest:
        list.sort((a, b) => a.size.compareTo(b.size));
      default:
        break;
    }
    return list;
  }

  Future<void> _open(BuildContext context, HistoryEntry e) async {
    final messenger = ScaffoldMessenger.of(context);
    if (e.path.isEmpty || !await FileOps.exists(e.path)) {
      messenger.showSnackBar(
        const SnackBar(content: Text('The file is no longer on this phone.')),
      );
      return;
    }
    if (!context.mounted) return;
    await openFileViewer(context, e.path, name: e.name, size: e.size);
  }

  Future<void> _share(BuildContext context, HistoryEntry e) async {
    final messenger = ScaffoldMessenger.of(context);
    if (e.path.isEmpty || !await FileOps.exists(e.path)) {
      messenger.showSnackBar(
        const SnackBar(content: Text('The file is no longer on this phone.')),
      );
      return;
    }
    await FileOps.share([e.path]);
  }

  void _details(BuildContext context, HistoryEntry e) {
    showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('File details'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Name: ${e.name}'),
            Text('Size: ${formatSize(e.size)}'),
            Text('${e.type == 'sent' ? 'Sent' : 'Received'}: ${_date(e.date)}'),
            Text('Status: ${e.status == 'partial' ? 'interrupted at ${e.percent}%' : 'complete'}'),
            const SizedBox(height: 6),
            Text('Location: ${e.path}', style: const TextStyle(fontSize: 12, color: Colors.white70)),
          ],
        ),
        actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Close'))],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final history = HistoryService.instance;
    return ValueListenableBuilder<int>(
      valueListenable: history.changes,
      builder: (context, _, __) {
        final items = _prepare(history.all());
        if (items.isEmpty) {
          return Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(Icons.history, size: 56, color: Colors.white24),
                const SizedBox(height: 8),
                Text(query.isEmpty ? 'No transfers yet.' : 'No results.'),
              ],
            ),
          );
        }
        return ListView.builder(
          itemCount: items.length,
          itemBuilder: (context, i) {
            final e = items[i];
            final sent = e.type == 'sent';
            final partial = e.status == 'partial';
            return ListTile(
              leading: CircleAvatar(
                backgroundColor: alpha(sent ? kGreen : kBlue, 0.25),
                child: Icon(
                  partial
                      ? Icons.warning_amber_rounded
                      : (sent ? Icons.arrow_upward : Icons.arrow_downward),
                  color: partial ? Colors.orangeAccent : (sent ? kGreen : kBlue),
                ),
              ),
              title: Text(e.name, maxLines: 1, overflow: TextOverflow.ellipsis),
              subtitle: Text(
                partial
                    ? '${sent ? 'Sending' : 'Receiving'} interrupted at ${e.percent}% • ${formatSize(e.size)} • ${_date(e.date)}'
                    : '${sent ? 'Sent' : 'Received'} ✓ • ${formatSize(e.size)} • ${_date(e.date)}',
                style: TextStyle(color: partial ? Colors.orangeAccent : null),
              ),
              trailing: PopupMenuButton<String>(
                color: kPanel,
                onSelected: (v) {
                  switch (v) {
                    case 'open':
                      _open(context, e);
                    case 'share':
                      _share(context, e);
                    case 'details':
                      _details(context, e);
                    case 'remove':
                      history.remove(e.key);
                  }
                },
                itemBuilder: (_) => [
                  if (!partial) const PopupMenuItem(value: 'open', child: Text('Open')),
                  if (!partial) const PopupMenuItem(value: 'share', child: Text('Share')),
                  const PopupMenuItem(value: 'details', child: Text('Details')),
                  const PopupMenuItem(value: 'remove', child: Text('Remove from history')),
                ],
              ),
              onTap: () => _open(context, e),
            );
          },
        );
      },
    );
  }
}
