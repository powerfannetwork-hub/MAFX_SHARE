import 'dart:async';
import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:photo_manager/photo_manager.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../media/media_entry.dart';
import '../models.dart';
import '../screens/music/now_playing_screen.dart';
import '../screens/music/playlists_screen.dart';
import '../screens/video_player_screen.dart';
import '../screens/viewer_screens.dart';
import '../services/file_ops.dart';
import '../services/music_service.dart';
import '../services/native_bridge.dart';
import '../services/selection_service.dart';
import '../theme.dart';
import 'apps_list.dart';
import 'file_browser.dart';
import 'history_list.dart';
import 'media_thumb.dart';
import 'mini_player.dart';
import 'selection_bar.dart';

/// Kept for older code.
enum MediaKind { video, image, audio }

const _tabNames = ['History', 'Apps', 'Photos', 'Videos', 'Music', 'Files'];
const _tabIcons = [
  Icons.history,
  Icons.apps,
  Icons.image_outlined,
  Icons.videocam_outlined,
  Icons.music_note_outlined,
  Icons.folder_outlined,
];

/// Media browser: History, Apps, Photos, Videos, Music and Files tabs with
/// search, sorting, list / grid view (remembered), multi-selection, select
/// all, share, delete with confirmation and file details.
class MediaHubScreen extends StatefulWidget {
  const MediaHubScreen({super.key, this.initialTab = 2});
  final int initialTab;

  @override
  State<MediaHubScreen> createState() => _MediaHubScreenState();
}

class _MediaHubScreenState extends State<MediaHubScreen>
    with SingleTickerProviderStateMixin {
  late final TabController _tabs = TabController(
    length: _tabNames.length,
    vsync: this,
    initialIndex: widget.initialTab.clamp(0, _tabNames.length - 1).toInt(),
  );

  /// Files added with the "Add files" button (Files tab).
  static final List<MediaEntry> _picked = [];

  final Map<EntryKind, List<MediaEntry>> _data = {};
  final Map<EntryKind, bool> _loading = {};
  final Map<EntryKind, String?> _error = {};
  final Map<String, SortMode> _sort = {};
  final Map<String, bool> _grid = {};
  final Map<String, MediaEntry> _sel = {};

  bool _searching = false;
  String _query = '';
  final TextEditingController _searchCtl = TextEditingController();
  bool _permissionOk = false;
  bool _allFiles = false; // "all files access" is on: real file manager
  bool _triedPm = false;
  bool _prefsReady = false;

  static const Map<int, EntryKind> _kinds = {
    2: EntryKind.photo,
    3: EntryKind.video,
    4: EntryKind.audio,
    5: EntryKind.file,
  };

  String _tabKey(int tab) => _tabNames[tab].toLowerCase();

  @override
  void initState() {
    super.initState();
    _tabs.addListener(() {
      if (!_tabs.indexIsChanging && mounted) setState(() {});
    });
    SelectionService.instance.addListener(_syncSelection);
    _init();
  }

  @override
  void dispose() {
    SelectionService.instance.removeListener(_syncSelection);
    _tabs.dispose();
    _searchCtl.dispose();
    super.dispose();
  }

  Future<void> _init() async {
    final sp = await SharedPreferences.getInstance();
    for (var t = 0; t < _tabNames.length; t++) {
      final k = _tabKey(t);
      final si = sp.getInt('sort_$k') ?? 0;
      _sort[k] = SortMode.values[si.clamp(0, SortMode.values.length - 1).toInt()];
      _grid[k] = sp.getBool('grid_$k') ?? (t == 2 || t == 3);
    }
    _prefsReady = true;
    if (mounted) setState(() {});
    await _ensurePermission();
    if (_permissionOk) {
      for (final k in _kinds.values) {
        unawaited(_load(k));
      }
    }
  }

  Future<void> _ensurePermission() async {
    _allFiles = await Native.isAllFilesGranted();
    if (_allFiles) {
      // One switch covers everything; no extra media questions.
      _permissionOk = true;
      if (mounted) setState(() {});
      return;
    }
    await _requestPm();
  }

  Future<void> _requestPm() async {
    try {
      final ps = await PhotoManager.requestPermissionExtend(
        requestOption: PermissionRequestOption(
          androidPermission: AndroidPermission(
            type: RequestType.all,
            mediaLocation: false,
          ),
        ),
      );
      _permissionOk = ps.hasAccess;
    } catch (_) {
      _permissionOk = false;
    }
    if (mounted) setState(() {});
  }

  Future<void> _load(EntryKind kind) async {
    if (mounted) {
      setState(() {
        _loading[kind] = true;
        _error[kind] = null;
      });
    }
    try {
      if (kind == EntryKind.audio) {
        await MusicService.instance.loadLibrary(force: true);
        _data[kind] = MusicService.instance.library;
      } else if (kind == EntryKind.file) {
        final raw = await Native.queryMedia('download');
        final list = [for (final m in raw) MediaEntry.fromMap('download', m)];
        _picked.removeWhere((e) => !File(e.path).existsSync());
        _data[kind] = [..._picked, ...list];
      } else {
        final name = kind == EntryKind.video ? 'video' : 'image';
        final raw = await Native.queryMedia(name);
        _data[kind] = [for (final m in raw) MediaEntry.fromMap(name, m)];
      }
    } catch (e) {
      if (_allFiles && !_triedPm) {
        // Some phones still want the media permission: ask once, then retry.
        _triedPm = true;
        await _requestPm();
        return _load(kind);
      }
      _error[kind] = 'Could not load files: $e';
    }
    if (mounted) setState(() => _loading[kind] = false);
  }

  // ---------------------------------------------------------- selection

  void _syncSelection() {
    final svc = SelectionService.instance;
    final gone = _sel.keys.where((k) => !svc.contains(k)).toList();
    if (gone.isEmpty) return;
    for (final k in gone) {
      _sel.remove(k);
    }
    if (mounted) setState(() {});
  }

  void _snack(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(msg)));
  }

  Future<bool> _select(MediaEntry e) async {
    var path = e.path;
    if (path.isEmpty || !File(path).existsSync()) {
      final f = await FileOps.toFile(e.source, e.name);
      if (f == null) {
        _snack('Cannot read "${e.name}".');
        return false;
      }
      path = f.path;
    }
    SelectionService.instance.add(
      PendingFile(id: e.key, path: path, name: e.name, size: e.size),
    );
    _sel[e.key] = e;
    return true;
  }

  Future<void> _toggle(MediaEntry e) async {
    if (_sel.containsKey(e.key)) {
      _sel.remove(e.key);
      SelectionService.instance.remove(e.key);
      if (mounted) setState(() {});
      return;
    }
    await _select(e);
    if (mounted) setState(() {});
  }

  void _clearSelection() {
    for (final k in _sel.keys.toList()) {
      SelectionService.instance.remove(k);
    }
    _sel.clear();
    setState(() {});
  }

  Future<void> _selectAll() async {
    final kind = _kinds[_tabs.index];
    if (kind == null) return;
    final list = _visible(kind);
    var failed = 0;
    for (final e in list) {
      if (_sel.containsKey(e.key)) continue;
      if (!await _select(e)) failed++;
    }
    if (failed > 0) _snack('$failed file(s) could not be selected.');
    if (mounted) setState(() {});
  }

  Future<void> _shareSelected() async {
    final ok = await FileOps.share([for (final e in _sel.values) e.source]);
    if (!ok) _snack('Could not open the share menu.');
  }

  Future<void> _deleteSelected() async {
    final chosen = _sel.values.toList();
    if (!await FileOps.confirmDelete(context, chosen.length)) return;
    final n = await FileOps.delete([for (final e in chosen) e.source]);
    final deletedKeys = <String>{};
    for (final e in chosen) {
      if (!await FileOps.exists(e.source)) deletedKeys.add(e.key);
    }
    for (final k in deletedKeys) {
      _sel.remove(k);
      SelectionService.instance.remove(k);
    }
    for (final kind in _data.keys.toList()) {
      _data[kind] = _data[kind]!.where((e) => !deletedKeys.contains(e.key)).toList();
    }
    _picked.removeWhere((e) => deletedKeys.contains(e.key));
    if (!mounted) return;
    setState(() {});
    _snack(deletedKeys.length == chosen.length
        ? 'Deleted ${deletedKeys.length} file(s).'
        : 'Deleted $n of ${chosen.length} file(s).');
  }

  void _details() {
    final list = _sel.values.toList();
    if (list.isEmpty) return;
    if (list.length > 1) {
      final total = list.fold<int>(0, (s, e) => s + e.size);
      showDialog<void>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text('Selected files'),
          content: Text('${list.length} files • ${formatSize(total)}'),
          actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Close'))],
        ),
      );
      return;
    }
    _showDetails(list.first);
  }

  Future<void> _showDetails(MediaEntry e) async {
    final info = (e.kind == EntryKind.video || e.kind == EntryKind.audio)
        ? await Native.mediaInfo(e.source)
        : <String, dynamic>{};
    final d = DateTime.fromMillisecondsSinceEpoch(e.dateMs);
    String two(int n) => n.toString().padLeft(2, '0');
    final rows = <MapEntry<String, String>>[
      MapEntry('Name', e.name),
      MapEntry('Size', formatSize(e.size)),
      if (e.dateMs > 0)
        MapEntry('Date', '${d.year}-${two(d.month)}-${two(d.day)} ${two(d.hour)}:${two(d.minute)}'),
      if (e.mime.isNotEmpty) MapEntry('Type', e.mime),
      if (e.durationMs > 0) MapEntry('Duration', formatDuration(e.durationMs ~/ 1000)),
      if (e.width > 0 && e.height > 0) MapEntry('Resolution', '${e.width} x ${e.height}'),
      if (info['bitrate'] != null)
        MapEntry('Bitrate', '${((int.tryParse(info['bitrate'].toString()) ?? 0) / 1000).round()} kbps'),
      if ((e.artist ?? '').isNotEmpty) MapEntry('Artist', e.artist!),
      if ((e.album ?? '').isNotEmpty) MapEntry('Album', e.album!),
      MapEntry('Location', e.path.isNotEmpty ? e.path : e.uri),
    ];
    if (!mounted) return;
    await showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('File details'),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              for (final r in rows)
                Padding(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: Text.rich(TextSpan(children: [
                    TextSpan(text: '${r.key}: ', style: const TextStyle(color: kGreen)),
                    TextSpan(text: r.value),
                  ])),
                ),
            ],
          ),
        ),
        actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Close'))],
      ),
    );
  }

  // ------------------------------------------------------ list helpers

  SortMode _sortOf(int tab) => _sort[_tabKey(tab)] ?? SortMode.newest;
  bool _gridOf(int tab) => _grid[_tabKey(tab)] ?? false;

  int _kindTab(EntryKind k) => _kinds.entries.firstWhere((e) => e.value == k).key;

  List<MediaEntry> _visible(EntryKind kind) =>
      sortAndFilter(_data[kind] ?? const [], _sortOf(_kindTab(kind)), _query);

  Future<void> _setSort(int tab, SortMode m) async {
    setState(() => _sort[_tabKey(tab)] = m);
    final sp = await SharedPreferences.getInstance();
    await sp.setInt('sort_${_tabKey(tab)}', m.index);
  }

  Future<void> _toggleGrid(int tab) async {
    final v = !_gridOf(tab);
    setState(() => _grid[_tabKey(tab)] = v);
    final sp = await SharedPreferences.getInstance();
    await sp.setBool('grid_${_tabKey(tab)}', v);
  }

  Future<void> _addFiles() async {
    try {
      final result = await FilePicker.platform.pickFiles(allowMultiple: true);
      if (result == null) return;
      for (final f in result.files) {
        final path = f.path;
        if (path == null) continue;
        if (_picked.any((e) => e.id == path)) continue;
        _picked.add(MediaEntry.picked(path, f.name, f.size));
      }
      _data[EntryKind.file] = [
        ..._picked,
        ...(_data[EntryKind.file] ?? const <MediaEntry>[]).where((e) => e.uri.isNotEmpty),
      ];
      if (mounted) setState(() {});
    } catch (e) {
      _snack('Could not pick files: $e');
    }
  }

  // ---------------------------------------------------------- open item

  Future<void> _open(MediaEntry e, List<MediaEntry> list, int index) async {
    if (_sel.isNotEmpty) {
      await _toggle(e);
      return;
    }
    switch (e.kind) {
      case EntryKind.audio:
        await playFrom(context, list, index);
      case EntryKind.video:
        await Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => VideoPlayerScreen(source: e.source, name: e.name, size: e.size),
          ),
        );
      case EntryKind.photo:
        await Navigator.push(
          context,
          MaterialPageRoute(builder: (_) => ImageViewerScreen(path: e.source, name: e.name)),
        );
      case EntryKind.file:
        await openFileViewer(context, e.source, name: e.name, size: e.size);
    }
  }

  // ------------------------------------------------------------- build

  @override
  Widget build(BuildContext context) {
    final tab = _tabs.index;
    final selecting = _sel.isNotEmpty;
    return PopScope(
      canPop: !selecting && !_searching,
      onPopInvokedWithResult: (didPop, _) {
        if (didPop) return;
        if (selecting) {
          _clearSelection();
        } else if (_searching) {
          setState(() {
            _searching = false;
            _query = '';
            _searchCtl.clear();
          });
        }
      },
      child: Scaffold(
        appBar: AppBar(
          leading: selecting
              ? IconButton(icon: const Icon(Icons.close), onPressed: _clearSelection)
              : null,
          title: selecting
              ? Text('${_sel.length} selected')
              : _searching
                  ? TextField(
                      controller: _searchCtl,
                      autofocus: true,
                      decoration: const InputDecoration(
                        hintText: 'Search',
                        border: InputBorder.none,
                      ),
                      onChanged: (v) => setState(() => _query = v),
                    )
                  : const Text('Media'),
          actions: selecting ? _selectionActions() : _normalActions(tab),
          bottom: TabBar(
            controller: _tabs,
            isScrollable: true,
            tabAlignment: TabAlignment.start,
            indicatorColor: kGreen,
            labelColor: kGreen,
            tabs: [
              for (var i = 0; i < _tabNames.length; i++)
                Tab(icon: Icon(_tabIcons[i], size: 20), text: _tabNames[i]),
            ],
          ),
        ),
        floatingActionButton: tab == 5 && !selecting && !_allFiles
            ? FloatingActionButton.extended(
                backgroundColor: kBlue,
                onPressed: _addFiles,
                icon: const Icon(Icons.add),
                label: const Text('Add files'),
              )
            : null,
        body: !_prefsReady
            ? const Center(child: CircularProgressIndicator())
            : TabBarView(
                controller: _tabs,
                children: [
                  HistoryList(query: _query, sort: _sortOf(0)),
                  AppsList(query: _query),
                  _mediaTab(2, EntryKind.photo),
                  _mediaTab(3, EntryKind.video),
                  _mediaTab(4, EntryKind.audio),
                  _allFiles
                      ? FileBrowserView(
                          query: _query,
                          sort: _sortOf(5),
                          selected: (e) => _sel.containsKey(e.key),
                          onToggle: (e) => _toggle(e),
                          onOpen: (e) async {
                            if (_sel.isNotEmpty) {
                              await _toggle(e);
                            } else {
                              await openFileViewer(context, e.path, name: e.name, size: e.size);
                            }
                          },
                        )
                      : _mediaTab(5, EntryKind.file),
                ],
              ),
        bottomNavigationBar: const SafeArea(
          top: false,
          child: Padding(
            padding: EdgeInsets.symmetric(horizontal: 10),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [MiniPlayer(), SelectionBar()],
            ),
          ),
        ),
      ),
    );
  }

  List<Widget> _selectionActions() => [
        IconButton(tooltip: 'Select all', icon: const Icon(Icons.select_all), onPressed: _selectAll),
        IconButton(tooltip: 'Share', icon: const Icon(Icons.share), onPressed: _shareSelected),
        IconButton(tooltip: 'Details', icon: const Icon(Icons.info_outline), onPressed: _details),
        IconButton(tooltip: 'Delete', icon: const Icon(Icons.delete_outline), onPressed: _deleteSelected),
      ];

  List<Widget> _normalActions(int tab) {
    final kind = _kinds[tab];
    return [
      IconButton(
        tooltip: _searching ? 'Close search' : 'Search',
        icon: Icon(_searching ? Icons.search_off : Icons.search),
        onPressed: () => setState(() {
          _searching = !_searching;
          if (!_searching) {
            _query = '';
            _searchCtl.clear();
          }
        }),
      ),
      if (kind != null)
        IconButton(
          tooltip: _gridOf(tab) ? 'List view' : 'Grid view',
          icon: Icon(_gridOf(tab) ? Icons.view_list : Icons.grid_view),
          onPressed: () => _toggleGrid(tab),
        ),
      if (tab != 1)
        PopupMenuButton<SortMode>(
          tooltip: 'Sort',
          color: kPanel,
          icon: const Icon(Icons.sort),
          onSelected: (m) => _setSort(tab, m),
          itemBuilder: (_) => [
            for (final m in SortMode.values)
              if (!m.needsDuration || kind == EntryKind.audio || kind == EntryKind.video)
                CheckedPopupMenuItem<SortMode>(
                  value: m,
                  checked: _sortOf(tab) == m,
                  child: Text(m.label),
                ),
          ],
        ),
    ];
  }

  // ---------------------------------------------------------- media tab

  Widget _mediaTab(int tab, EntryKind kind) {
    if (!_permissionOk) {
      return _message(
        icon: Icons.lock_outline,
        text: 'Allow access to your media to see your files.',
        actions: [
          FilledButton(
            onPressed: () async {
              await _ensurePermission();
              if (_permissionOk) {
                for (final k in _kinds.values) {
                  unawaited(_load(k));
                }
              }
            },
            child: const Text('Allow access'),
          ),
          TextButton(onPressed: PhotoManager.openSetting, child: const Text('Open settings')),
        ],
      );
    }
    if (_data[kind] == null && _error[kind] == null) {
      return const Center(child: CircularProgressIndicator());
    }
    if (_error[kind] != null) {
      return _message(
        icon: Icons.error_outline,
        text: _error[kind]!,
        actions: [FilledButton(onPressed: () => _load(kind), child: const Text('Try again'))],
      );
    }
    final list = _visible(kind);
    if (list.isEmpty) {
      return _message(
        icon: _tabIcons[tab],
        text: _query.isNotEmpty
            ? 'No results.'
            : kind == EntryKind.file
                ? 'Tap "Add files" to choose documents, APKs, zips...\nReceived files appear here too.'
                : 'Nothing found on this phone.',
      );
    }
    final Widget body = _gridOf(tab) ? _gridView(list, kind) : _listView(list, kind);
    return RefreshIndicator(onRefresh: () => _load(kind), child: body);
  }

  Widget _message({required IconData icon, required String text, List<Widget> actions = const []}) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, size: 56, color: Colors.white24),
            const SizedBox(height: 10),
            Text(text, textAlign: TextAlign.center),
            const SizedBox(height: 12),
            ...actions,
          ],
        ),
      ),
    );
  }

  Widget _musicHeader(List<MediaEntry> list) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 8, 12, 4),
      child: Row(
        children: [
          Expanded(
            child: FilledButton.icon(
              style: FilledButton.styleFrom(backgroundColor: kGreen, foregroundColor: Colors.black),
              onPressed: list.isEmpty
                  ? null
                  : () async {
                      final nav = Navigator.of(context);
                      final svc = MusicService.instance;
                      await svc.playQueue(list, 0);
                      if (!svc.shuffle) await svc.toggleShuffle();
                      nav.push(MaterialPageRoute(builder: (_) => const NowPlayingScreen()));
                    },
              icon: const Icon(Icons.shuffle),
              label: const Text('Shuffle'),
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: OutlinedButton.icon(
              onPressed: () => Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => Scaffold(
                    appBar: AppBar(title: const Text('Playlists')),
                    body: const PlaylistsView(),
                  ),
                ),
              ),
              icon: const Icon(Icons.queue_music),
              label: const Text('Playlists'),
            ),
          ),
        ],
      ),
    );
  }

  String _subtitle(MediaEntry e) {
    final parts = <String>[];
    if (e.kind == EntryKind.audio) {
      if ((e.artist ?? '').isNotEmpty && e.artist != '<unknown>') parts.add(e.artist!);
      if (e.durationMs > 0) parts.add(formatDuration(e.durationMs ~/ 1000));
    } else if (e.kind == EntryKind.video) {
      if (e.durationMs > 0) parts.add(formatDuration(e.durationMs ~/ 1000));
    }
    parts.add(formatSize(e.size));
    return parts.join(' • ');
  }

  Widget _listView(List<MediaEntry> list, EntryKind kind) {
    final header = kind == EntryKind.audio ? 1 : 0;
    return ListView.builder(
      padding: const EdgeInsets.only(bottom: 90),
      itemCount: list.length + header,
      itemBuilder: (context, i) {
        if (header == 1 && i == 0) return _musicHeader(list);
        final idx = i - header;
        final e = list[idx];
        final on = _sel.containsKey(e.key);
        return ListTile(
          key: ValueKey(e.key),
          selected: on,
          selectedTileColor: alpha(kBlue, 0.15),
          leading: SizedBox(
            width: 52,
            height: 52,
            child: MediaThumb(entry: e, size: 128, radius: 12),
          ),
          title: Text(e.displayName, maxLines: 1, overflow: TextOverflow.ellipsis),
          subtitle: Text(_subtitle(e), maxLines: 1, overflow: TextOverflow.ellipsis),
          trailing: kind == EntryKind.audio
              ? Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    IconButton(
                      tooltip: 'Add to playlist',
                      icon: const Icon(Icons.playlist_add),
                      onPressed: () => showAddToPlaylist(context, [e]),
                    ),
                    Checkbox(value: on, onChanged: (_) => _toggle(e)),
                  ],
                )
              : Checkbox(value: on, onChanged: (_) => _toggle(e)),
          onTap: () => _open(e, list, idx),
          onLongPress: () => _toggle(e),
        );
      },
    );
  }

  Widget _gridView(List<MediaEntry> list, EntryKind kind) {
    return LayoutBuilder(builder: (context, box) {
      final cols = (box.maxWidth / 120).floor().clamp(3, 8).toInt();
      return GridView.builder(
        padding: const EdgeInsets.fromLTRB(4, 4, 4, 90),
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: cols,
          mainAxisSpacing: 4,
          crossAxisSpacing: 4,
        ),
        itemCount: list.length,
        itemBuilder: (context, i) {
          final e = list[i];
          final on = _sel.containsKey(e.key);
          return GestureDetector(
            key: ValueKey(e.key),
            onTap: () => _open(e, list, i),
            onLongPress: () => _toggle(e),
            child: Stack(
              fit: StackFit.expand,
              children: [
                MediaThumb(entry: e, size: 300, radius: 8),
                if (on) Container(color: alpha(kBlue, 0.35)),
                if (kind == EntryKind.video && e.durationMs > 0)
                  Positioned(
                    left: 6,
                    bottom: 6,
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                      decoration: BoxDecoration(
                        color: Colors.black54,
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Text(formatDuration(e.durationMs ~/ 1000),
                          style: const TextStyle(fontSize: 11)),
                    ),
                  ),
                if (kind == EntryKind.audio || kind == EntryKind.file)
                  Positioned(
                    left: 0,
                    right: 0,
                    bottom: 0,
                    child: Container(
                      padding: const EdgeInsets.all(4),
                      color: Colors.black54,
                      child: Text(e.displayName,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(fontSize: 11)),
                    ),
                  ),
                Positioned(
                  right: 0,
                  top: 0,
                  child: Checkbox(
                    value: on,
                    visualDensity: VisualDensity.compact,
                    onChanged: (_) => _toggle(e),
                  ),
                ),
              ],
            ),
          );
        },
      );
    });
  }
}
