import 'dart:collection';
import 'dart:typed_data';

import 'package:flutter/material.dart';

import '../media/media_entry.dart';
import '../services/native_bridge.dart';
import '../theme.dart';

/// Small in-memory cache so scrolling lists does not decode again.
class ThumbCache {
  ThumbCache._();
  static final ThumbCache instance = ThumbCache._();

  final LinkedHashMap<String, Uint8List?> _map = LinkedHashMap();
  final Map<String, Future<Uint8List?>> _loading = {};

  bool has(String key) => _map.containsKey(key);
  Uint8List? get(String key) => _map[key];

  Future<Uint8List?> load(String key, String source, String kind,
      {int size = 256, int albumId = -1}) {
    if (_map.containsKey(key)) return Future.value(_map[key]);
    return _loading.putIfAbsent(key, () async {
      final b = await Native.thumbnail(source, kind, size: size, albumId: albumId);
      _map[key] = b;
      if (_map.length > 400) _map.remove(_map.keys.first);
      _loading.remove(key);
      return b;
    });
  }
}

/// Thumbnail / album artwork of a media entry, with an icon placeholder.
class MediaThumb extends StatefulWidget {
  const MediaThumb({
    super.key,
    required this.entry,
    this.size = 256,
    this.fit = BoxFit.cover,
    this.radius = 0,
  });

  final MediaEntry entry;
  final int size;
  final BoxFit fit;
  final double radius;

  @override
  State<MediaThumb> createState() => _MediaThumbState();
}

class _MediaThumbState extends State<MediaThumb> {
  Future<Uint8List?>? _future;

  String get _kind => switch (widget.entry.kind) {
        EntryKind.video => 'video',
        EntryKind.audio => 'audio',
        _ => 'image',
      };

  String get _cacheKey => '${widget.entry.key}@${widget.size}';

  @override
  void initState() {
    super.initState();
    _start();
  }

  @override
  void didUpdateWidget(covariant MediaThumb old) {
    super.didUpdateWidget(old);
    if (old.entry.key != widget.entry.key || old.size != widget.size) _start();
  }

  void _start() {
    final e = widget.entry;
    if (e.kind == EntryKind.file || e.source.isEmpty) {
      _future = null;
      return;
    }
    _future = ThumbCache.instance
        .load(_cacheKey, e.source, _kind, size: widget.size, albumId: e.albumId ?? -1);
  }

  IconData get _icon => switch (widget.entry.kind) {
        EntryKind.video => Icons.videocam_outlined,
        EntryKind.audio => Icons.music_note,
        EntryKind.photo => Icons.image_outlined,
        EntryKind.file => _fileIcon(widget.entry.name),
      };

  static IconData _fileIcon(String name) {
    final n = name.toLowerCase();
    if (n.endsWith('.apk')) return Icons.android;
    if (n.endsWith('.zip') || n.endsWith('.rar') || n.endsWith('.7z')) {
      return Icons.folder_zip_outlined;
    }
    if (n.endsWith('.pdf')) return Icons.picture_as_pdf_outlined;
    return Icons.insert_drive_file_outlined;
  }

  Widget _placeholder() => Container(
        color: alpha(kBlue, 0.14),
        alignment: Alignment.center,
        child: Icon(_icon, color: kBlue, size: 26),
      );

  @override
  Widget build(BuildContext context) {
    final cached = ThumbCache.instance.has(_cacheKey)
        ? ThumbCache.instance.get(_cacheKey)
        : null;
    Widget child;
    if (cached != null) {
      child = Image.memory(cached, fit: widget.fit, gaplessPlayback: true);
    } else if (_future == null) {
      child = _placeholder();
    } else {
      child = FutureBuilder<Uint8List?>(
        future: _future,
        builder: (context, snap) {
          final data = snap.data;
          if (data == null) return _placeholder();
          return Image.memory(data, fit: widget.fit, gaplessPlayback: true);
        },
      );
    }
    if (widget.radius > 0) {
      child = ClipRRect(
        borderRadius: BorderRadius.circular(widget.radius),
        child: child,
      );
    }
    return SizedBox.expand(child: child);
  }
}
