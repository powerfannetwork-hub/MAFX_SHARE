import 'package:flutter/material.dart';
import 'package:just_audio/just_audio.dart';

import '../screens/music/now_playing_screen.dart';
import '../services/music_service.dart';
import '../theme.dart';
import 'media_thumb.dart';

/// Small bar that shows the current song. Visible while music is loaded.
class MiniPlayer extends StatelessWidget {
  const MiniPlayer({super.key});

  @override
  Widget build(BuildContext context) {
    final svc = MusicService.instance;
    return ListenableBuilder(
      listenable: svc,
      builder: (context, _) {
        final cur = svc.current;
        if (cur == null) return const SizedBox.shrink();
        return Padding(
          padding: const EdgeInsets.only(bottom: 8),
          child: Material(
            color: kPanel,
            borderRadius: BorderRadius.circular(18),
            child: InkWell(
              borderRadius: BorderRadius.circular(18),
              onTap: () => Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const NowPlayingScreen()),
              ),
              child: Container(
                padding: const EdgeInsets.fromLTRB(10, 8, 6, 8),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(18),
                  border: Border.all(color: alpha(kBlue, 0.5)),
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Row(
                      children: [
                        SizedBox(
                          width: 42,
                          height: 42,
                          child: MediaThumb(entry: cur, size: 128, radius: 10),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(cur.displayName,
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: const TextStyle(fontWeight: FontWeight.w600)),
                              Text(cur.artist ?? 'Unknown artist',
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: const TextStyle(fontSize: 12, color: Colors.white60)),
                            ],
                          ),
                        ),
                        IconButton(
                          icon: const Icon(Icons.skip_previous),
                          onPressed: svc.previous,
                        ),
                        StreamBuilder<PlayerState>(
                          stream: svc.player.playerStateStream,
                          builder: (context, snap) {
                            final playing = snap.data?.playing ?? false;
                            return IconButton.filled(
                              style: IconButton.styleFrom(backgroundColor: kGreen, foregroundColor: Colors.black),
                              icon: Icon(playing ? Icons.pause : Icons.play_arrow),
                              onPressed: svc.togglePlay,
                            );
                          },
                        ),
                        IconButton(
                          icon: const Icon(Icons.skip_next),
                          onPressed: svc.next,
                        ),
                      ],
                    ),
                    StreamBuilder<Duration>(
                      stream: svc.player.positionStream,
                      builder: (context, snap) {
                        final pos = snap.data?.inMilliseconds ?? 0;
                        final dur = svc.player.duration?.inMilliseconds ?? cur.durationMs;
                        final f = dur > 0 ? (pos / dur).clamp(0.0, 1.0) : 0.0;
                        return Padding(
                          padding: const EdgeInsets.only(top: 4, right: 4),
                          child: LinearProgressIndicator(
                            value: f.toDouble(),
                            minHeight: 2,
                            color: kGreen,
                            backgroundColor: Colors.white12,
                          ),
                        );
                      },
                    ),
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}
