import 'package:flutter/material.dart';
import 'package:qr_flutter/qr_flutter.dart';

import '../models.dart';
import '../services/transfer_service.dart';
import '../theme.dart';

/// Which phones of the group should get the files? Returns null when there is
/// only one other phone (nothing to choose) or the user cancelled is NOT
/// distinguished: use [pickTargets] result `chosen == null` -> default phone,
/// empty list -> cancelled.
Future<List<PairedPeer>?> pickTargets(BuildContext context) async {
  final svc = TransferService.instance;
  final phones = svc.roster.value;
  if (phones.length <= 1) return null; // default: the one connected phone
  final selected = <int>{for (var i = 0; i < phones.length; i++) i};
  final res = await showDialog<List<PairedPeer>>(
    context: context,
    builder: (ctx) => StatefulBuilder(
      builder: (ctx, setS) => AlertDialog(
        title: const Text('Send to'),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              CheckboxListTile(
                value: selected.length == phones.length,
                title: const Text('All phones'),
                onChanged: (v) => setS(() {
                  selected.clear();
                  if (v == true) selected.addAll([for (var i = 0; i < phones.length; i++) i]);
                }),
              ),
              for (var i = 0; i < phones.length; i++)
                CheckboxListTile(
                  value: selected.contains(i),
                  title: Text(phones[i].name),
                  secondary: const Icon(Icons.smartphone),
                  onChanged: (v) => setS(() {
                    if (v == true) {
                      selected.add(i);
                    } else {
                      selected.remove(i);
                    }
                  }),
                ),
            ],
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, <PairedPeer>[]), child: const Text('Cancel')),
          FilledButton(
            onPressed: selected.isEmpty
                ? null
                : () => Navigator.pop(ctx, [for (final i in selected.toList()..sort()) phones[i].peer]),
            child: const Text('Send'),
          ),
        ],
      ),
    ),
  );
  return res ?? <PairedPeer>[];
}

/// Small card on Home while connected: how many phones (max 5) and who.
/// The host can add more phones.
class PeersBar extends StatelessWidget {
  const PeersBar({super.key});

  @override
  Widget build(BuildContext context) {
    final svc = TransferService.instance;
    return ValueListenableBuilder<PairedPeer?>(
      valueListenable: svc.pairedPeer,
      builder: (context, peer, _) {
        if (peer == null) return const SizedBox.shrink();
        return ValueListenableBuilder<List<RosterPeer>>(
          valueListenable: svc.roster,
          builder: (context, list, _) {
            final count = list.length + 1; // + this phone
            final isHost = svc.role == 'host';
            return Container(
              margin: const EdgeInsets.only(bottom: 8),
              padding: const EdgeInsets.fromLTRB(14, 8, 8, 8),
              decoration: BoxDecoration(
                color: kPanel,
                borderRadius: BorderRadius.circular(18),
                border: Border.all(color: alpha(kBlue, 0.5)),
              ),
              child: Row(
                children: [
                  const Icon(Icons.devices, color: kBlue),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('Connected phones: $count / ${TransferService.maxPhones}',
                            style: const TextStyle(fontWeight: FontWeight.w700)),
                        Text(
                          list.isEmpty ? 'Waiting...' : list.map((e) => e.name).join(', '),
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(fontSize: 12, color: alpha(Colors.white, 0.65)),
                        ),
                      ],
                    ),
                  ),
                  if (isHost && count < TransferService.maxPhones)
                    FilledButton.tonalIcon(
                      onPressed: () => Navigator.push(
                        context,
                        MaterialPageRoute(builder: (_) => const AddPhoneScreen()),
                      ),
                      icon: const Icon(Icons.add),
                      label: const Text('Add phone'),
                    ),
                ],
              ),
            );
          },
        );
      },
    );
  }
}

/// The host shows its QR code again so another phone can join the group.
class AddPhoneScreen extends StatelessWidget {
  const AddPhoneScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final svc = TransferService.instance;
    const blue = Color(0xFF2196F3);
    return Scaffold(
      appBar: AppBar(title: const Text('Add a phone')),
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: ListenableBuilder(
            listenable: svc.roster,
            builder: (context, _) => Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  padding: const EdgeInsets.all(18),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(32),
                    border: Border.all(color: const Color(0xFF3DB5FF), width: 5),
                  ),
                  child: QrImageView(
                    data: svc.qrPayload(),
                    size: 260,
                    backgroundColor: Colors.white,
                    eyeStyle: const QrEyeStyle(eyeShape: QrEyeShape.square, color: blue),
                    dataModuleStyle: const QrDataModuleStyle(
                      dataModuleShape: QrDataModuleShape.square,
                      color: blue,
                    ),
                  ),
                ),
                const SizedBox(height: 18),
                Text(
                  'Phones: ${svc.roster.value.length + 1} / ${TransferService.maxPhones}',
                  style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w700),
                ),
                const SizedBox(height: 8),
                const Text(
                  'On the other phone: open MAFX SHARE, tap Send, and scan this code.',
                  textAlign: TextAlign.center,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
