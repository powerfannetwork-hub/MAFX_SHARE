import 'package:flutter/material.dart';

import '../screens/connect_screen.dart';
import '../screens/transfer_screen.dart';
import '../services/selection_service.dart';
import '../services/transfer_service.dart';
import 'peers_bar.dart';
import '../theme.dart';

/// Bottom bar with the SEND button. Appears when something is ticked.
class SelectionBar extends StatelessWidget {
  const SelectionBar({super.key});

  @override
  Widget build(BuildContext context) {
    final sel = SelectionService.instance;
    return AnimatedBuilder(
      animation: sel,
      builder: (context, _) {
        if (sel.isEmpty) return const SizedBox.shrink();
        return SafeArea(
          top: false,
          child: Container(
            margin: const EdgeInsets.only(bottom: 8),
            padding: const EdgeInsets.fromLTRB(16, 10, 10, 10),
            decoration: BoxDecoration(
              color: kPanel,
              borderRadius: BorderRadius.circular(22),
              border: Border.all(color: alpha(kGreen, 0.6)),
            ),
            child: Row(
              children: [
                Expanded(
                  child: Text(
                    '${sel.count} selected • ${formatSize(sel.totalSize)}',
                    style: const TextStyle(fontWeight: FontWeight.w600),
                  ),
                ),
                FilledButton.icon(
                  style: FilledButton.styleFrom(
                    backgroundColor: kGreen,
                    foregroundColor: Colors.black,
                  ),
                  onPressed: () => _send(context, sel),
                  icon: const Icon(Icons.send),
                  label: const Text('SEND'),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Future<void> _send(BuildContext context, SelectionService sel) async {
    final svc = TransferService.instance;
    if (svc.isConnected) {
      // Several phones in the group: choose who gets the files.
      final targets = await pickTargets(context);
      if (targets != null && targets.isEmpty) return; // cancelled
      if (!context.mounted) return;
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => TransferScreen(files: sel.items, peers: targets),
        ),
      );
      return;
    }
    final connect = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Not connected'),
        content: const Text(
          'Connect to the other phone first: it shows a QR code on '
          '"Received", and you scan it here.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Connect'),
          ),
        ],
      ),
    );
    if (connect == true && context.mounted) {
      Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => const ConnectScreen(receive: false)),
      );
    }
  }
}
