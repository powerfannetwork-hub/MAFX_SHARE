import 'dart:async';

import 'package:flutter/material.dart';

import '../models.dart';
import '../screens/viewer_screens.dart';
import '../services/history_service.dart';
import '../services/transfer_service.dart';
import '../theme.dart';

/// Two tabs: "Send" (what this phone is sending) and "Received" (what is
/// coming in). Each tab shows its own live progress and its own recent files.
/// Also shows the Wi-Fi band / link speed, because that is what limits speed.
class TransferPanel extends StatefulWidget {
  const TransferPanel({super.key, this.initialTab = 0});

  final int initialTab;

  @override
  State<TransferPanel> createState() => _TransferPanelState();
}

class _TransferPanelState extends State<TransferPanel>
    with SingleTickerProviderStateMixin {
  final svc = TransferService.instance;
  late final TabController _tabs =
      TabController(length: 2, vsync: this, initialIndex: widget.initialTab);
  Timer? _timer;
  Map<String, int>? _link;
  bool _details = false;

  @override
  void initState() {
    super.initState();
    _poll();
    _timer = Timer.periodic(const Duration(seconds: 3), (_) => _poll());
  }

  @override
  void dispose() {
    _timer?.cancel();
    _tabs.dispose();
    super.dispose();
  }

  Future<void> _poll() async {
    final l = await svc.wifiLinkInfo();
    if (mounted) setState(() => _link = l);
  }

  Widget _linkInfo() {
    final l = _link;
    final f = l == null ? -1 : (l['freq'] ?? -1);
    final band = f >= 5925 ? '6 GHz' : (f >= 4900 ? '5 GHz' : '2.4 GHz');
    final speed = (l != null && (l['speed'] ?? -1) > 0) ? ' · ${l['speed']} Mbps' : '';
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Column(
        children: [
          if (f > 0) ...[
            Text('Wi-Fi: $band$speed',
                style: const TextStyle(fontWeight: FontWeight.w600)),
            if (f < 4900)
              Text(
                '2.4 GHz limits speed to roughly 5-12 MB/s. Use a 5 GHz Wi-Fi for more.',
                textAlign: TextAlign.center,
                style: TextStyle(
                    fontSize: 12, color: alpha(Colors.orangeAccent, 0.9)),
              ),
          ],
          ValueListenableBuilder<int>(
            valueListenable: svc.activeStreams,
            builder: (context, n, _) => n > 0
                ? Text('Streams in use: $n',
                    style: TextStyle(color: alpha(Colors.white, 0.7)))
                : const SizedBox.shrink(),
          ),
          ValueListenableBuilder<String>(
            valueListenable: svc.chunkInfo,
            builder: (context, info, _) => info.isEmpty
                ? const SizedBox.shrink()
                : Text(info,
                    textAlign: TextAlign.center,
                    style: TextStyle(
                        fontSize: 12, color: alpha(Colors.white, 0.6))),
          ),
        ],
      ),
    );
  }

  Tab _tab(String text, IconData icon, ValueNotifier<TransferProgress?> n) {
    return Tab(
      child: ValueListenableBuilder<TransferProgress?>(
        valueListenable: n,
        builder: (context, pr, _) {
          final active = pr != null && !pr.finished;
          return Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                pr != null && pr.finished ? Icons.check_circle : icon,
                size: 18,
                color: (active || (pr != null && pr.finished)) ? kGreen : null,
              ),
              const SizedBox(width: 6),
              Text(text),
              if (active) ...[
                const SizedBox(width: 6),
                Text('${(pr.fraction * 100).round()}%',
                    style: const TextStyle(color: kGreen, fontSize: 12)),
              ],
            ],
          );
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        ValueListenableBuilder<String>(
          valueListenable: svc.linkState,
          builder: (context, st, _) => st == 'lost'
              ? Container(
                  width: double.infinity,
                  margin: const EdgeInsets.only(bottom: 8),
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: alpha(Colors.orangeAccent, 0.15),
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: Colors.orangeAccent),
                  ),
                  child: const Text(
                    'Connection lost. Reconnecting by itself... What already arrived is kept.',
                    textAlign: TextAlign.center,
                  ),
                )
              : const SizedBox.shrink(),
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.end,
          children: [
            ValueListenableBuilder<int>(
              valueListenable: svc.activeStreams,
              // Getting slower? Tap: every stream reconnects fresh.
              builder: (context, n, _) => n > 0
                  ? IconButton(
                      tooltip: 'Refresh speed',
                      icon: const Icon(Icons.refresh),
                      onPressed: () {
                        svc.boostSpeed();
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(
                            content: Text('Connections refreshed'),
                            duration: Duration(seconds: 1),
                          ),
                        );
                      },
                    )
                  : const SizedBox.shrink(),
            ),
            IconButton(
              tooltip: 'Details',
              icon: Icon(_details ? Icons.info : Icons.info_outline),
              onPressed: () => setState(() => _details = !_details),
            ),
          ],
        ),
        if (_details) _linkInfo(),
        TabBar(
          controller: _tabs,
          indicatorColor: kGreen,
          labelColor: Colors.white,
          tabs: [
            _tab('Send', Icons.arrow_upward, svc.sendProgress),
            _tab('Received', Icons.arrow_downward, svc.receiveProgress),
          ],
        ),
        Expanded(
          child: TabBarView(
            controller: _tabs,
            children: [
              _DirectionView(sent: true),
              _DirectionView(sent: false),
            ],
          ),
        ),
      ],
    );
  }
}

class _DirectionView extends StatelessWidget {
  _DirectionView({required this.sent});

  final bool sent;
  final svc = TransferService.instance;

  @override
  Widget build(BuildContext context) {
    final notifier = sent ? svc.sendProgress : svc.receiveProgress;
    return ListView(
      padding: const EdgeInsets.fromLTRB(4, 16, 4, 16),
      children: [
        if (sent)
          ValueListenableBuilder<int>(
            valueListenable: svc.queued,
            builder: (context, q, _) => q > 0
                ? Padding(
                    padding: const EdgeInsets.only(bottom: 8),
                    child: Text('+$q more waiting in line',
                        textAlign: TextAlign.center,
                        style: TextStyle(color: alpha(Colors.white, 0.7))),
                  )
                : const SizedBox.shrink(),
          ),
        ValueListenableBuilder<TransferProgress?>(
          valueListenable: notifier,
          builder: (context, pr, _) => _progressCard(pr),
        ),
        const SizedBox(height: 16),
        Text(
          sent ? 'Recently sent' : 'Recently received',
          style: TextStyle(color: alpha(Colors.white, 0.7)),
        ),
        ValueListenableBuilder<int>(
          valueListenable: HistoryService.instance.changes,
          builder: (context, _, __) {
            final items = HistoryService.instance
                .all()
                .where((e) => e.type == (sent ? 'sent' : 'received'))
                .take(15)
                .toList();
            if (items.isEmpty) {
              return const Padding(
                padding: EdgeInsets.all(16),
                child: Text('Nothing here yet.'),
              );
            }
            return Column(
              children: [
                for (final e in items)
                  ListTile(
                    dense: true,
                    contentPadding: EdgeInsets.zero,
                    leading: Icon(
                      sent ? Icons.north_east : Icons.south_west,
                      color: sent ? kGreen : kBlue,
                    ),
                    title: Text(e.name, maxLines: 1, overflow: TextOverflow.ellipsis),
                    subtitle: Text(formatSize(e.size)),
                    onTap: () => openFileViewer(context, e.path),
                  ),
              ],
            );
          },
        ),
      ],
    );
  }

  Widget _progressCard(TransferProgress? pr) {
    if (pr == null) {
      return Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: kPanel,
          borderRadius: BorderRadius.circular(18),
        ),
        child: Center(
          child: Text(sent ? 'Nothing is being sent.' : 'Nothing is coming in.'),
        ),
      );
    }
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: kPanel,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: alpha(pr.finished ? kGreen : kBlue, 0.6)),
      ),
      child: Column(
        children: [
          if (pr.finished)
            const Icon(Icons.check_circle, size: 72, color: kGreen)
          else
            Text(
              '${(pr.fraction * 100).floor()}%',
              style: const TextStyle(fontSize: 48, fontWeight: FontWeight.w800),
            ),
          const SizedBox(height: 10),
          ClipRRect(
            borderRadius: BorderRadius.circular(8),
            child: LinearProgressIndicator(
              value: pr.fraction,
              minHeight: 10,
              color: kGreen,
              backgroundColor: kBg,
            ),
          ),
          const SizedBox(height: 12),
          Text(
            pr.currentName,
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
            textAlign: TextAlign.center,
            style: const TextStyle(fontWeight: FontWeight.w600),
          ),
          const SizedBox(height: 6),
          Text('File ${pr.fileIndex} of ${pr.fileCount}'),
          Text('${formatSize(pr.doneBytes)} / ${formatSize(pr.totalBytes)}'),
          const SizedBox(height: 6),
          Text(
            'Speed: ${formatSpeed(pr.speed)}',
            style: const TextStyle(
                fontSize: 18, fontWeight: FontWeight.w700, color: kGreen),
          ),
        ],
      ),
    );
  }
}
