import 'package:flutter_test/flutter_test.dart';
import 'package:share/models.dart';
import 'package:share/services/chunk_codec.dart';

void main() {
  const mib = 1024 * 1024;

  test('big files use the profile maximum, small files get more, smaller chunks', () {
    expect(ChunkPlan.sizeFor(4 * 1024 * mib, 16 * mib, 32), 16 * mib);
    final mid = ChunkPlan.sizeFor(200 * mib, 16 * mib, 32);
    expect(mid, lessThan(16 * mib));
    expect(ChunkCodec.chunkCount(200 * mib, mid), greaterThanOrEqualTo(32));
    expect(ChunkPlan.sizeFor(10 * mib, 16 * mib, 32), mib);
    expect(ChunkPlan.sizeFor(0, 16 * mib, 32), 16 * mib);
  });

  test('chunk size is a multiple of 256 KiB and never below 1 MiB', () {
    for (final size in [3 * mib, 50 * mib, 777 * mib, 5000 * mib]) {
      final c = ChunkPlan.sizeFor(size, 16 * mib, 24);
      expect(c % (256 * 1024), 0);
      expect(c, greaterThanOrEqualTo(mib));
      expect(c, lessThanOrEqualTo(16 * mib));
    }
  });

  test('file info fraction', () {
    const f = TransferFileInfo(index: 0, name: 'a', size: 200, doneBytes: 50, state: 'active');
    expect(f.fraction, 0.25);
    const e = TransferFileInfo(index: 1, name: 'b', size: 0, doneBytes: 0, state: 'done');
    expect(e.fraction, 1.0);
  });
}
