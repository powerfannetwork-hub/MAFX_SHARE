import 'package:flutter_test/flutter_test.dart';
import 'package:share/services/equalizer_service.dart';

void main() {
  test('resample keeps ends and length', () {
    final r = EqMath.resample([0, 10], 5);
    expect(r.length, 5);
    expect(r.first, 0);
    expect(r.last, 10);
    expect(r[2], closeTo(5, 1e-9));
  });

  test('resample to the same size returns a copy', () {
    expect(EqMath.resample([1, 2, 3], 3), [1, 2, 3]);
  });

  test('bass raises low bands, treble raises high bands, result is clamped', () {
    double g(int i, {double bass = 0, double treble = 0}) => EqMath.finalGain(
          base: 0, i: i, n: 5, bass: bass, treble: treble, minDb: -15, maxDb: 15);
    expect(g(0, bass: 1), greaterThan(0));
    expect(g(4, bass: 1), 0);
    expect(g(4, treble: 1), greaterThan(0));
    expect(g(0, treble: 1), 0);
    expect(g(0, bass: 1), lessThanOrEqualTo(15));
    expect(EqMath.finalGain(base: 14, i: 0, n: 5, bass: 1, treble: 0, minDb: -15, maxDb: 15), 15);
  });

  test('all required presets exist', () {
    final names = EqualizerService.presets.map((p) => p.name).toSet();
    for (final n in [
      'Bass Boost', 'Rock', 'Pop', 'Jazz', 'Classical', 'Dance',
      'Hip-Hop', 'Vocal', 'Acoustic', 'Remix', 'Flat',
    ]) {
      expect(names.contains(n), isTrue, reason: n);
    }
  });
}
