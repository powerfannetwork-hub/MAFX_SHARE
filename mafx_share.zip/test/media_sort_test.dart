import 'package:flutter_test/flutter_test.dart';
import 'package:share/media/media_entry.dart';

MediaEntry e(String id, String name, int size, int date, {int dur = 0}) => MediaEntry(
      id: id, kind: EntryKind.video, uri: '', path: '/x/$name', name: name,
      size: size, dateMs: date, durationMs: dur,
    );

void main() {
  final list = [
    e('1', 'b.mp4', 300, 20, dur: 50),
    e('2', 'a.mp4', 100, 30, dur: 90),
    e('3', 'c.mp4', 200, 10, dur: 10),
  ];
  List<String> ids(SortMode m, [String q = '']) =>
      sortAndFilter(list, m, q).map((x) => x.id).toList();

  test('sort modes', () {
    expect(ids(SortMode.newest), ['2', '1', '3']);
    expect(ids(SortMode.oldest), ['3', '1', '2']);
    expect(ids(SortMode.nameAsc), ['2', '1', '3']);
    expect(ids(SortMode.nameDesc), ['3', '1', '2']);
    expect(ids(SortMode.largest), ['1', '3', '2']);
    expect(ids(SortMode.smallest), ['2', '3', '1']);
    expect(ids(SortMode.longest), ['2', '1', '3']);
    expect(ids(SortMode.shortest), ['3', '1', '2']);
  });

  test('search', () {
    expect(ids(SortMode.newest, 'B.M'), ['1']);
    expect(ids(SortMode.newest, 'zzz'), isEmpty);
  });

  test('only audio / video sorts need duration', () {
    expect(SortMode.longest.needsDuration, isTrue);
    expect(SortMode.newest.needsDuration, isFalse);
  });
}
