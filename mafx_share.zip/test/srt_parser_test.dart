import 'package:flutter_test/flutter_test.dart';
import 'package:share/services/subtitle.dart';

void main() {
  const sample = '\uFEFF1\r\n00:00:01,000 --> 00:00:03,500\r\nHello <i>world</i>\r\n\r\n'
      '2\r\n00:00:04,000 --> 00:00:06,000\r\nSecond line\r\nwith two rows\r\n';

  test('parses cues, strips tags and BOM', () {
    final cues = SrtParser.parse(sample);
    expect(cues.length, 2);
    expect(cues[0].text, 'Hello world');
    expect(cues[0].start, const Duration(seconds: 1));
    expect(cues[0].end, const Duration(milliseconds: 3500));
    expect(cues[1].text, 'Second line\nwith two rows');
  });

  test('finds the cue at a position and honours the delay', () {
    final cues = SrtParser.parse(sample);
    expect(SrtParser.at(cues, const Duration(seconds: 2))?.text, 'Hello world');
    expect(SrtParser.at(cues, const Duration(milliseconds: 3800)), isNull);
    expect(SrtParser.at(cues, const Duration(seconds: 5))?.text, startsWith('Second'));
    // Delay of +2 s: the first cue now shows from 3 s to 5.5 s.
    expect(
      SrtParser.at(cues, const Duration(seconds: 3), offset: const Duration(seconds: 2))?.text,
      'Hello world',
    );
  });

  test('ignores garbage', () {
    expect(SrtParser.parse('not a subtitle file'), isEmpty);
  });
}
