import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';

import '../models.dart';
import '../services/selection_service.dart';
import '../theme.dart';
import '../widgets/selection_bar.dart';
import 'viewer_screens.dart';

/// Pick any files from the phone with the system file picker.
class FilesScreen extends StatefulWidget {
  const FilesScreen({super.key});

  @override
  State<FilesScreen> createState() => _FilesScreenState();
}

class _FilesScreenState extends State<FilesScreen> {
  static final List<PendingFile> _picked = [];
  bool _busy = false;

  Future<void> _pick() async {
    setState(() => _busy = true);
    try {
      final result = await FilePicker.platform.pickFiles(allowMultiple: true);
      if (result != null) {
        for (final f in result.files) {
          final path = f.path;
          if (path == null) continue;
          if (_picked.any((e) => e.id == path)) continue;
          final file = PendingFile(
            id: path,
            path: path,
            name: f.name,
            size: f.size,
          );
          _picked.add(file);
          SelectionService.instance.add(file);
        }
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Could not pick files: $e')),
        );
      }
    }
    if (mounted) setState(() => _busy = false);
  }

  Future<void> _delete(PendingFile f) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Delete file?'),
        content: Text(f.name),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Delete'),
          ),
        ],
      ),
    );
    if (ok != true) return;
    try {
      final file = File(f.path);
      if (file.existsSync()) await file.delete();
    } catch (_) {}
    SelectionService.instance.remove(f.id);
    if (mounted) setState(() => _picked.removeWhere((e) => e.id == f.id));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Files')),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _busy ? null : _pick,
        icon: const Icon(Icons.add),
        label: Text(_busy ? 'Loading...' : 'Add files'),
      ),
      body: AnimatedBuilder(
        animation: SelectionService.instance,
        builder: (context, _) {
          if (_picked.isEmpty) {
            return const Center(
              child: Padding(
                padding: EdgeInsets.all(24),
                child: Text(
                  'Tap "Add files" to choose any files (documents, APKs, zips...).',
                  textAlign: TextAlign.center,
                ),
              ),
            );
          }
          return ListView.builder(
            padding: const EdgeInsets.only(bottom: 90),
            itemCount: _picked.length,
            itemBuilder: (context, i) {
              final f = _picked[i];
              final on = SelectionService.instance.contains(f.id);
              return ListTile(
                leading: Checkbox(
                  value: on,
                  onChanged: (v) {
                    if (v == true) {
                      SelectionService.instance.add(f);
                    } else {
                      SelectionService.instance.remove(f.id);
                    }
                  },
                ),
                title: Text(f.name, maxLines: 1, overflow: TextOverflow.ellipsis),
                subtitle: Text(formatSize(f.size)),
                trailing: IconButton(
                  icon: const Icon(Icons.delete_outline),
                  onPressed: () => _delete(f),
                ),
                onTap: () => openFileViewer(context, f.path),
              );
            },
          );
        },
      ),
      bottomNavigationBar: const SelectionBar(),
    );
  }
}
