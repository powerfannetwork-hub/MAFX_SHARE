import 'dart:io';

import 'package:flutter/material.dart';

import '../models.dart';
import '../services/history_service.dart';
import '../theme.dart';
import 'viewer_screens.dart';

/// Everything sent or received. Entries older than 2 months disappear
/// automatically, or you can delete them yourself.
class HistoryScreen extends StatelessWidget {
  const HistoryScreen({super.key});

  String _date(DateTime d) {
    String two(int n) => n.toString().padLeft(2, '0');
    return '${d.year}-${two(d.month)}-${two(d.day)} ${two(d.hour)}:${two(d.minute)}';
  }

  Future<void> _clearAll(BuildContext context) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Clear history?'),
        content: const Text('The list will be cleared. Your files are kept.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Clear'),
          ),
        ],
      ),
    );
    if (ok == true) await HistoryService.instance.clear();
  }

  @override
  Widget build(BuildContext context) {
    final history = HistoryService.instance;
    return Scaffold(
      appBar: AppBar(
        title: const Text('History'),
        actions: [
          IconButton(
            tooltip: 'Clear all',
            icon: const Icon(Icons.delete_sweep_outlined),
            onPressed: () => _clearAll(context),
          ),
        ],
      ),
      body: ValueListenableBuilder<int>(
        valueListenable: history.changes,
        builder: (context, _, __) {
          final items = history.all();
          if (items.isEmpty) {
            return const Center(child: Text('No transfers yet.'));
          }
          return ListView.builder(
            itemCount: items.length,
            itemBuilder: (context, i) {
              final e = items[i];
              final sent = e.type == 'sent';
              return ListTile(
                leading: CircleAvatar(
                  backgroundColor: alpha(sent ? kGreen : kBlue, 0.25),
                  child: Icon(
                    e.status == 'partial'
                        ? Icons.warning_amber_rounded
                        : (sent ? Icons.arrow_upward : Icons.arrow_downward),
                    color: e.status == 'partial'
                        ? Colors.orangeAccent
                        : (sent ? kGreen : kBlue),
                  ),
                ),
                title: Text(e.name, maxLines: 1, overflow: TextOverflow.ellipsis),
                subtitle: Text(
                  e.status == 'partial'
                      ? '${sent ? 'Sending' : 'Receiving'} interrupted at ${e.percent}% • ${formatSize(e.size)} • ${_date(e.date)}'
                      : '${sent ? 'Sent' : 'Received'} ✓ • ${formatSize(e.size)} • ${_date(e.date)}',
                  style: TextStyle(
                    color: e.status == 'partial' ? Colors.orangeAccent : null,
                  ),
                ),
                trailing: IconButton(
                  icon: const Icon(Icons.delete_outline),
                  onPressed: () => history.remove(e.key),
                ),
                onTap: () {
                  if (e.path.isNotEmpty && File(e.path).existsSync()) {
                    openFileViewer(context, e.path);
                  } else {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('The file is no longer on this phone.')),
                    );
                  }
                },
              );
            },
          );
        },
      ),
    );
  }
}
