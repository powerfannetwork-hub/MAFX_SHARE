import 'package:flutter/material.dart';

import '../widgets/media_browser.dart';
import 'viewer_screens.dart';

class ImagesScreen extends StatelessWidget {
  const ImagesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return MediaBrowser(
      kind: MediaKind.image,
      title: 'Images',
      onOpen: (ctx, asset) async {
        final file = await asset.originFile;
        if (file != null && ctx.mounted) {
          Navigator.push(
            ctx,
            MaterialPageRoute(builder: (_) => ImageViewerScreen(path: file.path)),
          );
        }
      },
    );
  }
}
