import 'package:flutter/material.dart';

import '../services/selection_service.dart';
import '../services/transfer_service.dart';
import '../theme.dart';
import '../widgets/progress_badge.dart';
import '../widgets/selection_bar.dart';
import 'apps_screen.dart';
import 'files_screen.dart';
import 'history_screen.dart';
import 'images_screen.dart';
import 'music_screen.dart';
import 'videos_screen.dart';

/// File selection hub shown after a successful connection.
class SendScreen extends StatelessWidget {
  const SendScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final tiles = <(String, String, IconData, Widget Function())>[
      ('V', 'Videos', Icons.videocam_outlined, () => const VideosScreen()),
      ('I', 'Images', Icons.image_outlined, () => const ImagesScreen()),
      ('A', 'Apps', Icons.apps, () => const AppsScreen()),
      ('M', 'Music', Icons.music_note_outlined, () => const MusicScreen()),
      ('F', 'Files', Icons.folder_outlined, () => const FilesScreen()),
      ('H', 'History', Icons.history, () => const HistoryScreen()),
    ];
    return Scaffold(
      appBar: AppBar(
        title: const Text('Select files'),
        actions: [
          const ProgressBadge(size: 38),
          IconButton(
            tooltip: 'Disconnect',
            icon: const Icon(Icons.link_off),
            onPressed: () async {
              await TransferService.instance.endSession();
              SelectionService.instance.clear();
              if (context.mounted) {
                Navigator.popUntil(context, (r) => r.isFirst);
              }
            },
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: alpha(kGreen, 0.15),
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: kGreen),
            ),
            child: Row(
              children: [
                const Icon(Icons.check_circle, color: kGreen),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(
                    'Connection Successful • ${TransferService.instance.mode.value.label}',
                    style: const TextStyle(fontWeight: FontWeight.w600),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          const Text(
            'Choose what to send, tick the files, then press SEND.',
          ),
          const SizedBox(height: 12),
          for (final t in tiles)
            Container(
              margin: const EdgeInsets.only(bottom: 10),
              decoration: BoxDecoration(
                color: kPanel,
                borderRadius: BorderRadius.circular(18),
              ),
              child: ListTile(
                leading: CircleAvatar(
                  backgroundColor: kBlue,
                  child: Text(
                    t.$1,
                    style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ),
                title: Text(t.$2),
                trailing: Icon(t.$3),
                onTap: () => Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => t.$4()),
                ),
              ),
            ),
        ],
      ),
      bottomNavigationBar: const SelectionBar(),
    );
  }
}
