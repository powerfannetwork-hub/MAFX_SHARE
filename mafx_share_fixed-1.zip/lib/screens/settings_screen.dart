import 'package:flutter/material.dart';

import '../services/storage_service.dart';
import '../theme.dart';

/// Change storage: if the internal memory is full, save received files on
/// the SD Card / Memory Card instead.
class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  late final Future<List<StorageOption>> _options =
      StorageService.instance.options();
  int _index = StorageService.instance.selectedIndex;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Settings')),
      body: FutureBuilder<List<StorageOption>>(
        future: _options,
        builder: (context, snap) {
          if (!snap.hasData) {
            return const Center(child: CircularProgressIndicator());
          }
          final opts = snap.data!;
          return ListView(
            padding: const EdgeInsets.all(16),
            children: [
              const Text(
                'Change storage',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.w700),
              ),
              const SizedBox(height: 6),
              const Text(
                'Choose where received files are saved. If the internal '
                'storage is full, switch to the SD Card / Memory Card.',
              ),
              const SizedBox(height: 16),
              for (var i = 0; i < opts.length; i++)
                Container(
                  margin: const EdgeInsets.only(bottom: 10),
                  decoration: BoxDecoration(
                    color: kPanel,
                    borderRadius: BorderRadius.circular(18),
                    border: Border.all(
                      color: i == _index ? kGreen : Colors.transparent,
                    ),
                  ),
                  child: ListTile(
                    leading: Icon(
                      i == _index
                          ? Icons.radio_button_checked
                          : Icons.radio_button_unchecked,
                      color: i == _index ? kGreen : null,
                    ),
                    title: Text(opts[i].label),
                    subtitle: Text(opts[i].path),
                    onTap: () async {
                      await StorageService.instance.setSelectedIndex(i);
                      setState(() => _index = i);
                    },
                  ),
                ),
              if (opts.length == 1)
                const Padding(
                  padding: EdgeInsets.only(top: 8),
                  child: Text('No SD Card / Memory Card was found on this phone.'),
                ),
            ],
          );
        },
      ),
    );
  }
}
