import 'package:flutter/material.dart';

import '../widgets/media_browser.dart';
import 'viewer_screens.dart';

class VideosScreen extends StatelessWidget {
  const VideosScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return MediaBrowser(
      kind: MediaKind.video,
      title: 'Videos',
      onOpen: (ctx, asset) async {
        final file = await asset.originFile;
        if (file != null && ctx.mounted) {
          Navigator.push(
            ctx,
            MaterialPageRoute(builder: (_) => PlayerScreen(path: file.path)),
          );
        }
      },
    );
  }
}
