import 'dart:async';
import 'dart:io';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:path/path.dart' as p;
import 'package:video_player/video_player.dart';

import '../theme.dart';

const _videoExt = {'.mp4', '.mkv', '.3gp', '.webm', '.mov', '.avi', '.m4v'};
const _audioExt = {'.mp3', '.m4a', '.aac', '.wav', '.ogg', '.flac', '.opus', '.amr'};
const _imageExt = {'.jpg', '.jpeg', '.png', '.gif', '.webp', '.bmp'};

/// Opens a file inside the app (video / music player or image viewer).
void openFileViewer(BuildContext context, String path) {
  final ext = p.extension(path).toLowerCase();
  Widget? page;
  if (_videoExt.contains(ext)) {
    page = PlayerScreen(path: path);
  } else if (_audioExt.contains(ext)) {
    page = PlayerScreen(path: path, audio: true);
  } else if (_imageExt.contains(ext)) {
    page = ImageViewerScreen(path: path);
  }
  if (page == null) {
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(
        const SnackBar(content: Text('This file type cannot be opened here.')),
      );
    return;
  }
  final target = page;
  Navigator.push(context, MaterialPageRoute(builder: (_) => target));
}

class PlayerScreen extends StatefulWidget {
  const PlayerScreen({super.key, required this.path, this.audio = false});

  final String path;
  final bool audio;

  @override
  State<PlayerScreen> createState() => _PlayerScreenState();
}

enum _Orient { auto, landscape, portrait }

class _PlayerScreenState extends State<PlayerScreen>
    with WidgetsBindingObserver {
  late final VideoPlayerController _c =
      VideoPlayerController.file(File(widget.path));
  bool _ready = false;
  String? _error;

  bool _showControls = true;
  Timer? _hideTimer;
  _Orient _orient = _Orient.auto;

  // --- seeking: only the LAST requested position is sent to the player, and
  // only after the previous seek finished. This stops seeks piling up, which
  // is what makes dragging / swiping feel slow.
  Duration? _pendingSeek;
  bool _seeking = false;

  // --- swipe to seek
  bool _swiping = false;
  Duration _swipeStart = Duration.zero;
  Duration _swipeTarget = Duration.zero;
  double _swipeDx = 0;

  // --- slider scrubbing
  bool _scrubbing = false;
  double _scrubMs = 0;

  String? _flash; // "+10s" / "-10s" hint
  Timer? _flashTimer;
  double _speed = 1.0;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    if (!widget.audio) {
      // Follow the phone's sensor (auto-rotate) while the player is open.
      SystemChrome.setPreferredOrientations(DeviceOrientation.values);
    }
    _init();
  }

  Future<void> _init() async {
    try {
      await _c.initialize();
      if (!mounted) return;
      setState(() => _ready = true);
      if (!widget.audio && _c.value.aspectRatio > 1.0) {
        // Landscape video: turn the screen sideways, like video apps do.
        _setOrient(_Orient.landscape);
      }
      await _c.play();
      _scheduleHide();
    } catch (_) {
      if (mounted) setState(() => _error = 'This file cannot be played.');
    }
  }

  @override
  void didChangeMetrics() {
    if (!mounted || widget.audio) return;
    final size = WidgetsBinding.instance.platformDispatcher.views.first.physicalSize;
    final landscape = size.width > size.height;
    SystemChrome.setEnabledSystemUIMode(
      landscape ? SystemUiMode.immersiveSticky : SystemUiMode.edgeToEdge,
    );
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _hideTimer?.cancel();
    _flashTimer?.cancel();
    _c.dispose();
    if (!widget.audio) {
      SystemChrome.setPreferredOrientations(const <DeviceOrientation>[]);
      SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    }
    super.dispose();
  }

  // ------------------------------------------------------------ helpers

  Duration get _duration => _c.value.duration;

  Duration _clamp(Duration d) {
    if (d < Duration.zero) return Duration.zero;
    if (d > _duration) return _duration;
    return d;
  }

  void _requestSeek(Duration target) {
    _pendingSeek = _clamp(target);
    if (!_seeking) _drainSeeks();
  }

  Future<void> _drainSeeks() async {
    _seeking = true;
    try {
      while (_pendingSeek != null) {
        final t = _pendingSeek!;
        _pendingSeek = null;
        await _c.seekTo(t);
      }
    } catch (_) {
      // ignore a failed seek, the next one will work
    } finally {
      _seeking = false;
    }
  }

  void _skip(int seconds) {
    final base = _pendingSeek ?? _c.value.position;
    _requestSeek(base + Duration(seconds: seconds));
    _flashText(seconds > 0 ? '+${seconds}s' : '${seconds}s');
  }

  void _flashText(String t) {
    _flashTimer?.cancel();
    setState(() => _flash = t);
    _flashTimer = Timer(const Duration(milliseconds: 700), () {
      if (mounted) setState(() => _flash = null);
    });
  }

  void _scheduleHide() {
    _hideTimer?.cancel();
    _hideTimer = Timer(const Duration(seconds: 3), () {
      if (mounted && _c.value.isPlaying && !_scrubbing && !_swiping) {
        setState(() => _showControls = false);
      }
    });
  }

  void _toggleControls() {
    setState(() => _showControls = !_showControls);
    if (_showControls) _scheduleHide();
  }

  void _setOrient(_Orient o) {
    _orient = o;
    switch (o) {
      case _Orient.auto:
        SystemChrome.setPreferredOrientations(DeviceOrientation.values);
      case _Orient.landscape:
        SystemChrome.setPreferredOrientations(const [
          DeviceOrientation.landscapeLeft,
          DeviceOrientation.landscapeRight,
        ]);
      case _Orient.portrait:
        SystemChrome.setPreferredOrientations(const [
          DeviceOrientation.portraitUp,
        ]);
    }
    if (mounted) setState(() {});
  }

  void _cycleOrient() {
    const order = [_Orient.auto, _Orient.landscape, _Orient.portrait];
    _setOrient(order[(order.indexOf(_orient) + 1) % order.length]);
  }

  String _fmt(Duration d) {
    final h = d.inHours;
    final m = d.inMinutes.remainder(60).toString().padLeft(2, '0');
    final s = d.inSeconds.remainder(60).toString().padLeft(2, '0');
    return h > 0 ? '$h:$m:$s' : '${d.inMinutes}:$s';
  }

  // ------------------------------------------------------------- gestures

  Offset _doubleTapAt = Offset.zero;

  void _onDoubleTap(double width) {
    _skip(_doubleTapAt.dx < width / 2 ? -10 : 10);
  }

  void _swipeBegin() {
    _swiping = true;
    _swipeDx = 0;
    _swipeStart = _pendingSeek ?? _c.value.position;
    _swipeTarget = _swipeStart;
  }

  void _swipeUpdate(double dx, double width) {
    _swipeDx += dx;
    // A swipe over the full screen width moves 2 minutes (or the whole video
    // if it is shorter).
    final span = math.min(_duration.inMilliseconds, 120000);
    final deltaMs = (_swipeDx / width * span).round();
    _swipeTarget = _clamp(_swipeStart + Duration(milliseconds: deltaMs));
    setState(() {});
  }

  void _swipeEnd() {
    _requestSeek(_swipeTarget);
    setState(() => _swiping = false);
    _scheduleHide();
  }

  // ---------------------------------------------------------------- build

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: _error != null
          ? SafeArea(child: Center(child: Text(_error!)))
          : !_ready
              ? const Center(child: CircularProgressIndicator())
              : LayoutBuilder(builder: (context, box) => _player(box.maxWidth)),
    );
  }

  Widget _player(double width) {
    return Stack(
      fit: StackFit.expand,
      children: [
        GestureDetector(
          behavior: HitTestBehavior.opaque,
          onTap: _toggleControls,
          onDoubleTapDown: (d) => _doubleTapAt = d.localPosition,
          onDoubleTap: () => _onDoubleTap(width),
          onHorizontalDragStart: (_) => _swipeBegin(),
          onHorizontalDragUpdate: (d) => _swipeUpdate(d.delta.dx, width),
          onHorizontalDragEnd: (_) => _swipeEnd(),
          onHorizontalDragCancel: _swipeEnd,
          child: Center(
            child: widget.audio
                ? Icon(Icons.music_note, size: 120, color: alpha(kBlue, 0.9))
                : AspectRatio(
                    aspectRatio: _c.value.aspectRatio,
                    child: VideoPlayer(_c),
                  ),
          ),
        ),
        if (_swiping)
          Center(child: _hint('${_fmt(_swipeTarget)} / ${_fmt(_duration)}')),
        if (_flash != null && !_swiping) Center(child: _hint(_flash!)),
        if (_showControls) ...[
          Positioned(top: 0, left: 0, right: 0, child: _topBar()),
          Positioned(bottom: 0, left: 0, right: 0, child: _bottomBar()),
        ],
      ],
    );
  }

  Widget _hint(String text) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 10),
        decoration: BoxDecoration(
          color: Colors.black54,
          borderRadius: BorderRadius.circular(14),
        ),
        child: Text(
          text,
          style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w700),
        ),
      );

  Widget _topBar() {
    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [Colors.black87, Colors.transparent],
        ),
      ),
      child: SafeArea(
        bottom: false,
        child: Row(
          children: [
            IconButton(
              icon: const Icon(Icons.arrow_back),
              onPressed: () => Navigator.pop(context),
            ),
            Expanded(
              child: Text(
                p.basename(widget.path),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(fontSize: 16),
              ),
            ),
            if (!widget.audio)
              IconButton(
                tooltip: 'Rotate',
                icon: Icon(
                  switch (_orient) {
                    _Orient.auto => Icons.screen_rotation,
                    _Orient.landscape => Icons.stay_current_landscape,
                    _Orient.portrait => Icons.stay_current_portrait,
                  },
                ),
                onPressed: () {
                  _cycleOrient();
                  _scheduleHide();
                },
              ),
            PopupMenuButton<double>(
              tooltip: 'Speed',
              color: kPanel,
              icon: const Icon(Icons.speed),
              onSelected: (v) {
                _speed = v;
                _c.setPlaybackSpeed(v);
                _flashText('${v}x');
              },
              itemBuilder: (_) => [
                for (final v in const [0.5, 0.75, 1.0, 1.25, 1.5, 2.0])
                  CheckedPopupMenuItem<double>(
                    value: v,
                    checked: v == _speed,
                    child: Text('${v}x'),
                  ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _bottomBar() {
    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.bottomCenter,
          end: Alignment.topCenter,
          colors: [Colors.black87, Colors.transparent],
        ),
      ),
      child: SafeArea(
        top: false,
        child: ValueListenableBuilder<VideoPlayerValue>(
          valueListenable: _c,
          builder: (context, v, _) {
            final durMs = math.max(1, v.duration.inMilliseconds).toDouble();
            final posMs = (_scrubbing ? _scrubMs : v.position.inMilliseconds.toDouble())
                .clamp(0.0, durMs);
            return Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Row(
                  children: [
                    const SizedBox(width: 16),
                    Text(_fmt(Duration(milliseconds: posMs.round()))),
                    Expanded(
                      child: Slider(
                        value: posMs,
                        max: durMs,
                        activeColor: kGreen,
                        inactiveColor: kPanel,
                        onChangeStart: (x) {
                          _scrubbing = true;
                          _scrubMs = x;
                          _hideTimer?.cancel();
                        },
                        onChanged: (x) {
                          setState(() => _scrubMs = x);
                          _requestSeek(Duration(milliseconds: x.round()));
                        },
                        onChangeEnd: (x) {
                          _requestSeek(Duration(milliseconds: x.round()));
                          setState(() => _scrubbing = false);
                          _scheduleHide();
                        },
                      ),
                    ),
                    Text(_fmt(v.duration)),
                    const SizedBox(width: 16),
                  ],
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    IconButton(
                      iconSize: 36,
                      icon: const Icon(Icons.replay_10),
                      onPressed: () {
                        _skip(-10);
                        _scheduleHide();
                      },
                    ),
                    const SizedBox(width: 12),
                    IconButton.filled(
                      iconSize: 44,
                      icon: Icon(v.isPlaying ? Icons.pause : Icons.play_arrow),
                      onPressed: () async {
                        if (v.isPlaying) {
                          await _c.pause();
                        } else {
                          // At the very end: start again from the beginning.
                          if (v.position >= v.duration) {
                            _requestSeek(Duration.zero);
                          }
                          await _c.play();
                          _scheduleHide();
                        }
                      },
                    ),
                    const SizedBox(width: 12),
                    IconButton(
                      iconSize: 36,
                      icon: const Icon(Icons.forward_10),
                      onPressed: () {
                        _skip(10);
                        _scheduleHide();
                      },
                    ),
                  ],
                ),
                const SizedBox(height: 8),
              ],
            );
          },
        ),
      ),
    );
  }
}

class ImageViewerScreen extends StatelessWidget {
  const ImageViewerScreen({super.key, required this.path});
  final String path;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        title: Text(
          p.basename(path),
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
        ),
      ),
      body: InteractiveViewer(
        maxScale: 6,
        child: Center(child: Image.file(File(path))),
      ),
    );
  }
}
