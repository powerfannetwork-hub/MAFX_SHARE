import 'dart:typed_data';

/// Wire format of one chunk on a TCP stream:
///
///   [4-byte uint32 chunkIndex][4-byte uint32 dataLength][chunk bytes]
///
/// (big-endian). The byte offset of a chunk inside the file is
/// `chunkIndex * chunkSize`, so chunks may arrive in any order and on any
/// stream. A header with chunkIndex 0xFFFFFFFF and length 0 is an
/// "end of file binding" marker: the next bytes on that socket are a new
/// handshake line (see TransferService).
class ChunkCodec {
  ChunkCodec._();

  static const int headerSize = 8;
  static const int endMarkerIndex = 0xFFFFFFFF;

  static Uint8List encodeHeader(int chunkIndex, int dataLength) {
    final b = ByteData(headerSize)
      ..setUint32(0, chunkIndex, Endian.big)
      ..setUint32(4, dataLength, Endian.big);
    return b.buffer.asUint8List();
  }

  static Uint8List endMarker() => encodeHeader(endMarkerIndex, 0);

  static int chunkIndexOf(Uint8List header) =>
      ByteData.sublistView(header).getUint32(0, Endian.big);

  static int dataLengthOf(Uint8List header) =>
      ByteData.sublistView(header).getUint32(4, Endian.big);

  static int chunkCount(int fileSize, int chunkSize) =>
      fileSize <= 0 ? 0 : (fileSize + chunkSize - 1) ~/ chunkSize;

  static int offsetOf(int chunkIndex, int chunkSize) => chunkIndex * chunkSize;

  /// Length of chunk [chunkIndex] (the last chunk may be shorter).
  static int lengthOf(int chunkIndex, int fileSize, int chunkSize) {
    final rest = fileSize - chunkIndex * chunkSize;
    return rest < chunkSize ? rest : chunkSize;
  }
}
