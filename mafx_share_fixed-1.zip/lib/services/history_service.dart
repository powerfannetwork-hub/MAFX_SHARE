import 'package:flutter/foundation.dart';
import 'package:hive/hive.dart';

import '../models.dart';

/// Saves every sent / received file. Entries older than 2 months are removed
/// automatically when the app starts.
class HistoryService {
  HistoryService._();
  static final HistoryService instance = HistoryService._();

  late Box _box;
  final ValueNotifier<int> changes = ValueNotifier<int>(0);

  Future<void> init() async {
    _box = await Hive.openBox('history');
    await purgeOld();
  }

  Future<void> purgeOld() async {
    final limit =
        DateTime.now().subtract(const Duration(days: 60)).millisecondsSinceEpoch;
    final old = <dynamic>[];
    for (final key in _box.keys) {
      final v = _box.get(key);
      if (v is Map) {
        final date = v['date'];
        if (date is int && date < limit) old.add(key);
      }
    }
    if (old.isNotEmpty) await _box.deleteAll(old);
  }

  Future<void> add({
    required String name,
    required int size,
    required String type,
    required String path,
    String status = 'done',
    int percent = 100,
  }) async {
    await _box.add({
      'name': name,
      'size': size,
      'type': type,
      'path': path,
      'status': status,
      'percent': percent,
      'date': DateTime.now().millisecondsSinceEpoch,
    });
    changes.value++;
  }

  List<HistoryEntry> all() {
    final list = <HistoryEntry>[];
    for (final key in _box.keys) {
      final v = _box.get(key);
      if (v is! Map) continue;
      list.add(HistoryEntry(
        key: key,
        name: (v['name'] ?? '').toString(),
        size: (v['size'] is int) ? v['size'] as int : 0,
        date: DateTime.fromMillisecondsSinceEpoch(
            (v['date'] is int) ? v['date'] as int : 0),
        type: (v['type'] ?? 'sent').toString(),
        path: (v['path'] ?? '').toString(),
        status: (v['status'] ?? 'done').toString(),
        percent: (v['percent'] is int) ? v['percent'] as int : 100,
      ));
    }
    list.sort((a, b) => b.date.compareTo(a.date));
    return list;
  }

  Future<void> remove(dynamic key) async {
    await _box.delete(key);
    changes.value++;
  }

  Future<void> clear() async {
    await _box.clear();
    changes.value++;
  }
}
