import 'dart:convert';
import 'dart:io';

import 'package:path_provider/path_provider.dart';

/// Remembers (on disk) what is needed to CONTINUE an interrupted transfer:
///  - partials: files this phone was receiving (which chunks are already in)
///  - pending : the files this phone was sending when the link broke
class PartialStore {
  PartialStore._();
  static final PartialStore instance = PartialStore._();

  Map<String, dynamic> _partials = {};
  Map<String, dynamic>? _pending;
  File? _file;

  Future<void> init() async {
    final dir = await getApplicationDocumentsDirectory();
    _file = File('${dir.path}/mafx_resume.json');
    try {
      if (await _file!.exists()) {
        final j = jsonDecode(await _file!.readAsString());
        if (j is Map) {
          final p = j['partials'];
          if (p is Map) _partials = Map<String, dynamic>.from(p);
          final s = j['pending'];
          if (s is Map) _pending = Map<String, dynamic>.from(s);
        }
      }
    } catch (_) {}
  }

  Future<void> _save() async {
    try {
      await _file?.writeAsString(
        jsonEncode({'partials': _partials, 'pending': _pending}),
      );
    } catch (_) {}
  }

  Map<String, dynamic>? partial(String key) {
    final v = _partials[key];
    return v is Map ? Map<String, dynamic>.from(v) : null;
  }

  Future<void> putPartials(Map<String, Map<String, dynamic>> items) async {
    if (items.isEmpty) return;
    _partials.addAll(items);
    await _save();
  }

  Future<void> removePartial(String key) async {
    if (_partials.remove(key) != null) await _save();
  }

  Map<String, dynamic>? get pending => _pending;

  Future<void> setPending(Map<String, dynamic>? v) async {
    _pending = v;
    await _save();
  }
}
