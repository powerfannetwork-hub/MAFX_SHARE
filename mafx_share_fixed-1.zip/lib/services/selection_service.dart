import 'package:flutter/foundation.dart';

import '../models.dart';

/// Files the user ticked in any list (Videos, Images, Music, Files...).
class SelectionService extends ChangeNotifier {
  SelectionService._();
  static final SelectionService instance = SelectionService._();

  final Map<String, PendingFile> _items = {};

  bool contains(String id) => _items.containsKey(id);
  bool get isEmpty => _items.isEmpty;
  int get count => _items.length;
  int get totalSize => _items.values.fold<int>(0, (s, f) => s + f.size);
  List<PendingFile> get items => _items.values.toList();

  void add(PendingFile f) {
    _items[f.id] = f;
    notifyListeners();
  }

  void remove(String id) {
    if (_items.remove(id) != null) notifyListeners();
  }

  void clear() {
    if (_items.isEmpty) return;
    _items.clear();
    notifyListeners();
  }
}
