import 'dart:io';

import 'package:hive/hive.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';

class StorageOption {
  const StorageOption(this.label, this.path);
  final String label;
  final String path;
}

/// Decides where received files are saved (internal storage or SD card).
class StorageService {
  StorageService._();
  static final StorageService instance = StorageService._();

  late Box _box;

  Future<void> init() async {
    _box = await Hive.openBox('settings');
  }

  int get selectedIndex {
    final v = _box.get('storageIndex', defaultValue: 0);
    return v is int ? v : 0;
  }

  Future<void> setSelectedIndex(int i) => _box.put('storageIndex', i);

  Future<List<StorageOption>> options() async {
    List<Directory> dirs = [];
    try {
      dirs = await getExternalStorageDirectories() ?? [];
    } catch (_) {}
    if (dirs.isEmpty) {
      final d = await getApplicationDocumentsDirectory();
      return [StorageOption('Internal storage', d.path)];
    }
    return [
      for (var i = 0; i < dirs.length; i++)
        StorageOption(
          i == 0
              ? 'Internal storage'
              : (dirs.length == 2 ? 'SD Card / Memory Card' : 'SD Card $i'),
          dirs[i].path,
        ),
    ];
  }

  Future<Directory> receiveDir() async {
    final opts = await options();
    var i = selectedIndex;
    if (i >= opts.length) i = 0;
    final dir = Directory(p.join(opts[i].path, 'MAFX SHARE'));
    if (!dir.existsSync()) dir.createSync(recursive: true);
    return dir;
  }
}
