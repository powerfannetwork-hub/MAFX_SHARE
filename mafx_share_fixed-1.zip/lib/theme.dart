import 'package:flutter/material.dart';

const kBg = Color(0xFF202024);
const kPanel = Color(0xFF2B2B31);
const kBlue = Color(0xFF2196F3);
const kGreen = Color(0xFF00D18B);

Color alpha(Color c, double opacity) => c.withAlpha((opacity * 255).round());

ThemeData buildTheme() => ThemeData(
      useMaterial3: true,
      brightness: Brightness.dark,
      scaffoldBackgroundColor: kBg,
      colorScheme: const ColorScheme.dark(
        primary: kBlue,
        secondary: kGreen,
        surface: kBg,
      ),
      appBarTheme: const AppBarTheme(
        backgroundColor: kBg,
        elevation: 0,
        centerTitle: true,
      ),
    );

String formatSize(int bytes) {
  if (bytes < 1024) return '$bytes B';
  const units = ['KB', 'MB', 'GB', 'TB'];
  double v = bytes / 1024;
  var i = 0;
  while (v >= 1024 && i < units.length - 1) {
    v /= 1024;
    i++;
  }
  return '${v.toStringAsFixed(v < 10 ? 2 : 1)} ${units[i]}';
}

String formatSpeed(double bytesPerSecond) =>
    '${formatSize(bytesPerSecond.round())}/s';

String formatDuration(int seconds) {
  final m = seconds ~/ 60;
  final s = seconds % 60;
  return '$m:${s.toString().padLeft(2, '0')}';
}
