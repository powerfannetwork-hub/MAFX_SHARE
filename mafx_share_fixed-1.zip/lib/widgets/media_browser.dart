import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:path/path.dart' as p;
import 'package:photo_manager/photo_manager.dart';

import '../models.dart';
import '../services/selection_service.dart';
import '../theme.dart';
import 'selection_bar.dart';

enum MediaKind { video, image, audio }

/// Lists real media from the phone with checkboxes. Used by the Videos,
/// Images and Music screens.
class MediaBrowser extends StatefulWidget {
  const MediaBrowser({
    super.key,
    required this.kind,
    required this.title,
    required this.onOpen,
  });

  final MediaKind kind;
  final String title;
  final Future<void> Function(BuildContext context, AssetEntity asset) onOpen;

  @override
  State<MediaBrowser> createState() => _MediaBrowserState();
}

class _MediaBrowserState extends State<MediaBrowser> {
  List<AssetEntity> _assets = [];
  bool _loading = true;
  String? _error;

  RequestType get _type {
    switch (widget.kind) {
      case MediaKind.video:
        return RequestType.video;
      case MediaKind.image:
        return RequestType.image;
      case MediaKind.audio:
        return RequestType.audio;
    }
  }

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final ps = await PhotoManager.requestPermissionExtend(
        requestOption: PermissionRequestOption(
          androidPermission: AndroidPermission(
            type: RequestType.all,
            mediaLocation: false,
          ),
        ),
      );
      if (!ps.hasAccess) {
        if (!mounted) return;
        setState(() {
          _loading = false;
          _error = 'Allow access to your media to see your files.';
        });
        return;
      }
      final opt = FilterOptionGroup(
        orders: [OrderOption(type: OrderOptionType.createDate, asc: false)],
      );
      opt.setOption(
        AssetType.video,
        FilterOption(
          needTitle: true,
          durationConstraint: DurationConstraint(allowNullable: true),
        ),
      );
      opt.setOption(
        AssetType.audio,
        FilterOption(
          needTitle: true,
          durationConstraint: DurationConstraint(allowNullable: true),
        ),
      );
      final paths = await PhotoManager.getAssetPathList(
        type: _type,
        onlyAll: true,
        filterOption: opt,
      );
      var list = <AssetEntity>[];
      if (paths.isNotEmpty) {
        list = await paths.first.getAssetListRange(start: 0, end: 5000);
      }
      if (!mounted) return;
      setState(() {
        _assets = list;
        _loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _loading = false;
        _error = 'Could not load files: $e';
      });
    }
  }

  void _snack(String msg) {
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(msg)));
  }

  Future<void> _toggle(AssetEntity a) async {
    final sel = SelectionService.instance;
    if (sel.contains(a.id)) {
      sel.remove(a.id);
      return;
    }
    final file = await a.originFile;
    if (file == null) {
      _snack('Cannot read this file.');
      return;
    }
    sel.add(PendingFile(
      id: a.id,
      path: file.path,
      name: p.basename(file.path),
      size: await file.length(),
    ));
  }

  Future<void> _deleteSelected(List<AssetEntity> chosen) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Delete files?'),
        content: Text('Delete ${chosen.length} selected file(s) from this phone?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Delete'),
          ),
        ],
      ),
    );
    if (ok != true) return;
    try {
      final deleted = await PhotoManager.editor
          .deleteWithIds([for (final a in chosen) a.id]);
      final gone = deleted.toSet();
      for (final id in gone) {
        SelectionService.instance.remove(id);
      }
      if (!mounted) return;
      setState(() => _assets.removeWhere((a) => gone.contains(a.id)));
    } catch (e) {
      _snack('Delete failed: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: SelectionService.instance,
      builder: (context, _) {
        final sel = SelectionService.instance;
        final selectedHere = _assets.where((a) => sel.contains(a.id)).toList();
        return Scaffold(
          appBar: AppBar(
            title: Text(widget.title),
            actions: [
              if (selectedHere.isNotEmpty)
                IconButton(
                  tooltip: 'Delete',
                  icon: const Icon(Icons.delete_outline),
                  onPressed: () => _deleteSelected(selectedHere),
                ),
            ],
          ),
          body: _body(sel),
          bottomNavigationBar: const SelectionBar(),
        );
      },
    );
  }

  Widget _body(SelectionService sel) {
    if (_loading) return const Center(child: CircularProgressIndicator());
    if (_error != null) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(_error!, textAlign: TextAlign.center),
              const SizedBox(height: 16),
              FilledButton(onPressed: _load, child: const Text('Try again')),
              TextButton(
                onPressed: PhotoManager.openSetting,
                child: const Text('Open settings'),
              ),
            ],
          ),
        ),
      );
    }
    if (_assets.isEmpty) {
      return const Center(child: Text('Nothing found on this phone.'));
    }
    if (widget.kind == MediaKind.audio) {
      return ListView.builder(
        itemCount: _assets.length,
        itemBuilder: (context, i) {
          final a = _assets[i];
          final on = sel.contains(a.id);
          return ListTile(
            key: ValueKey(a.id),
            leading: Container(
              width: 44,
              height: 44,
              decoration: BoxDecoration(
                color: alpha(kBlue, 0.2),
                borderRadius: BorderRadius.circular(12),
              ),
              child: const Icon(Icons.music_note, color: kBlue),
            ),
            title: Text(a.title ?? 'Audio', maxLines: 1, overflow: TextOverflow.ellipsis),
            subtitle: Text(formatDuration(a.duration)),
            trailing: Checkbox(value: on, onChanged: (_) => _toggle(a)),
            onTap: () => widget.onOpen(context, a),
            onLongPress: () => _toggle(a),
          );
        },
      );
    }
    return GridView.builder(
      padding: const EdgeInsets.all(4),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 3,
        mainAxisSpacing: 4,
        crossAxisSpacing: 4,
      ),
      itemCount: _assets.length,
      itemBuilder: (context, i) {
        final a = _assets[i];
        final on = sel.contains(a.id);
        return GestureDetector(
          key: ValueKey(a.id),
          onTap: () => widget.onOpen(context, a),
          onLongPress: () => _toggle(a),
          child: Stack(
            fit: StackFit.expand,
            children: [
              _Thumb(asset: a),
              if (on) Container(color: alpha(kBlue, 0.3)),
              if (widget.kind == MediaKind.video)
                Positioned(
                  left: 6,
                  bottom: 6,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                    decoration: BoxDecoration(
                      color: Colors.black54,
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Text(
                      formatDuration(a.duration),
                      style: const TextStyle(fontSize: 11),
                    ),
                  ),
                ),
              Positioned(
                right: 0,
                top: 0,
                child: Checkbox(
                  value: on,
                  visualDensity: VisualDensity.compact,
                  onChanged: (_) => _toggle(a),
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

class _Thumb extends StatefulWidget {
  const _Thumb({required this.asset});
  final AssetEntity asset;

  @override
  State<_Thumb> createState() => _ThumbState();
}

class _ThumbState extends State<_Thumb> {
  late final Future<Uint8List?> _future =
      widget.asset.thumbnailDataWithSize(const ThumbnailSize(260, 260));

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<Uint8List?>(
      future: _future,
      builder: (context, snap) {
        final data = snap.data;
        if (data == null) return Container(color: kPanel);
        return Image.memory(data, fit: BoxFit.cover, gaplessPlayback: true);
      },
    );
  }
}
