import 'package:flutter/material.dart';

import '../models.dart';
import '../screens/transfer_screen.dart';
import '../services/transfer_service.dart';
import '../theme.dart';

/// Round sync badge (circle with two arrows). Only shown once two phones are
/// connected. Shows transfer progress and opens the transfer screen.
class ProgressBadge extends StatelessWidget {
  const ProgressBadge({super.key, this.size = 52});
  final double size;

  @override
  Widget build(BuildContext context) {
    final svc = TransferService.instance;
    return ValueListenableBuilder<PairedPeer?>(
      valueListenable: svc.pairedPeer,
      builder: (context, peer, _) {
        if (peer == null) return const SizedBox.shrink();
        return ValueListenableBuilder<TransferProgress?>(
          valueListenable: svc.progress,
          builder: (context, pr, _) {
            final active = pr != null && !pr.finished;
            return GestureDetector(
              onTap: () => Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const TransferScreen()),
              ),
              child: Container(
                width: size,
                height: size,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: alpha(kGreen, 0.18),
                  border: Border.all(color: kGreen, width: 2),
                  boxShadow: [
                    BoxShadow(color: alpha(kGreen, 0.35), blurRadius: 12),
                  ],
                ),
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                    if (pr != null)
                      SizedBox(
                        width: size - 8,
                        height: size - 8,
                        child: CircularProgressIndicator(
                          value: pr.fraction,
                          strokeWidth: 3,
                          color: kBlue,
                          backgroundColor: Colors.transparent,
                        ),
                      ),
                    Icon(
                      Icons.sync,
                      color: active ? kGreen : Colors.white,
                      size: size * 0.5,
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }
}
