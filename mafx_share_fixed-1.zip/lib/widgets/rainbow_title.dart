import 'package:flutter/material.dart';

/// MAFX SHARE title whose colours keep cycling through the whole rainbow.
class RainbowTitle extends StatefulWidget {
  const RainbowTitle({super.key, this.size = 48});
  final double size;

  @override
  State<RainbowTitle> createState() => _RainbowTitleState();
}

class _RainbowTitleState extends State<RainbowTitle>
    with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(
    vsync: this,
    duration: const Duration(seconds: 6),
  )..repeat();

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  Color _hue(double deg) => HSVColor.fromAHSV(1, deg % 360, 0.85, 1).toColor();

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _c,
      builder: (context, _) {
        final base = _c.value * 360;
        final gradient = LinearGradient(
          colors: [for (var i = 0; i <= 5; i++) _hue(base + i * 60)],
        );
        Widget word(String t) => ShaderMask(
              blendMode: BlendMode.srcIn,
              shaderCallback: (rect) => gradient.createShader(rect),
              child: Text(
                t,
                style: TextStyle(
                  fontSize: widget.size,
                  height: 0.95,
                  fontWeight: FontWeight.w900,
                  fontStyle: FontStyle.italic,
                  letterSpacing: -2,
                  color: Colors.white,
                ),
              ),
            );
        return Column(
          mainAxisSize: MainAxisSize.min,
          children: [word('MAFX'), word('SHARE')],
        );
      },
    );
  }
}
