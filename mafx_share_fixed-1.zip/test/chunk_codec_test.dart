import 'package:flutter_test/flutter_test.dart';
import 'package:share/services/chunk_codec.dart';

void main() {
  test('header round trip', () {
    final h = ChunkCodec.encodeHeader(123456, 4194304);
    expect(h.length, 8);
    expect(ChunkCodec.chunkIndexOf(h), 123456);
    expect(ChunkCodec.dataLengthOf(h), 4194304);
  });

  test('end marker', () {
    final h = ChunkCodec.endMarker();
    expect(ChunkCodec.chunkIndexOf(h), ChunkCodec.endMarkerIndex);
    expect(ChunkCodec.dataLengthOf(h), 0);
  });

  test('chunk math for a 10 GB file (8 MiB chunks)', () {
    const size = 10 * 1024 * 1024 * 1024 + 5;
    const chunk = 8 * 1024 * 1024;
    final n = ChunkCodec.chunkCount(size, chunk);
    expect(n, 1281);
    expect(ChunkCodec.lengthOf(n - 1, size, chunk), 5);
    expect(ChunkCodec.offsetOf(n - 1, chunk), 10 * 1024 * 1024 * 1024);
    var total = 0;
    for (var i = 0; i < n; i++) {
      total += ChunkCodec.lengthOf(i, size, chunk);
    }
    expect(total, size);
  });

  test('empty file has no chunks', () {
    expect(ChunkCodec.chunkCount(0, 4194304), 0);
  });
}
