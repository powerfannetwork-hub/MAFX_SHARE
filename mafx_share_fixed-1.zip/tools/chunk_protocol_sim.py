import random, struct, json, os, hashlib

END = 0xFFFFFFFF

def chunk_count(size, cs): return 0 if size <= 0 else (size + cs - 1)//cs
def length_of(i, size, cs):
    rest = size - i*cs
    return rest if rest < cs else cs

class Incoming:
    def __init__(s, size, cs):
        s.size=size; s.cs=cs; s.count=chunk_count(size,cs)
        s.done_map=bytearray(s.count); s.chunks_done=0; s.done=False
        s.data=bytearray(size)          # stands in for the RandomAccessFile

class Receiver:
    def __init__(s, files): s.incoming=files; s.rx_done=0
    # --- exact port of TransferService._onSocket
    def run_socket(s, packets, bufsize):
        line=bytearray(); hdr=bytearray(8); hdr_len=0
        buf=bytearray(bufsize); buf_len=0; buf_pos=0; pos=0; remaining=0
        chunk_index=0; in_chunk=False; skipping=False; counted=0; file=None
        def flush():
            nonlocal buf_len, counted
            if file is None or buf_len==0: buf_len=0; return
            file.data[buf_pos:buf_pos+buf_len]=buf[:buf_len]
            s.rx_done+=buf_len; counted+=buf_len; buf_len=0
        def put(data, frm, count):
            nonlocal buf_len, buf_pos, pos
            while count>0:
                if buf_len==0: buf_pos=pos
                n=min(len(buf)-buf_len, count)
                buf[buf_len:buf_len+n]=data[frm:frm+n]
                buf_len+=n; frm+=n; count-=n; pos+=n
                if buf_len==len(buf): flush()
        for data in packets:
            off=0
            while off<len(data):
                if file is None:
                    nl=data.find(b'\n', off)
                    if nl<0:
                        line+=data[off:]; off=len(data); continue
                    line+=data[off:nl]; off=nl+1
                    h=json.loads(line.decode()); line=bytearray()
                    file=s.incoming[h['file']]
                    buf_len=0; hdr_len=0; in_chunk=False
                elif not in_chunk:
                    n=min(8-hdr_len, len(data)-off)
                    hdr[hdr_len:hdr_len+n]=data[off:off+n]; hdr_len+=n; off+=n
                    if hdr_len<8: continue
                    hdr_len=0
                    idx,ln=struct.unpack('>II', bytes(hdr))
                    if idx==END: file=None; continue
                    f=file
                    assert idx<f.count and ln==length_of(idx,f.size,f.cs), 'bad chunk'
                    chunk_index=idx; skipping=f.done_map[idx]==1
                    pos=idx*f.cs; remaining=ln; counted=0; in_chunk=True
                else:
                    take=min(len(data)-off, remaining)
                    if not skipping: put(data, off, take)
                    off+=take; remaining-=take
                    if remaining==0:
                        in_chunk=False; f=file
                        if not skipping:
                            flush()
                            if f.done_map[chunk_index]==1: s.rx_done-=counted
                            else:
                                f.done_map[chunk_index]=1; f.chunks_done+=1
                                if f.chunks_done>=f.count: f.done=True
                        counted=0
        return

def fragment(stream, rnd):
    out=[]; i=0
    while i<len(stream):
        n=rnd.choice([1,2,3,7,8,9,50,500,4096,65536]); out.append(bytes(stream[i:i+n])); i+=n
    return out

def trial(seed):
    rnd=random.Random(seed)
    nfiles=rnd.randint(1,4)
    cs=rnd.choice([64,100,1000,4096])
    streams=rnd.choice([1,4,12])
    bufsize=rnd.choice([16,256,1000,5000])
    srcs=[os.urandom(rnd.choice([0,1,cs-1,cs,cs+1,cs*7+13,50000])) for _ in range(nfiles)]
    files=[Incoming(len(b),cs) for b in srcs]
    rx=Receiver(files)
    jobs=[(i,c) for i,b in enumerate(srcs) for c in range(chunk_count(len(b),cs))]
    # duplicates (resend) to test dedupe
    if jobs and rnd.random()<0.5: jobs += rnd.sample(jobs, k=min(3,len(jobs)))
    rnd.shuffle(jobs) if rnd.random()<0.5 else None   # sometimes out of order
    # each stream takes next job (work queue), builds its byte stream
    sock=[bytearray() for _ in range(streams)]; bound=[-1]*streams
    for j,(fi,c) in enumerate(jobs):
        w=j%streams if rnd.random()<0.5 else rnd.randrange(streams)
        if bound[w]!=fi:
            if bound[w]>=0: sock[w]+=struct.pack('>II',END,0)
            sock[w]+=(json.dumps({'file':fi})+'\n').encode(); bound[w]=fi
        ln=length_of(c,len(srcs[fi]),cs)
        sock[w]+=struct.pack('>II',c,ln)+srcs[fi][c*cs:c*cs+ln]
    # sockets are independent, run in random order, with random fragmentation
    order=list(range(streams)); rnd.shuffle(order)
    for w in order:
        if sock[w]: rx.run_socket(fragment(sock[w],rnd), bufsize)
    for i,b in enumerate(srcs):
        assert files[i].done or len(b)==0, f'seed {seed}: file {i} not complete'
        assert bytes(files[i].data)==b, f'seed {seed}: file {i} content differs'
    total=sum(len(b) for b in srcs)
    assert rx.rx_done==total, f'seed {seed}: counter {rx.rx_done} != {total}'

for seed in range(3000): trial(seed)
print("3000 random trials OK: chunks reassemble byte-exact, duplicates ignored, counters exact")
