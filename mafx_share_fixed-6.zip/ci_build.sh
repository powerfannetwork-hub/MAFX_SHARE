#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"

# 1) Android project with package com.mafx.share
flutter create --org com.mafx --project-name share --platforms=android build_app
cp pubspec.yaml build_app/pubspec.yaml
rm -rf build_app/lib build_app/test
cp -r lib build_app/lib
cp android_overrides/AndroidManifest.xml build_app/android/app/src/main/AndroidManifest.xml
# app icon (replaces the default Flutter icon)
cp -r android_overrides/res/. build_app/android/app/src/main/res/
find build_app/android/app/src/main \( -name 'MainActivity.kt' -o -name 'MainActivity.java' \) -delete
mkdir -p build_app/android/app/src/main/kotlin/com/mafx/share
cp android_overrides/*.kt build_app/android/app/src/main/kotlin/com/mafx/share/

# 2) Force compileSdk 36 on all modules (fixes the file_picker error)
mkdir -p "$HOME/.gradle/init.d"
cp android_overrides/force-sdk36.gradle "$HOME/.gradle/init.d/force-sdk36.gradle"

cd build_app
flutter pub get

# 3) Belt and braces: also patch the plugin files directly
PUB="${PUB_CACHE:-$HOME/.pub-cache}"
for f in "$PUB"/hosted/pub.dev/*/android/build.gradle "$PUB"/hosted/pub.dev/*/android/build.gradle.kts; do
  [ -f "$f" ] || continue
  if grep -Eq 'compileSdk(Version)?[ =]+[0-9]+' "$f"; then
    sed -i -E 's/(compileSdk(Version)?[ =]+)[0-9]+/\136/' "$f"
    echo "patched $f"
  fi
done

# 3b) Explicitly turn off R8 minify/shrink in the generated gradle file
GRADLE_FILE=""
for g in android/app/build.gradle.kts android/app/build.gradle; do
  [ -f "$g" ] && GRADLE_FILE="$g"
done
if [ -n "$GRADLE_FILE" ]; then
  case "$GRADLE_FILE" in
    *.kts)
      sed -i -E 's/^([[:space:]]*)signingConfig = signingConfigs\.getByName\("debug"\)/&\n\1isMinifyEnabled = false\n\1isShrinkResources = false/' "$GRADLE_FILE" ;;
    *)
      sed -i -E 's/^([[:space:]]*)signingConfig signingConfigs\.debug/&\n\1minifyEnabled false\n\1shrinkResources false/' "$GRADLE_FILE" ;;
  esac
  echo "--- release block in $GRADLE_FILE:"
  grep -n -B2 -A6 "release {" "$GRADLE_FILE" || true
  grep -Eq 'isMinifyEnabled = false|minifyEnabled false' "$GRADLE_FILE" \
    || echo "WARNING: could not disable minify in $GRADLE_FILE"
fi

# 4) Build
# --no-shrink turns off R8 minify/obfuscation. With R8 on, the ML Kit barcode
# scanner (mobile_scanner) loses classes it needs and the camera fails with
# "genericError ... Attempt to invoke virtual method ... on a null object reference".
flutter build apk --release --no-shrink
