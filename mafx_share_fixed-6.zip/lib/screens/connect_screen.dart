import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:permission_handler/permission_handler.dart';

import '../services/transfer_service.dart';
import 'qr_screen.dart';
import 'scan_qr_screen.dart';

const Color _kPrepGreen = Color(0xFF008752);

/// "Preparations" page (like Xender), shown before the QR screens.
///
/// It only lists what is still wrong:
///   * Turn off hotspot   (our own hotspot is created for the QR code)
///   * Turn off Bluetooth
///   * Open WLAN          (shows the small Wi-Fi switch pop-up)
/// Every row disappears by itself when it is done. When nothing is left the
/// NEXT button turns green.
class ConnectScreen extends StatefulWidget {
  const ConnectScreen({super.key, required this.receive});

  /// true = Received (show QR), false = Send (scan QR).
  final bool receive;

  @override
  State<ConnectScreen> createState() => _ConnectScreenState();
}

class _ConnectScreenState extends State<ConnectScreen>
    with WidgetsBindingObserver {
  static const MethodChannel _sys = MethodChannel('com.mafx.share/apps');
  final svc = TransferService.instance;

  bool _permDone = false;
  bool _denied = false;
  bool _navigated = false;
  bool _polling = false;
  bool _hotspotOn = false;
  bool _bluetoothOn = false;
  bool _wifiOn = true;
  bool _waitingWifi = false;
  Timer? _timer;

  /// Receive: the user's OWN hotspot (set to 5 GHz) may stay on. Send: this
  /// phone must be a Wi-Fi client, so its hotspot has to be off.
  bool get _ready =>
      _permDone &&
      !_bluetoothOn &&
      (widget.receive ? (_wifiOn || _hotspotOn) : (!_hotspotOn && _wifiOn));

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    svc.releaseNetwork(); // start every session on a clean network
    WidgetsBinding.instance.addPostFrameCallback((_) => _run());
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _timer?.cancel();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) _refresh();
  }

  Future<void> _run() async {
    setState(() => _denied = false);
    final result = await [
      Permission.camera,
      Permission.locationWhenInUse,
      Permission.nearbyWifiDevices,
      Permission.notification, // for the "connection kept alive" notice
    ].request();
    if (!mounted) return;

    final cameraOk = result[Permission.camera]?.isGranted ?? false;
    if (!widget.receive && !cameraOk) {
      setState(() => _denied = true);
      return;
    }
    _permDone = true;
    await _refresh();
    _timer ??= Timer.periodic(const Duration(seconds: 1), (_) => _refresh());
  }

  Future<void> _refresh() async {
    if (_polling || !mounted || _navigated || !_permDone) return;
    _polling = true;
    try {
      final hotspot = await svc.isHotspotOn();
      final bt = await svc.isBluetoothOn();
      final wifi = await svc.isWifiOn();
      if (!mounted) return;
      setState(() {
        _hotspotOn = hotspot;
        _bluetoothOn = bt;
        _wifiOn = wifi;
        if (wifi) _waitingWifi = false;
      });
    } finally {
      _polling = false;
    }
  }

  Future<bool> _invoke(String method) async {
    try {
      return (await _sys.invokeMethod<bool>(method)) ?? false;
    } catch (_) {
      return false;
    }
  }

  Future<void> _turnOffHotspot() async {
    final ok = await _invoke('openHotspotSettings');
    if (!ok) _snack('Could not open Settings. Please open it yourself.');
  }

  Future<void> _turnOffBluetooth() async {
    // Older Android can switch it off directly; newer Android needs Settings.
    final done = await _invoke('turnOffBluetooth');
    if (!done) {
      final ok = await _invoke('openBluetoothSettings');
      if (!ok) _snack('Could not open Settings. Please open it yourself.');
    }
    _refresh();
  }

  Future<void> _openWlan() async {
    setState(() => _waitingWifi = true);
    final ok = await _invoke('openWifiPanel');
    if (!ok) {
      setState(() => _waitingWifi = false);
      _snack('Could not open Settings. Please open it yourself.');
    }
  }

  void _snack(String m) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));
  }

  void _next() {
    if (!_ready || _navigated) return;
    _navigated = true;
    _timer?.cancel();
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (_) =>
            widget.receive
                ? QrScreen(ownNetwork: _hotspotOn)
                : const ScanQrScreen(),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: _kPrepGreen,
        foregroundColor: Colors.white,
        centerTitle: false,
        title: const Text('Preparations'),
      ),
      body: SafeArea(
        child: _denied
            ? _deniedPanel()
            : !_permDone
                ? const Center(child: CircularProgressIndicator())
                : _body(),
      ),
    );
  }

  Widget _deniedPanel() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text(
              'Camera permission is needed to scan the QR code.',
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 16),
            FilledButton(onPressed: _run, child: const Text('Try again')),
            TextButton(
              onPressed: openAppSettings,
              child: const Text('Open app settings'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _body() {
    return Column(
      children: [
        const SizedBox(height: 24),
        const Icon(Icons.phonelink_setup, size: 110, color: _kPrepGreen),
        const SizedBox(height: 24),
        Expanded(
          child: ListView(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            children: [
              if (_hotspotOn && !widget.receive)
                _row(Icons.wifi_tethering, 'Turn off hotspot', 'TURN OFF',
                    _turnOffHotspot),
              if (_bluetoothOn)
                _row(Icons.bluetooth, 'Turn off Bluetooth', 'TURN OFF',
                    _turnOffBluetooth),
              if (!_wifiOn && !(widget.receive && _hotspotOn))
                _row(Icons.wifi, 'Open WLAN', 'OPEN', _openWlan,
                    loading: _waitingWifi),
              if (_ready)
                Padding(
                  padding: const EdgeInsets.only(top: 40),
                  child: Center(
                    child: Text(
                      widget.receive && _hotspotOn
                          ? 'Your hotspot is on. The other phone must join its Wi-Fi first, then scan the QR code.'
                          : 'Everything is ready. Tap NEXT.',
                      textAlign: TextAlign.center,
                    ),
                  ),
                ),
            ],
          ),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 20),
          child: SizedBox(
            width: double.infinity,
            height: 56,
            child: FilledButton(
              style: FilledButton.styleFrom(
                backgroundColor: _kPrepGreen,
                disabledBackgroundColor: const Color(0xFFCCCCCC),
                foregroundColor: Colors.white,
                disabledForegroundColor: Colors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(28),
                ),
              ),
              onPressed: _ready ? _next : null,
              child: const Text(
                'NEXT',
                style: TextStyle(fontSize: 22, fontWeight: FontWeight.w600),
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _row(IconData icon, String title, String button, VoidCallback onTap,
      {bool loading = false}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 12),
      child: Row(
        children: [
          CircleAvatar(
            radius: 22,
            backgroundColor: _kPrepGreen,
            child: Icon(icon, color: Colors.white),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Text(title, style: const TextStyle(fontSize: 20)),
          ),
          if (loading)
            const SizedBox(
              width: 28,
              height: 28,
              child: CircularProgressIndicator(strokeWidth: 3, color: _kPrepGreen),
            )
          else
            OutlinedButton(
              style: OutlinedButton.styleFrom(
                foregroundColor: _kPrepGreen,
                side: const BorderSide(color: _kPrepGreen),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(24),
                ),
                padding:
                    const EdgeInsets.symmetric(horizontal: 22, vertical: 14),
              ),
              onPressed: onTap,
              child: Text(button, style: const TextStyle(fontSize: 16)),
            ),
        ],
      ),
    );
  }
}
