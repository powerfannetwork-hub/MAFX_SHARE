import 'package:flutter/material.dart';

import '../models.dart';
import '../services/selection_service.dart';
import '../services/transfer_service.dart';
import '../theme.dart';
import '../widgets/transfer_panel.dart';

/// Transfer progress in two tabs: Send (going out) and Received (coming in).
///
/// - files != null : starts sending those files
/// - receiving     : opened because files are arriving (starts on "Received")
class TransferScreen extends StatefulWidget {
  const TransferScreen({super.key, this.files, this.receiving = false});

  final List<PendingFile>? files;
  final bool receiving;

  static int _openCount = 0;

  /// True while a transfer screen is on top (so we do not open a second one).
  static bool get isOpen => _openCount > 0;

  @override
  State<TransferScreen> createState() => _TransferScreenState();
}

class _TransferScreenState extends State<TransferScreen> {
  final svc = TransferService.instance;
  String? _error;

  @override
  void initState() {
    super.initState();
    TransferScreen._openCount++;
    if (widget.files != null) {
      // The selection is cleared right away, so you can pick more files and
      // press Send again while this one is still running.
      WidgetsBinding.instance.addPostFrameCallback((_) {
        SelectionService.instance.clear();
      });
      _send();
    }
  }

  Future<void> _send() async {
    try {
      await svc.sendFiles(widget.files!);
    } catch (e) {
      if (mounted) {
        setState(() => _error = e.toString().replaceFirst('Exception: ', ''));
      }
    }
  }

  @override
  void dispose() {
    // Leaving this screen must NOT end the connection.
    TransferScreen._openCount--;
    super.dispose();
  }

  int get _initialTab {
    if (widget.files != null) return 0;
    if (widget.receiving) return 1;
    final sending = svc.sendProgress.value;
    final receiving = svc.receiveProgress.value;
    if (sending == null && receiving != null) return 1;
    return 0;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Transfer'),
        actions: [
          IconButton(
            tooltip: 'Disconnect',
            icon: const Icon(Icons.link_off),
            onPressed: () async {
              await svc.endSession();
              SelectionService.instance.clear();
              if (context.mounted) {
                Navigator.popUntil(context, (r) => r.isFirst);
              }
            },
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            if (_error != null) ...[
              const SizedBox(height: 12),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: alpha(Colors.redAccent, 0.15),
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: Colors.redAccent),
                ),
                child: Text(_error!, textAlign: TextAlign.center),
              ),
            ],
            const SizedBox(height: 8),
            Expanded(child: TransferPanel(initialTab: _initialTab)),
          ],
        ),
      ),
    );
  }
}
