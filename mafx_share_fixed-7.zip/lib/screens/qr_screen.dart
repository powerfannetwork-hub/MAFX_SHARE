import 'package:flutter/material.dart';
import 'package:qr_flutter/qr_flutter.dart';

import '../models.dart';
import '../services/transfer_service.dart';
import '../theme.dart';

/// Receiver shows this QR code. The sender scans it.
class QrScreen extends StatefulWidget {
  const QrScreen({super.key, this.ownNetwork = false});

  /// true = the user's own hotspot / Wi-Fi is used (no hotspot is created).
  final bool ownNetwork;

  @override
  State<QrScreen> createState() => _QrScreenState();
}

class _QrScreenState extends State<QrScreen> {
  final svc = TransferService.instance;
  bool _ready = false;
  bool _paired = false;
  // 0 = 5 GHz hotspot (Wi-Fi Direct, falls back to normal), 1 = normal hotspot,
  // 2 = my own Wi-Fi / my own hotspot
  late int _netMode = widget.ownNetwork ? 2 : 0;
  String? _error;

  @override
  void initState() {
    super.initState();
    svc.pairedPeer.addListener(_onPaired);
    _start();
  }

  Future<void> _start() async {
    setState(() {
      _error = null;
      _ready = false;
    });
    try {
      await svc.startReceiver(
        useHotspot: _netMode != 2,
        prefer5g: _netMode == 0,
      );
      if (mounted) setState(() => _ready = true);
    } catch (e) {
      if (mounted) {
        setState(() => _error = e.toString().replaceFirst('Exception: ', ''));
      }
    }
  }

  void _onPaired() {
    if (_paired || svc.pairedPeer.value == null || !mounted) return;
    _paired = true;
    // Connected: go back to Home. The transfer screen opens by itself when
    // files start to arrive, and this phone can also send from Home.
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Connection Successful')),
    );
    Navigator.of(context).popUntil((r) => r.isFirst);
  }

  @override
  void dispose() {
    svc.pairedPeer.removeListener(_onPaired);
    if (!_paired) svc.stopReceiver();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Scan to connect'),
        actions: [
          PopupMenuButton<int>(
            tooltip: 'Network',
            color: kPanel,
            onSelected: (v) {
              _netMode = v;
              _start();
            },
            itemBuilder: (_) => [
              CheckedPopupMenuItem(
                value: 0,
                checked: _netMode == 0,
                child: const Text('5 GHz hotspot (fast)'),
              ),
              CheckedPopupMenuItem(
                value: 1,
                checked: _netMode == 1,
                child: const Text('Normal hotspot (2.4 GHz)'),
              ),
              CheckedPopupMenuItem(
                value: 2,
                checked: _netMode == 2,
                child: const Text('My Wi-Fi / my own hotspot'),
              ),
            ],
          ),
        ],
      ),
      body: _error != null
          ? Center(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(_error!, textAlign: TextAlign.center),
                    const SizedBox(height: 16),
                    FilledButton(onPressed: _start, child: const Text('Try again')),
                  ],
                ),
              ),
            )
          : !_ready
              ? const Center(child: CircularProgressIndicator())
              : _content(),
    );
  }

  Widget _content() {
    const blue = Color(0xFF2196F3);
    const frame = Color(0xFF3DB5FF);
    return Center(
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              padding: const EdgeInsets.all(18),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(32),
                border: Border.all(color: frame, width: 5),
                boxShadow: [
                  BoxShadow(color: alpha(frame, 0.5), blurRadius: 24),
                ],
              ),
              child: QrImageView(
                data: svc.qrPayload(),
                size: 260,
                backgroundColor: Colors.white,
                eyeStyle:
                    const QrEyeStyle(eyeShape: QrEyeShape.square, color: blue),
                dataModuleStyle: const QrDataModuleStyle(
                  dataModuleShape: QrDataModuleShape.square,
                  color: blue,
                ),
              ),
            ),
            const SizedBox(height: 20),
            Text(
              '${svc.localIp}:${svc.httpPort}',
              style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w700),
            ),
            if (svc.hotspotBand == 1)
              Padding(
                padding: const EdgeInsets.only(top: 14),
                child: Text(
                  'This hotspot is probably 2.4 GHz (slow). For full speed turn on YOUR OWN 5 GHz hotspot instead.',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: alpha(Colors.orangeAccent, 0.95)),
                ),
              ),
          ],
        ),
      ),
    );
  }
}
